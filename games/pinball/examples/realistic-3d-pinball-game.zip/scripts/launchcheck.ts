import './shim';
import { stepPhysics } from '../src/game/physics';
import { gameRef, spawnBallAt } from '../src/game/store';
import { SENSORS, PLUNGER_X, PLUNGER_REST_Y } from '../src/game/constants';
import { applyDifficulty, DIFF, DIFF_ORDER, DIFFS } from '../src/game/difficulty';

const dt = 1 / 120;

console.log('per-tier plunger sweep: apex height + top-lane reach at skill-zone power');
for (const id of DIFF_ORDER) {
  applyDifficulty(id);
  const cfg = DIFFS[id];
  const row: string[] = [];
  for (const p of [0.2, 0.32, 0.4, 0.48, 0.65, 1.0]) {
    gameRef.balls = [];
    gameRef.plungerCharging = false;
    const b = spawnBallAt(PLUNGER_X, PLUNGER_REST_Y, 0, (80 + p * 175) * cfg.launch);
    b.inLane = true;
    let apex = -99, laneHit = false;
    for (let s = 0; s < 120 * 8; s++) {
      stepPhysics(dt);
      if (!b.active) break;
      apex = Math.max(apex, b.y);
      for (const sn of SENSORS) {
        if (sn.kind === 'lane' && Math.hypot(b.x - sn.x, b.y - sn.y) < sn.r) laneHit = true;
      }
      if (laneHit) break;
    }
    row.push(`p${p.toFixed(2)}:${laneHit ? 'LANE' : apex.toFixed(0)}`);
  }
  console.log(`  ${cfg.label.padEnd(11)} ${row.join('  ')}`);
}
applyDifficulty('medium');
