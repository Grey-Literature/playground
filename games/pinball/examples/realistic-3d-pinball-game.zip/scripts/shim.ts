// Minimal browser shims so the game modules can be imported in plain Node for analysis.
const g = globalThis as any;
if (!g.window) g.window = g;
if (!g.localStorage) {
  const store = new Map<string, string>();
  g.localStorage = {
    getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
    setItem: (k: string, v: string) => void store.set(k, v),
  };
}
if (!g.performance) g.performance = { now: () => Date.now() };
export {};
