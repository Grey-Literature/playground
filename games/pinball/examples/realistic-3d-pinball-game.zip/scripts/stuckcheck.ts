import './shim';
import { stepPhysics } from '../src/game/physics';
import { gameRef } from '../src/game/store';
import {
  BALL_RADIUS, WALL_PAD, WALLS, BUMPERS, POSTS, TARGETS, DROP_TARGETS,
  EXTRA_BUMPERS, TOP_POSTS, FRICKIES,
  LEFT_PIVOT, RIGHT_PIVOT, FLIPPER_LEN, FLIPPER_R, LEFT_REST, RIGHT_REST,
  RAMP_PATH, TUNNEL_PATH, BallState,
} from '../src/game/constants';
import { applyDifficulty, DIFF, DIFF_ORDER, DIFFS, WRECKER } from '../src/game/difficulty';

const dt = 1 / 120;
let seed = 12345;
const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);

function segDist(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
  const abx = bx - ax, aby = by - ay;
  const len2 = abx * abx + aby * aby;
  const t = len2 > 1e-9 ? Math.max(0, Math.min(1, ((px - ax) * abx + (py - ay) * aby) / len2)) : 0;
  return Math.hypot(px - (ax + abx * t), py - (ay + aby * t));
}

// static clearance for the ACTIVE difficulty (mirrors physics.ts gating)
function clearance(x: number, y: number) {
  let m = Infinity;
  for (const w of WALLS) m = Math.min(m, segDist(x, y, w.ax, w.ay, w.bx, w.by) - (BALL_RADIUS + WALL_PAD));
  const bumps = DIFF.ob.extraBumpers ? [...BUMPERS, ...EXTRA_BUMPERS] : BUMPERS;
  const posts = DIFF.ob.topPosts ? [...POSTS, ...TOP_POSTS] : POSTS;
  const frick = DIFF.ob.frickies ? FRICKIES : [];
  for (const b of bumps) m = Math.min(m, Math.hypot(x - b.x, y - b.y) - (b.r + BALL_RADIUS));
  for (const p of [...posts, ...frick]) m = Math.min(m, Math.hypot(x - p.x, y - p.y) - (p.r + BALL_RADIUS));
  for (const t of TARGETS) m = Math.min(m, Math.hypot(x - t.x, y - t.y) - (t.r + BALL_RADIUS));
  for (const t of DROP_TARGETS) m = Math.min(m, Math.hypot(x - t.x, y - t.y) - (t.r + BALL_RADIUS));
  for (const pv of [LEFT_PIVOT, RIGHT_PIVOT]) {
    const ang = pv === LEFT_PIVOT ? LEFT_REST : RIGHT_REST;
    m = Math.min(m, segDist(x, y, pv.x, pv.y,
      pv.x + Math.cos(ang) * FLIPPER_LEN, pv.y + Math.sin(ang) * FLIPPER_LEN) - (BALL_RADIUS + FLIPPER_R));
  }
  return m;
}

function crv(points: typeof RAMP_PATH, t: number) {
  const n = points.length - 1;
  const u = Math.max(0, Math.min(0.9999, t)) * n;
  const i = Math.floor(u); const f = u - i; const f2 = f * f; const f3 = f2 * f;
  const g = (k: 'x' | 'y') => {
    const p0 = points[Math.max(0, i - 1)][k], p1 = points[i][k];
    const p2 = points[Math.min(n, i + 1)][k], p3 = points[Math.min(n, i + 2)][k];
    return 0.5 * (2 * p1 + (-p0 + p2) * f + (2 * p0 - 5 * p1 + 4 * p2 - p3) * f2 + (-p0 + 3 * p1 - 3 * p2 + p3) * f3);
  };
  return { x: g('x'), y: g('y') };
}

function reset() {
  gameRef.balls = [];
  gameRef.left.pressed = false;
  gameRef.right.pressed = false;
  gameRef.plungerCharging = false;
  gameRef.tiltedUntil = 0;
  gameRef.paused = false;
  gameRef.dropDown = [false, false, false];
}

function mkBall(x: number, y: number, vx: number, vy: number, cooldown = 3): BallState {
  return { id: 1, x, y, vx, vy, active: true, inLane: false, captured: 0, captureCooldown: cooldown, inside: new Set(), spin: 0 };
}

function legitRest(x: number, y: number) {
  if (x > 16.5) return true;
  for (const pv of [LEFT_PIVOT, RIGHT_PIVOT]) {
    const ang = pv === LEFT_PIVOT ? LEFT_REST : RIGHT_REST;
    const d = segDist(x, y, pv.x, pv.y, pv.x + Math.cos(ang) * FLIPPER_LEN, pv.y + Math.sin(ang) * FLIPPER_LEN);
    if (d < BALL_RADIUS + FLIPPER_R + 0.6) return true;
  }
  return false;
}

// A ball is stuck if it stays slow AND travels less than 2.4 units over a 2.5s window
// (position variance, so the wrecker shoving a ball around doesn't false-positive).
function soak(): { stuck: { x: number; y: number }[]; drained: number; trials: number; rest: number } {
  const stuck: { x: number; y: number }[] = [];
  let drained = 0, trials = 0, rest = 0;

  // flood-fill reachable free space for this tier's obstacle set
  const X0 = -23, X1 = 23, Y0 = -42, Y1 = 38, STEP = 0.7;
  const NX = Math.round((X1 - X0) / STEP) + 1;
  const NY = Math.round((Y1 - Y0) / STEP) + 1;
  const free = new Uint8Array(NX * NY);
  for (let i = 0; i < NX; i++) for (let j = 0; j < NY; j++) free[i * NY + j] = clearance(X0 + i * STEP, Y0 + j * STEP) > 0 ? 1 : 0;
  const seen = new Uint8Array(NX * NY);
  const q = [Math.round((19.5 - X0) / STEP) * NY + Math.round((-20 - Y0) / STEP)];
  seen[q[0]] = 1;
  while (q.length) {
    const cur = q.pop()!;
    const ci = Math.floor(cur / NY), cj = cur % NY;
    for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const ni = ci + di, nj = cj + dj;
      if (ni < 0 || nj < 0 || ni >= NX || nj >= NY) continue;
      const idx = ni * NY + nj;
      if (seen[idx] || !free[idx]) continue;
      seen[idx] = 1;
      q.push(idx);
    }
  }
  const reach = (x: number, y: number) => {
    const i = Math.round((x - X0) / STEP), j = Math.round((y - Y0) / STEP);
    return i >= 0 && j >= 0 && i < NX && j < NY && seen[i * NY + j] === 1;
  };

  for (let gx = -21; gx <= 21; gx += 1.5) {
    for (let gy = -36; gy <= 34; gy += 1.5) {
      if (clearance(gx, gy) < 0.05 || !reach(gx, gy)) continue;
      trials++;
      reset();
      const speed = 30 + rnd() * 130 * DIFF.launch;
      const ang = rnd() * Math.PI * 2;
      const ball = mkBall(gx, gy, Math.cos(ang) * speed, Math.sin(ang) * speed);
      gameRef.balls.push(ball);
      const hist: [number, number][] = [];
      let slow = 0, result = 'run';
      for (let s = 0; s < 120 * 9; s++) {
        stepPhysics(dt);
        if (!ball.active) { result = 'drain'; break; }
        if (ball.captured > 0 || ball.ride) { slow = 0; hist.length = 0; continue; }
        const sp = Math.hypot(ball.vx, ball.vy);
        if (sp < 11) slow += dt; else slow = 0;
        hist.push([ball.x, ball.y]);
        if (hist.length > 300) hist.shift();
        if (slow > 2.5) {
          if (legitRest(ball.x, ball.y)) { result = 'rest'; break; }
          let minx = Infinity, maxx = -Infinity, miny = Infinity, maxy = -Infinity;
          for (const [hx, hy] of hist) {
            minx = Math.min(minx, hx); maxx = Math.max(maxx, hx);
            miny = Math.min(miny, hy); maxy = Math.max(maxy, hy);
          }
          const spread = Math.hypot(maxx - minx, maxy - miny);
          if (spread > 2.4) { slow = 0; continue; } // being actively moved around
          result = 'stuck';
          break;
        }
      }
      if (result === 'drain') drained++;
      else if (result === 'rest') rest++;
      else if (result === 'stuck') stuck.push({ x: ball.x, y: ball.y });
    }
  }
  return { stuck, drained, trials, rest };
}

console.log('tier soak — every difficulty, obstacles active:');
let anyBad = false;
for (const id of DIFF_ORDER) {
  applyDifficulty(id);
  const r = soak();
  const flag = r.stuck.length ? `  <-- ${r.stuck.length} STUCK` : '';
  if (r.stuck.length) anyBad = true;
  const clusters = new Map<string, number>();
  for (const s of r.stuck) {
    const k = `${Math.round(s.x / 2)}_${Math.round(s.y / 2)}`;
    clusters.set(k, (clusters.get(k) ?? 0) + 1);
  }
  const worst = [...clusters.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3)
    .map(([k, n]) => `${k.replace('_', ',')}×${n}`).join('  ');
  console.log(
    `  ${DIFFS[id].label.padEnd(11)} trials=${String(r.trials).padStart(4)} drain=${String(r.drained).padStart(4)} flipperRest=${String(r.rest).padStart(3)} stuck=${String(r.stuck.length).padStart(2)}${flag} ${worst}`,
  );
}

applyDifficulty('medium');

// ride tests (both capture paths must always eject, at medium)
console.log('\nride tests (medium):');
for (const test of [
  { name: 'ramp', path: RAMP_PATH, x: -18.2, y: 4.5, vx: 0, vy: 130 },
  { name: 'tunnel', path: TUNNEL_PATH, x: 6.2, y: -9.0, vx: 0, vy: 42 },
]) {
  reset();
  const ball = mkBall(test.x, test.y, test.vx, test.vy, 0);
  gameRef.balls.push(ball);
  let rode = 0, ejected = false, bad = false;
  for (let s = 0; s < 120 * 8; s++) {
    stepPhysics(dt);
    if (ball.ride) rode++;
    else if (rode > 0) ejected = true;
    if (ejected && !ball.ride) {
      if (Math.hypot(ball.vx, ball.vy) > 1) break;
      bad = true; break;
    }
    if (!ball.active) break;
  }
  // verify the ride path itself doesn't clip static toys (visual overlap check)
  let minClr = Infinity;
  for (let i = 0; i <= 400; i++) {
    const p = crv(test.path, i / 400);
    minClr = Math.min(minClr, clearance(p.x, p.y));
  }
  console.log(`  ${test.name}: ejected=${ejected && !bad} rideTime=${(rode / 120).toFixed(2)}s path-vs-toys clearance=${minClr.toFixed(2)} (path may legally overlap scenery it flies over)`);
}

// wrecker must never pin a ball: dedicated soak at impossible with bar spinning
applyDifficulty('impossible');
let pin = 0;
for (let n = 0; n < 500; n++) {
  reset();
  const x = -10 + rnd() * 20, y = -22 + rnd() * 12;
  if (clearance(x, y) < 0.05) continue;
  const ball = mkBall(x, y, (rnd() - 0.5) * 60, -20 - rnd() * 40);
  gameRef.balls.push(ball);
  const hist: [number, number][] = [];
  let slow = 0;
  for (let s = 0; s < 120 * 10; s++) {
    stepPhysics(dt);
    if (!ball.active) break;
    if (ball.captured > 0 || ball.ride) { slow = 0; hist.length = 0; continue; }
    if (Math.hypot(ball.vx, ball.vy) < 11) slow += dt; else slow = 0;
    hist.push([ball.x, ball.y]);
    if (hist.length > 260) hist.shift();
    if (slow > 2.2) {
      if (legitRest(ball.x, ball.y)) break;
      let minx = Infinity, maxx = -Infinity, miny = Infinity, maxy = -Infinity;
      for (const [hx, hy] of hist) { minx = Math.min(minx, hx); maxx = Math.max(maxx, hx); miny = Math.min(miny, hy); maxy = Math.max(maxy, hy); }
      if (Math.hypot(maxx - minx, maxy - miny) < 2.4) { pin++; break; }
      slow = 0;
    }
  }
}
console.log(`\nwrecker+frickies pin test (impossible, 500 balls near bar): pinned=${pin}`);
applyDifficulty('medium');
void WRECKER;
if (anyBad || pin) process.exitCode = 1;
