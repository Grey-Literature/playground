import { useGame, gameRef } from '../game/store';
import { DIFFS, DIFF_ORDER, obstacleCount, DIFF } from '../game/difficulty';
import {
  Volume2, VolumeX, Camera, Vibrate, VibrateOff, CircleHelp,
  Play, Pause, RotateCcw, Trophy, Zap, Target, Sparkles, TriangleAlert, LifeBuoy,
} from 'lucide-react';

function fmt(n: number) {
  return n.toLocaleString('en-US');
}

function Kbd({ children, active, wide }: { children: React.ReactNode; active?: boolean; wide?: boolean }) {
  return (
    <span
      className={`inline-flex items-center justify-center ${wide ? 'px-2.5' : 'px-1.5'} min-w-7 h-7 rounded-md border text-[11px] font-bold tracking-wide transition-all duration-75 ${
        active
          ? 'bg-cyan-400 text-slate-950 border-cyan-300 shadow-[0_0_14px_rgba(34,211,238,0.8)] scale-105'
          : 'bg-slate-800/80 text-slate-200 border-slate-600/80'
      }`}
    >
      {children}
    </span>
  );
}

function DifficultyPicker({ compact }: { compact?: boolean }) {
  const selected = useGame((s) => s.difficulty);
  const setDifficulty = useGame((s) => s.setDifficulty);
  return (
    <div className={`grid w-full gap-1.5 ${compact ? 'grid-cols-5' : 'grid-cols-2 sm:grid-cols-5'}`}>
      {DIFF_ORDER.map((id, i) => {
        const cfg = DIFFS[id];
        const on = selected === id;
        return (
          <button
            key={id}
            onClick={() => setDifficulty(id)}
            title={cfg.blurb}
            className={`group pointer-events-auto relative overflow-hidden rounded-lg border px-2 py-2 text-left transition-all duration-150 ${
              on ? 'scale-[1.03] border-transparent shadow-lg' : 'border-slate-700/60 bg-slate-900/50 hover:border-slate-500 hover:bg-slate-800/70'
            }`}
            style={on ? { background: `${cfg.accent}22`, borderColor: cfg.accent, boxShadow: `0 0 18px ${cfg.accent}55` } : undefined}
          >
            <div className="flex items-center justify-between gap-1">
              <span className={`text-[10px] font-black tracking-wider ${on ? '' : 'text-slate-300'}`} style={on ? { color: cfg.accent } : undefined}>
                {cfg.label}
              </span>
              <span className="text-[9px] font-bold text-slate-500">{i + 1}</span>
            </div>
            {!compact && (
              <div className="mt-1 flex items-center gap-1">
                <span className="h-1 w-1 rounded-full" style={{ background: cfg.accent }} />
                <span className="text-[9px] font-bold text-slate-400">+{obstacleCount(id)} obst</span>
                <span className="text-[9px] font-bold text-slate-500">·</span>
                <span className="text-[9px] font-black" style={{ color: cfg.score >= 1 ? cfg.accent : '#64748b' }}>
                  {cfg.score >= 1 ? `${cfg.score.toFixed(2)}x pts` : `${cfg.score.toFixed(2)}x`}
                </span>
              </div>
            )}
            {on && <span className="absolute inset-x-0 bottom-0 h-0.5" style={{ background: cfg.accent }} />}
          </button>
        );
      })}
    </div>
  );
}

function DifficultyBadge() {
  const difficulty = useGame((s) => s.difficulty);
  const cfg = DIFFS[difficulty];
  return (
    <div
      className="pointer-events-none flex items-center gap-1.5 rounded-full border px-3 py-1 backdrop-blur-md"
      style={{ borderColor: `${cfg.accent}66`, background: `${cfg.accent}14` }}
      title={cfg.blurb}
    >
      <Zap className="h-3 w-3" style={{ color: cfg.accent }} />
      <span className="text-[10px] font-black tracking-[0.2em]" style={{ color: cfg.accent }}>{cfg.label}</span>
      {cfg.score !== 1 && <span className="text-[10px] font-black text-slate-300">{cfg.score}x</span>}
    </div>
  );
}

function TopBar() {
  const score = useGame((s) => s.score);
  const highScore = useGame((s) => s.highScore);
  const ball = useGame((s) => s.ball);
  const totalBalls = useGame((s) => s.totalBalls);
  const multiplier = useGame((s) => s.multiplier);
  const multiball = useGame((s) => s.multiball);
  const multiballT = useGame((s) => s.multiballT);
  const phase = useGame((s) => s.phase);
  const isHigh = phase === 'playing' && score > 0 && score >= highScore;

  return (
    <div className="pointer-events-none absolute top-0 left-0 right-0 z-20 flex items-start justify-between gap-3 p-3 sm:p-4">
      {/* score */}
      <div className="min-w-0 flex-1">
        <div className="inline-block rounded-xl border border-cyan-400/25 bg-slate-950/70 px-4 py-2 backdrop-blur-md shadow-[0_0_30px_rgba(34,211,238,0.15)]">
          <div className="text-[10px] font-bold tracking-[0.3em] text-cyan-400/80">SCORE</div>
          <div className={`font-display text-2xl sm:text-4xl font-black tabular-nums leading-none ${isHigh ? 'text-yellow-300 drop-shadow-[0_0_12px_rgba(253,224,71,0.7)]' : 'text-white drop-shadow-[0_0_12px_rgba(34,211,238,0.6)]'}`}>
            {fmt(score)}
          </div>
          <div className="mt-1 flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
            <Trophy className="h-3 w-3 text-amber-400" />
            <span className="tabular-nums">{fmt(highScore)}</span>
            {isHigh && <span className="ml-1 animate-pulse rounded bg-yellow-400/20 px-1.5 py-px text-[10px] font-black text-yellow-300">NEW BEST!</span>}
          </div>
        </div>
      </div>

      {/* multiball / multiplier center */}
      <div className="hidden sm:flex flex-col items-center gap-2 pt-1">
        <div className={`flex items-center gap-2 rounded-full border px-4 py-1.5 backdrop-blur-md ${multiball ? 'border-fuchsia-400/60 bg-fuchsia-950/70 shadow-[0_0_24px_rgba(232,121,249,0.5)]' : 'border-slate-600/50 bg-slate-950/70'}`}>
          <Zap className={`h-4 w-4 ${multiball ? 'text-fuchsia-300' : multiplier >= 5 ? 'text-yellow-300' : 'text-cyan-300'}`} />
          <span className={`font-display text-lg font-black ${multiball ? 'text-fuchsia-200' : 'text-white'}`}>
            {multiball ? `${multiplier * 2}X` : `${multiplier}X`}
          </span>
          <span className="text-[10px] font-bold tracking-widest text-slate-400">{multiball ? 'MULTIBALL' : 'MULTI'}</span>
        </div>
        {multiball && (
          <div className="h-1.5 w-40 overflow-hidden rounded-full bg-slate-800">
            <div className="h-full rounded-full bg-gradient-to-r from-fuchsia-400 to-cyan-300 transition-all" style={{ width: `${(multiballT / DIFF.mbTime) * 100}%` }} />
          </div>
        )}
        <DifficultyBadge />
      </div>

      {/* ball */}
      <div className="flex flex-1 justify-end">
        <div className="rounded-xl border border-fuchsia-400/25 bg-slate-950/70 px-4 py-2 text-right backdrop-blur-md shadow-[0_0_30px_rgba(232,121,249,0.15)]">
          <div className="text-[10px] font-bold tracking-[0.3em] text-fuchsia-400/80">BALL</div>
          <div className="font-display text-2xl sm:text-4xl font-black leading-none text-white drop-shadow-[0_0_12px_rgba(232,121,249,0.6)] tabular-nums">
            {ball}<span className="text-slate-500 text-lg sm:text-2xl">/{totalBalls}</span>
          </div>
          <BallsDots />
        </div>
      </div>
    </div>
  );
}

function BallsDots() {
  const ball = useGame((s) => s.ball);
  const totalBalls = useGame((s) => s.totalBalls);
  const phase = useGame((s) => s.phase);
  if (phase !== 'playing') return <div className="mt-1 h-2" />;
  return (
    <div className="mt-1.5 flex justify-end gap-1">
      {Array.from({ length: Math.min(totalBalls, 6) }).map((_, i) => (
        <span
          key={i}
          className={`h-2 w-2 rounded-full ${i < totalBalls - ball + 1 ? 'bg-fuchsia-400 shadow-[0_0_6px_rgba(232,121,249,0.9)]' : 'bg-slate-700'}`}
        />
      ))}
    </div>
  );
}

function StatusPanels() {
  const lanes = useGame((s) => s.lanes);
  const leftTargets = useGame((s) => s.leftTargets);
  const rightTargets = useGame((s) => s.rightTargets);
  const centerTargets = useGame((s) => s.centerTargets);
  const jackpotLit = useGame((s) => s.jackpotLit);
  const dropTargets = useGame((s) => s.dropTargets);
  const kickbackLit = useGame((s) => s.kickbackLit);
  const rampLit = useGame((s) => s.rampLit);
  const combo = useGame((s) => s.combo);
  const rampChain = useGame((s) => s.rampChain);
  const multiball = useGame((s) => s.multiball);
  const tiltWarnings = useGame((s) => s.tiltWarnings);
  const tilted = useGame((s) => s.tilted);
  const phase = useGame((s) => s.phase);
  const bonus = useGame((s) => s.bonus);
  if (phase !== 'playing') return null;
  return (
    <>
      {/* left panel */}
      <div className="pointer-events-none absolute left-3 top-1/2 z-20 hidden -translate-y-1/2 flex-col gap-3 lg:flex">
        <div className="rounded-xl border border-slate-700/60 bg-slate-950/70 p-3 backdrop-blur-md w-36">
          <div className="mb-2 text-[10px] font-black tracking-[0.25em] text-emerald-400">TOP LANES</div>
          <div className="flex gap-2">
            {lanes.map((lit, i) => (
              <div key={i} className={`flex h-9 flex-1 items-center justify-center rounded-lg border text-sm font-black ${lit ? 'border-emerald-300 bg-emerald-400 text-slate-950 shadow-[0_0_12px_rgba(52,211,153,0.8)]' : 'border-slate-700 bg-slate-800/60 text-slate-500'}`}>
                {['N', 'O', 'V'][i]}
              </div>
            ))}
          </div>
          <div className="mt-2 text-[10px] text-slate-400">All 3 → multiplier +1</div>
        </div>
        <div className="rounded-xl border border-slate-700/60 bg-slate-950/70 p-3 backdrop-blur-md w-36">
          <div className="mb-2 flex items-center gap-1 text-[10px] font-black tracking-[0.25em] text-cyan-300">
            <Target className="h-3 w-3" /> BANKS
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              <span className="w-6 text-[10px] font-bold text-cyan-400">L</span>
              {leftTargets.map((t, i) => (
                <span key={i} className={`h-3 flex-1 rounded-sm ${t ? 'bg-cyan-300 shadow-[0_0_8px_rgba(34,211,238,0.9)]' : 'bg-slate-700'}`} />
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-6 text-[10px] font-bold text-fuchsia-400">R</span>
              {rightTargets.map((t, i) => (
                <span key={i} className={`h-3 flex-1 rounded-sm ${t ? 'bg-fuchsia-400 shadow-[0_0_8px_rgba(232,121,249,0.9)]' : 'bg-slate-700'}`} />
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-6 text-[10px] font-bold text-amber-400">C</span>
              {centerTargets.map((t, i) => (
                <span key={i} className={`h-3 flex-1 rounded-sm ${t ? 'bg-amber-300 shadow-[0_0_8px_rgba(251,191,36,0.9)]' : 'bg-slate-700'}`} />
              ))}
            </div>
          </div>
          <div className="mt-2 text-[10px] text-slate-400">L+R → multiball • C → jackpot</div>
        </div>
        <div className="rounded-xl border border-slate-700/60 bg-slate-950/70 p-3 backdrop-blur-md w-36">
          <div className="mb-2 text-[10px] font-black tracking-[0.25em] text-cyan-300">DOORS</div>
          <div className="flex gap-1.5">
            {dropTargets.map((t, i) => (
              <span key={i} className={`h-7 flex-1 rounded ${t ? 'bg-slate-700/80' : 'bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]'}`} />
            ))}
          </div>
          <div className="mt-2 text-[10px] text-slate-400">Drop all 3 → kickback + ramp 3X</div>
        </div>
      </div>
      {/* right panel */}
      <div className="pointer-events-none absolute right-3 top-1/2 z-20 hidden -translate-y-1/2 flex-col gap-3 lg:flex">
        <div className={`rounded-xl border p-3 backdrop-blur-md w-36 ${jackpotLit ? 'border-amber-300/70 bg-amber-950/70 shadow-[0_0_24px_rgba(251,191,36,0.4)]' : 'border-slate-700/60 bg-slate-950/70'}`}>
          <div className={`flex items-center gap-1 text-[10px] font-black tracking-[0.25em] ${jackpotLit ? 'text-amber-300' : 'text-slate-400'}`}>
            <Sparkles className="h-3 w-3" /> JACKPOT
          </div>
          <div className={`font-display mt-1 text-xl font-black ${jackpotLit ? 'animate-pulse text-amber-300' : 'text-slate-600'}`}>
            {jackpotLit ? '25,000' : '— — —'}
          </div>
          <div className="text-[10px] text-slate-400">{jackpotLit ? 'SHOOT SCOOP!' : 'Light C targets'}</div>
        </div>
        <div className={`rounded-xl border p-3 backdrop-blur-md w-36 ${kickbackLit || rampLit ? 'border-fuchsia-400/50 bg-fuchsia-950/50' : 'border-slate-700/60 bg-slate-950/70'}`}>
          <div className="text-[10px] font-black tracking-[0.25em] text-fuchsia-300">SHOTS</div>
          <div className={`mt-1 text-[11px] font-black ${rampLit ? 'animate-pulse text-cyan-300' : 'text-slate-500'}`}>RAMP {rampLit ? '3X LIT' : '—'}{rampChain > 1 ? ` x${rampChain}` : ''}</div>
          <div className={`text-[11px] font-black ${kickbackLit ? 'animate-pulse text-amber-300' : 'text-slate-500'}`}>KICKBACK {kickbackLit ? 'READY' : '—'}</div>
          {combo >= 2 && <div className="mt-1 text-[11px] font-black text-yellow-300">COMBO x{combo}</div>}
        </div>
        <div className="rounded-xl border border-slate-700/60 bg-slate-950/70 p-3 backdrop-blur-md w-36">
          <div className="text-[10px] font-black tracking-[0.25em] text-slate-400">BONUS</div>
          <div className="font-display text-xl font-black text-slate-200 tabular-nums">{fmt(Math.round(bonus))}</div>
          {multiball && <div className="mt-1 animate-pulse text-[10px] font-black text-fuchsia-300">2X SCORING!</div>}
        </div>
        <div className={`rounded-xl border p-3 backdrop-blur-md w-36 ${tilted ? 'border-red-500 bg-red-950/80' : 'border-slate-700/60 bg-slate-950/70'}`}>
          <div className="flex items-center gap-1 text-[10px] font-black tracking-[0.25em] text-slate-400">
            <TriangleAlert className="h-3 w-3" /> TILT
          </div>
          <div className="mt-1.5 flex gap-1.5">
            {[0, 1].map((i) => (
              <span key={i} className={`h-2 flex-1 rounded-full ${tilted ? 'bg-red-500' : i < tiltWarnings ? 'bg-orange-400' : 'bg-slate-700'}`} />
            ))}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">{tilted ? 'FLIPPERS DEAD!' : 'Nudge carefully'}</div>
        </div>
      </div>
    </>
  );
}

function MessageBar() {
  const message = useGame((s) => s.message);
  const messageT = useGame((s) => s.messageT);
  const phase = useGame((s) => s.phase);
  if (phase !== 'playing') return null;
  return (
    <div className="pointer-events-none absolute bottom-24 sm:bottom-20 left-0 right-0 z-20 flex justify-center px-4">
      <div key={messageT} className="msg-pop rounded-full border border-slate-600/60 bg-slate-950/75 px-5 py-1.5 text-center text-xs sm:text-sm font-bold tracking-wide text-slate-100 backdrop-blur-md">
        {message}
      </div>
    </div>
  );
}

function Popups() {
  const popups = useGame((s) => s.popups);
  return (
    <div className="pointer-events-none absolute right-4 sm:right-8 top-32 z-20 flex flex-col items-end gap-2">
      {popups.map((p) => (
        <div key={p.id} className="popup-rise rounded-lg border border-yellow-300/40 bg-slate-950/85 px-3 py-1.5 text-right backdrop-blur-md shadow-[0_0_20px_rgba(251,191,36,0.25)]">
          <div className="font-display text-lg font-black text-yellow-300 tabular-nums">{p.text}</div>
          {p.sub && <div className="text-[10px] font-black tracking-[0.2em] text-yellow-200/70">{p.sub}</div>}
        </div>
      ))}
    </div>
  );
}

function BigMessage() {
  const big = useGame((s) => s.bigMessage);
  const t = useGame((s) => s.bigMessageT);
  if (!big) return null;
  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
      <div key={t} className="big-pop px-6 text-center">
        <div className="font-display text-4xl sm:text-7xl font-black tracking-tight text-white drop-shadow-[0_0_25px_rgba(34,211,238,0.9)]" style={{ WebkitTextStroke: '1px rgba(34,211,238,0.6)' }}>
          {big}
        </div>
      </div>
    </div>
  );
}

function PlungerMeter() {
  const ballPhase = useGame((s) => s.ballPhase);
  const charging = useGame((s) => s.plungerCharging);
  const power = useGame((s) => s.plungerPower);
  const phase = useGame((s) => s.phase);
  if (phase !== 'playing' || ballPhase !== 'plunger') return null;
  return (
    <div className="pointer-events-none absolute bottom-40 right-4 sm:right-8 z-20 flex flex-col items-center gap-2">
      <div className="text-[10px] font-black tracking-[0.25em] text-slate-300">POWER</div>
      <div className="relative h-44 w-5 overflow-hidden rounded-full border border-slate-600 bg-slate-900/90">
        {/* skill zone */}
        <div className="absolute left-0 right-0 bg-emerald-500/50" style={{ bottom: '32%', height: '16%' }} />
        <div
          className={`absolute bottom-0 left-0 right-0 transition-none ${power > 0.85 ? 'bg-gradient-to-t from-yellow-400 to-red-500' : 'bg-gradient-to-t from-cyan-500 to-fuchsia-400'}`}
          style={{ height: `${power * 100}%` }}
        />
      </div>
      <div className={`text-[11px] font-black ${charging ? 'animate-pulse text-cyan-300' : 'text-slate-400'}`}>
        {charging ? 'RELEASE!' : 'HOLD SPACE'}
      </div>
    </div>
  );
}

function ControlsBar() {
  const st = useGame.getState;
  const toggleMute = useGame((s) => s.toggleMute);
  const muted = useGame((s) => s.muted);
  const cycleCamera = useGame((s) => s.cycleCamera);
  const cameraMode = useGame((s) => s.cameraMode);
  const toggleShake = useGame((s) => s.toggleShake);
  const shakeEnabled = useGame((s) => s.shakeEnabled);
  const toggleHelp = useGame((s) => s.toggleHelp);
  const paused = useGame((s) => s.paused);
  const setPaused = useGame((s) => s.setPaused);
  const phase = useGame((s) => s.phase);
  void st;
  return (
    <div className="absolute top-24 sm:top-28 right-3 sm:right-4 z-30 flex flex-col gap-2">
      {[
        { icon: muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />, fn: toggleMute, label: muted ? 'Unmute' : 'Mute', active: !muted },
        { icon: <Camera className="h-4 w-4" />, fn: cycleCamera, label: `Cam: ${cameraMode}`, active: true },
        { icon: shakeEnabled ? <Vibrate className="h-4 w-4" /> : <VibrateOff className="h-4 w-4" />, fn: toggleShake, label: 'Shake', active: shakeEnabled },
        { icon: <CircleHelp className="h-4 w-4" />, fn: toggleHelp, label: 'Help', active: false },
      ].map((b, i) => (
        <button
          key={i}
          onClick={b.fn}
          title={b.label}
          className={`pointer-events-auto flex h-9 w-9 items-center justify-center rounded-lg border backdrop-blur-md transition-all hover:scale-105 active:scale-95 ${
            b.active ? 'border-cyan-400/40 bg-slate-900/80 text-cyan-300' : 'border-slate-700/60 bg-slate-900/80 text-slate-400'
          }`}
        >
          {b.icon}
        </button>
      ))}
      {phase === 'playing' && (
        <>
          <button
            onClick={() => useGame.getState().reserveBall()}
            title="Ball reset (B) — frees a stuck ball, no ball lost"
            className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-lg border border-amber-400/50 bg-slate-900/80 text-amber-300 backdrop-blur-md transition-all hover:scale-105 active:scale-95"
          >
            <LifeBuoy className="h-4 w-4" />
          </button>
          <button
            onClick={() => setPaused(!paused)}
            title={paused ? 'Resume' : 'Pause'}
            className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700/60 bg-slate-900/80 text-slate-300 backdrop-blur-md transition-all hover:scale-105 active:scale-95"
          >
            {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </button>
          <button
            onClick={() => useGame.getState().startGame()}
            title="Restart"
            className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700/60 bg-slate-900/80 text-slate-300 backdrop-blur-md transition-all hover:scale-105 active:scale-95"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </>
      )}
    </div>
  );
}

function KeyHints() {
  const leftPressed = useGame((s) => s.leftPressed);
  const rightPressed = useGame((s) => s.rightPressed);
  const plungerCharging = useGame((s) => s.plungerCharging);
  const phase = useGame((s) => s.phase);
  return (
    <div className="pointer-events-none absolute bottom-0 left-0 right-0 z-20 hidden justify-center pb-3 sm:flex">
      <div className="flex items-center gap-4 rounded-2xl border border-slate-700/50 bg-slate-950/75 px-5 py-2.5 backdrop-blur-md">
        <div className="flex items-center gap-1.5">
          <Kbd active={leftPressed}>Z</Kbd>
          <Kbd active={leftPressed}>◀</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">LEFT</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1.5">
          <Kbd active={rightPressed}>M</Kbd>
          <Kbd active={rightPressed}>▶</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">RIGHT</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1.5">
          <Kbd active={plungerCharging} wide>SPACE</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">PLUNGE</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1">
          <Kbd>A</Kbd><Kbd>W</Kbd><Kbd>D</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">NUDGE</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1.5">
          <Kbd>B</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">BALL RESET</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1">
          <Kbd>1</Kbd><Kbd>…</Kbd><Kbd>5</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">MODE</span>
        </div>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-1.5">
          <Kbd>⏎</Kbd>
          <span className="ml-1 text-[11px] font-bold text-slate-300">{phase === 'playing' ? 'START' : 'PLAY'}</span>
        </div>
      </div>
    </div>
  );
}

function TouchControls() {
  const phase = useGame((s) => s.phase);
  const ballPhase = useGame((s) => s.ballPhase);
  if (phase !== 'playing') return null;
  const setFlipper = useGame.getState().setFlipper;
  const press = (side: 'left' | 'right', v: boolean) => (e: React.PointerEvent) => {
    e.preventDefault();
    setFlipper(side, v);
  };
  const plungerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    if (ballPhase !== 'plunger') return;
    gameRef.plungerCharging = true;
    gameRef.plungerPower = 0;
    useGame.setState({ plungerCharging: true, plungerPower: 0 });
  };
  const plungerUp = (e: React.PointerEvent) => {
    e.preventDefault();
    if (!gameRef.plungerCharging) return;
    useGame.getState().releasePlunger();
  };
  return (
    <div className="absolute bottom-16 left-0 right-0 z-30 flex items-end justify-between px-4 sm:hidden">
      <button
        className="pointer-events-auto h-20 w-24 rounded-2xl border border-cyan-400/50 bg-cyan-500/20 text-2xl font-black text-cyan-200 backdrop-blur-md active:bg-cyan-400/50"
        onPointerDown={press('left', true)}
        onPointerUp={press('left', false)}
        onPointerLeave={press('left', false)}
        onPointerCancel={press('left', false)}
      >
        ◀
      </button>
      {ballPhase === 'plunger' ? (
        <button
          className="pointer-events-auto h-20 w-20 rounded-full border border-yellow-300/60 bg-yellow-500/25 text-xs font-black text-yellow-200 backdrop-blur-md active:bg-yellow-400/50"
          onPointerDown={plungerDown}
          onPointerUp={plungerUp}
          onPointerLeave={plungerUp}
          onPointerCancel={plungerUp}
        >
          HOLD<br />FIRE
        </button>
      ) : (
        <button
          className="pointer-events-auto h-14 w-14 rounded-full border border-slate-600 bg-slate-800/60 text-lg backdrop-blur-md active:bg-slate-600"
          onPointerDown={(e) => { e.preventDefault(); useGame.getState().nudge('up'); }}
        >
          👊
        </button>
      )}
      <button
        className="pointer-events-auto h-20 w-24 rounded-2xl border border-fuchsia-400/50 bg-fuchsia-500/20 text-2xl font-black text-fuchsia-200 backdrop-blur-md active:bg-fuchsia-400/50"
        onPointerDown={press('right', true)}
        onPointerUp={press('right', false)}
        onPointerLeave={press('right', false)}
        onPointerCancel={press('right', false)}
      >
        ▶
      </button>
    </div>
  );
}

function AttractScreen() {
  const phase = useGame((s) => s.phase);
  const highScore = useGame((s) => s.highScore);
  const selected = useGame((s) => s.difficulty);
  if (phase !== 'attract') return null;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-gradient-to-b from-slate-950/60 via-slate-950/40 to-slate-950/80 p-4">
      <div className="attract-in w-full max-w-2xl rounded-3xl border border-cyan-400/25 bg-slate-950/85 p-6 sm:p-10 text-center shadow-[0_0_80px_rgba(34,211,238,0.25)] backdrop-blur-xl">
        <div className="mb-1 text-[11px] font-black tracking-[0.5em] text-cyan-400">INSERT COIN • 3 BALLS</div>
        <h1 className="font-display text-5xl sm:text-7xl font-black leading-none tracking-tight">
          <span className="bg-gradient-to-b from-cyan-200 via-cyan-400 to-blue-600 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(34,211,238,0.5)]">NEON</span>{' '}
          <span className="bg-gradient-to-b from-fuchsia-200 via-fuchsia-400 to-purple-700 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(232,121,249,0.5)]">NOVA</span>
        </h1>
        <div className="mt-1 text-sm font-bold tracking-[0.35em] text-slate-400">★ PINBALL ★</div>

        <div className="mx-auto mt-5 flex max-w-md items-center justify-center gap-3 rounded-xl border border-amber-300/30 bg-amber-950/30 px-4 py-2">
          <Trophy className="h-4 w-4 text-amber-300" />
          <span className="text-xs font-bold tracking-widest text-amber-200/80">HIGH SCORE</span>
          <span className="font-display text-xl font-black text-amber-300 tabular-nums">{fmt(highScore)}</span>
        </div>

        <div className="mx-auto mt-5 max-w-xl text-left">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[10px] font-black tracking-[0.35em] text-slate-400">SELECT DIFFICULTY</span>
            <span className="text-[10px] font-bold text-slate-500">keys 1–5</span>
          </div>
          <DifficultyPicker />
          <div className="mt-2 text-center text-[11px] font-semibold text-slate-400" style={{ color: DIFFS[selected].accent }}>
            {DIFFS[selected].blurb}
          </div>
        </div>

        <div className="mx-auto mt-5 grid max-w-lg grid-cols-2 gap-2 text-left sm:grid-cols-3">
          {[
            { k: ['Z', '◀'], label: 'Left flipper' },
            { k: ['M', '▶'], label: 'Right flipper' },
            { k: ['SPACE'], label: 'Hold = plunge', wide: true },
            { k: ['A', 'W', 'D'], label: 'Nudge (tilt!)' },
            { k: ['B'], label: 'Ball reset' },
            { k: ['C'], label: 'Camera view' },
          ].map((r, i) => (
            <div key={i} className="rounded-lg border border-slate-700/60 bg-slate-900/60 px-2.5 py-2">
              <div className="flex gap-1">
                {r.k.map((k) => (
                  <span key={k} className="inline-flex h-6 min-w-6 items-center justify-center rounded border border-slate-600 bg-slate-800 px-1 text-[10px] font-black text-slate-100">{k}</span>
                ))}
              </div>
              <div className="mt-1 text-[11px] font-semibold text-slate-400">{r.label}</div>
            </div>
          ))}
        </div>

        <button
          onClick={() => useGame.getState().startGame()}
          className="group pointer-events-auto mt-6 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-fuchsia-500 px-8 py-3.5 font-display text-lg font-black tracking-wide text-white shadow-[0_0_35px_rgba(34,211,238,0.5)] transition-all hover:scale-105 hover:shadow-[0_0_50px_rgba(232,121,249,0.6)] active:scale-95"
        >
          <Play className="h-5 w-5 fill-current" /> PRESS ENTER / TAP TO PLAY
        </button>
        <div className="mt-3 animate-pulse text-xs font-bold tracking-widest text-cyan-300/80">HOLD SPACE • RELEASE IN GREEN FOR SKILL SHOT</div>
        <div className="mt-4 text-[11px] text-slate-500">Drop the DOORS to light kickback + 3X ramp • WORMHOLE for mystery awards • Chain shots for combos • L+R banks = MULTIBALL</div>
      </div>
    </div>
  );
}

function GameOverScreen() {
  const phase = useGame((s) => s.phase);
  const score = useGame((s) => s.score);
  const highScore = useGame((s) => s.highScore);
  const difficulty = useGame((s) => s.difficulty);
  if (phase !== 'gameover') return null;
  const isBest = score >= highScore && score > 0;
  const cfg = DIFFS[difficulty];
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-[2px]">
      <div className="attract-in w-full max-w-md rounded-3xl border border-fuchsia-400/30 bg-slate-950/90 p-8 text-center shadow-[0_0_60px_rgba(232,121,249,0.3)] backdrop-blur-xl">
        <div className="flex items-center justify-center gap-2 text-[11px] font-black tracking-[0.4em] text-fuchsia-400">
          GAME OVER
          <span className="rounded-full px-2 py-0.5 text-[10px] tracking-[0.2em]" style={{ color: cfg.accent, background: `${cfg.accent}1a`, border: `1px solid ${cfg.accent}55` }}>
            {cfg.label}{cfg.score !== 1 ? ` · ${cfg.score}X PTS` : ''}
          </span>
        </div>
        <div className="font-display mt-2 text-5xl font-black text-white tabular-nums drop-shadow-[0_0_20px_rgba(232,121,249,0.6)]">{fmt(score)}</div>
        {isBest ? (
          <div className="mx-auto mt-3 inline-flex animate-pulse items-center gap-2 rounded-full border border-yellow-300/50 bg-yellow-400/10 px-4 py-1.5 text-sm font-black text-yellow-300">
            <Trophy className="h-4 w-4" /> NEW HIGH SCORE!
          </div>
        ) : (
          <div className="mt-3 flex items-center justify-center gap-2 text-sm font-bold text-slate-400">
            <Trophy className="h-4 w-4 text-amber-400/70" /> Best: <span className="tabular-nums text-slate-200">{fmt(highScore)}</span>
          </div>
        )}
        <div className="mt-5 text-left">
          <div className="mb-1.5 text-[10px] font-black tracking-[0.3em] text-slate-500">RETRY ON A DIFFERENT TIER?</div>
          <DifficultyPicker compact />
        </div>
        <button
          onClick={() => useGame.getState().startGame()}
          className="pointer-events-auto mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-fuchsia-500 px-6 py-3 font-display text-base font-black text-white shadow-[0_0_30px_rgba(34,211,238,0.4)] transition-all hover:scale-[1.02] active:scale-95"
        >
          <RotateCcw className="h-4 w-4" /> PLAY AGAIN (ENTER)
        </button>
      </div>
    </div>
  );
}

function BonusOverlay() {
  const bonusCounting = useGame((s) => s.bonusCounting);
  const bonusDisplay = useGame((s) => s.bonusDisplay);
  const multiplier = useGame((s) => s.multiplier);
  if (!bonusCounting) return null;
  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
      <div className="rounded-2xl border border-slate-600/60 bg-slate-950/90 px-10 py-6 text-center backdrop-blur-xl shadow-2xl">
        <div className="text-[11px] font-black tracking-[0.4em] text-slate-400">BALL BONUS ×{multiplier}</div>
        <div className="font-display mt-1 text-4xl font-black text-cyan-300 tabular-nums">+{fmt(bonusDisplay)}</div>
      </div>
    </div>
  );
}

function StuckHint() {
  const stuckHint = useGame((s) => s.stuckHint);
  const phase = useGame((s) => s.phase);
  if (!stuckHint || phase !== 'playing') return null;
  return (
    <div className="pointer-events-none absolute bottom-40 left-0 right-0 z-30 flex justify-center px-4">
      <div className="pointer-events-auto flex items-center gap-3 rounded-xl border border-amber-300/60 bg-amber-950/85 px-4 py-2 backdrop-blur-md shadow-[0_0_28px_rgba(251,191,36,0.35)]">
        <LifeBuoy className="h-4 w-4 animate-pulse text-amber-300" />
        <span className="text-xs font-black tracking-widest text-amber-200">BALL STUCK?</span>
        <button
          onClick={() => useGame.getState().reserveBall()}
          className="rounded-lg bg-amber-400 px-3 py-1 text-[11px] font-black text-slate-950 transition hover:bg-amber-300 active:scale-95"
        >
          PRESS B TO RESET
        </button>
      </div>
    </div>
  );
}

function TiltFlash() {
  const tilted = useGame((s) => s.tilted);
  if (!tilted) return null;
  return <div className="tilt-flash pointer-events-none absolute inset-0 z-30 rounded-none" />;
}

function PausedOverlay() {
  const paused = useGame((s) => s.paused);
  const phase = useGame((s) => s.phase);
  if (!paused || phase !== 'playing') return null;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm">
      <div className="rounded-2xl border border-slate-600 bg-slate-900 px-10 py-8 text-center">
        <div className="font-display text-3xl font-black text-white">PAUSED</div>
        <div className="mt-2 text-sm text-slate-400">Press P to resume</div>
        <button onClick={() => useGame.getState().setPaused(false)} className="pointer-events-auto mt-4 rounded-xl bg-cyan-500 px-6 py-2 font-bold text-slate-950 hover:bg-cyan-400">
          RESUME
        </button>
      </div>
    </div>
  );
}

function HelpModal() {
  const show = useGame((s) => s.showHelp);
  const toggle = useGame((s) => s.toggleHelp);
  if (!show) return null;
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm" onClick={toggle}>
      <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-slate-600 bg-slate-900 p-6" onClick={(e) => e.stopPropagation()}>
        <h2 className="font-display text-2xl font-black text-white">HOW TO PLAY</h2>
        <div className="mt-4 space-y-3 text-sm text-slate-300">
          <p><b className="text-cyan-300">Flippers:</b> <Kbd>Z</Kbd> / <Kbd>◀</Kbd> left, <Kbd>M</Kbd> / <Kbd>▶</Kbd> right. Time your shots — late flips aim up the middle, early flips aim the sides.</p>
          <p><b className="text-cyan-300">Plunger:</b> hold <Kbd wide>SPACE</Kbd>, release in the <span className="font-bold text-emerald-400">green zone</span> then hit a top lane for a 15K SKILL SHOT.</p>
          <p><b className="text-cyan-300">Nudge:</b> <Kbd>A</Kbd> <Kbd>W</Kbd> <Kbd>D</Kbd> shoves the machine to save drains — but 4 nudges in 2.5s = <span className="font-bold text-red-400">TILT</span> (flippers die 5s).</p>
          <p><b className="text-cyan-300">Scoring:</b> pop bumpers build combos • <span className="text-emerald-400 font-bold">N-O-V lanes</span> raise multiplier to 5X • <span className="text-cyan-300 font-bold">L</span>+<span className="text-fuchsia-300 font-bold">R</span> banks start MULTIBALL (2X everything) • <span className="text-amber-300 font-bold">C</span> targets light the 25K JACKPOT scoop.</p>
          <p><b className="text-cyan-300">Ramp:</b> left-flipper shot up the cyan hoop rides the wire ramp (3,500 — 9,000 when doors have lit it).</p>
          <p><b className="text-fuchsia-300">Wormhole:</b> drop the ball in the magenta hole at mid-right for a pipe ride and a mystery award.</p>
          <p><b className="text-cyan-300">Doors:</b> three drop targets on the left. Knock all three down to light <b>kickback</b> (saves a left-lane drain) and a 3X ramp.</p>
          <p><b className="text-yellow-300">Combos:</b> chain different shots within 7s (ramp → tunnel → scoop…) for rising combo bonuses.</p>
          <p><b className="text-cyan-300">Upper level:</b> shots up either side climb onto the raised rear deck and its three lanes — a weak shot rolls back down.</p>
          <p><b className="text-amber-300">Stuck ball:</b> press <Kbd>B</Kbd> to re-serve the ball to the plunger. You keep your score and <i>don't</i> lose a ball. The machine also auto-kicks a resting ball after ~3s.</p>
          <p><b className="text-cyan-300">Difficulty</b> (<Kbd>1</Kbd>–<Kbd>5</Kbd> on the title screen): Super Easy → Impossible. Each tier scales gravity, launch power, bounciness and flipper snap, adds obstacles (Extra Bumpers → Top Posts → the spinning <b className="text-red-400">WRECKER</b> → kicking Frickies), and multiplies all points earned. The score you chase is tier-specific — Impossible pays 1.5x.</p>
          <p><b className="text-cyan-300">Extra balls</b> at 120K / 300K / 600K. <b className="text-cyan-300">Camera:</b> <Kbd>C</Kbd> cycles Auto / Broadcast / Top / Cinematic.</p>
        </div>
        <button onClick={toggle} className="pointer-events-auto mt-5 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-fuchsia-500 py-2.5 font-black text-white">GOT IT</button>
      </div>
    </div>
  );
}

export function HUD() {
  return (
    <>
      <TopBar />
      <StatusPanels />
      <ControlsBar />
      <MessageBar />
      <Popups />
      <BigMessage />
      <PlungerMeter />
      <KeyHints />
      <TouchControls />
      <BonusOverlay />
      <StuckHint />
      <TiltFlash />
      <AttractScreen />
      <GameOverScreen />
      <PausedOverlay />
      <HelpModal />
    </>
  );
}
