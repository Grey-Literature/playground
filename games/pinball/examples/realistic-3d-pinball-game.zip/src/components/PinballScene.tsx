import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { Environment, Lightformer, ContactShadows } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import {
  WALLS, BUMPERS, POSTS, TARGETS, SENSORS,
  LEFT_PIVOT, RIGHT_PIVOT, FLIPPER_LEN, FLIPPER_R,
  BALL_RADIUS, MAX_SPEED, PLUNGER_X,
  boardHeightAt, UPPER_DECK_HEIGHT,
  SLING_LEFT, SLING_RIGHT, RETURN_GUIDE_LEFT, RETURN_GUIDE_RIGHT,
  DROP_TARGETS, RAMP_PATH, TUNNEL_PATH, samplePath, PathPt,
  EXTRA_BUMPERS, TOP_POSTS, FRICKIES,
} from '../game/constants';
import { DIFF, WRECKER } from '../game/difficulty';
import { gameRef, useGame, spawnBallAt, isTilted } from '../game/store';
import { stepPhysics } from '../game/physics';
import { sound } from '../game/audio';

// ---------------- Playfield art ----------------
function makePlayfieldTexture(): THREE.CanvasTexture {
  const W = 1024, H = 1792;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d')!;
  // bg
  const bg = g.createRadialGradient(W/2, H*0.35, 100, W/2, H/2, 1200);
  bg.addColorStop(0, '#0d1440');
  bg.addColorStop(0.45, '#0a0f33');
  bg.addColorStop(1, '#04060f');
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);
  // stars
  for (let i = 0; i < 700; i++) {
    const x = Math.random()*W, y = Math.random()*H;
    const r = Math.random()*1.8+0.3;
    g.fillStyle = `rgba(${150+Math.random()*105|0},${170+Math.random()*85|0},255,${0.15+Math.random()*0.6})`;
    g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  // neon grid horizon
  g.save();
  g.globalAlpha = 0.5;
  for (let i = 0; i < 26; i++) {
    const y = H*0.12 + i*i*1.55;
    if (y > H) break;
    g.strokeStyle = i % 2 ? 'rgba(34,211,238,0.35)' : 'rgba(232,121,249,0.3)';
    g.lineWidth = i % 5 === 0 ? 3 : 1.5;
    g.beginPath(); g.moveTo(60, y); g.lineTo(W-60, y); g.stroke();
  }
  for (let i = 0; i <= 20; i++) {
    const x = 60 + (W-120)*i/20;
    g.strokeStyle = 'rgba(99,102,241,0.22)';
    g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(W/2+(x-W/2)*0.2, H*0.12); g.lineTo(x, H); g.stroke();
  }
  g.restore();
  // outer orbit ring
  g.save();
  g.strokeStyle = 'rgba(34,211,238,0.85)';
  g.lineWidth = 10;
  g.shadowColor = '#22d3ee'; g.shadowBlur = 30;
  g.beginPath();
  g.arc(W/2, H*0.245, W*0.40, Math.PI, 0);
  g.stroke();
  g.strokeStyle = 'rgba(232,121,249,0.7)';
  g.lineWidth = 5;
  g.shadowColor = '#e879f9'; g.shadowBlur = 24;
  g.beginPath();
  g.arc(W/2, H*0.245, W*0.40 - 26, Math.PI, 0);
  g.stroke();
  g.restore();
  // center sun
  const sunY = H*0.42;
  const sun = g.createLinearGradient(0, sunY-130, 0, sunY+130);
  sun.addColorStop(0, '#fde047');
  sun.addColorStop(0.45, '#fb7185');
  sun.addColorStop(1, '#7c3aed');
  g.save();
  g.shadowColor = '#fb7185'; g.shadowBlur = 60;
  g.fillStyle = sun;
  g.beginPath(); g.arc(W/2, sunY, 130, 0, 7); g.fill();
  g.restore();
  // sun slats
  g.fillStyle = '#0a0f33';
  for (let i = 0; i < 6; i++) {
    const y = sunY + 10 + i*20;
    g.fillRect(W/2-135, y, 270, 6+i*1.6);
  }
  // title
  g.save();
  g.textAlign = 'center';
  g.shadowColor = '#22d3ee'; g.shadowBlur = 34;
  g.fillStyle = '#e0faff';
  g.font = '900 92px "Arial Black", Arial, sans-serif';
  g.fillText('NEON', W/2, sunY - 170);
  g.shadowColor = '#e879f9';
  g.fillStyle = '#ffe4fb';
  g.fillText('NOVA', W/2, sunY - 84);
  g.restore();
  g.save();
  g.textAlign = 'center';
  g.fillStyle = 'rgba(224,250,255,0.75)';
  g.font = '700 30px Arial';
  g.fillText('•  PINBALL  •', W/2, sunY + 190);
  g.restore();
  // lane labels
  g.save();
  g.textAlign = 'center';
  g.font = '900 34px Arial';
  const laneY = 150;
  const labels = ['N', 'O', 'V'];
  const cols = ['#22d3ee', '#e879f9', '#fbbf24'];
  labels.forEach((t, i) => {
    const x = W/2 + (i-1)*150;
    g.shadowColor = cols[i]; g.shadowBlur = 22;
    g.strokeStyle = cols[i]; g.lineWidth = 3;
    g.beginPath(); g.arc(x, laneY, 44, 0, 7); g.stroke();
    g.fillStyle = '#ffffff';
    g.fillText(t, x, laneY+12);
  });
  g.fillStyle = 'rgba(255,255,255,0.55)';
  g.font = '700 22px Arial';
  g.shadowBlur = 0;
  g.fillText('LIGHT ALL 3 • MULTIPLIER', W/2, laneY + 78);
  g.restore();
  // bumper halos painted
  const bumperPos = [[W/2-150, H*0.30], [W/2+150, H*0.30], [W/2, H*0.245]];
  bumperPos.forEach(([x, y], i) => {
    const col = ['#22d3ee', '#e879f9', '#fbbf24'][i];
    g.save();
    g.strokeStyle = col; g.globalAlpha = 0.5;
    g.lineWidth = 4; g.shadowColor = col; g.shadowBlur = 20;
    g.beginPath(); g.arc(x, y, 86, 0, 7); g.stroke();
    g.restore();
  });
  // scoop label
  g.save();
  g.textAlign = 'center';
  g.fillStyle = '#fde047';
  g.shadowColor = '#fbbf24'; g.shadowBlur = 18;
  g.font = '900 30px Arial';
  g.fillText('JACKPOT', W*0.27, H*0.52);
  g.font = '700 22px Arial';
  g.fillStyle = 'rgba(253,224,71,0.7)';
  g.shadowBlur = 0;
  g.fillText('SCOOP', W*0.27, H*0.52 + 30);
  g.restore();
  // orbit label
  g.save();
  g.translate(72, H*0.32);
  g.rotate(-Math.PI/2);
  g.textAlign = 'center';
  g.fillStyle = 'rgba(34,211,238,0.8)';
  g.font = '900 28px Arial';
  g.fillText('O R B I T  •  1000', 0, 0);
  g.restore();
  // plunger lane art + skill zone
  const laneX = W*0.895;
  g.save();
  g.fillStyle = 'rgba(0,0,0,0.45)';
  g.fillRect(laneX - 52, H*0.30, 104, H*0.55);
  g.strokeStyle = 'rgba(148,163,184,0.5)';
  g.lineWidth = 3;
  g.strokeRect(laneX - 52, H*0.30, 104, H*0.55);
  // skill zone (lower-middle of lane = gentle launch)
  const sz1 = H*0.586, sz0 = H*0.674;
  const grad = g.createLinearGradient(0, sz1, 0, sz0);
  grad.addColorStop(0, '#22c55e');
  grad.addColorStop(1, '#15803d');
  g.fillStyle = grad;
  g.shadowColor = '#22c55e'; g.shadowBlur = 22;
  g.fillRect(laneX - 52, sz1, 104, sz0 - sz1);
  g.fillStyle = '#04140a';
  g.textAlign = 'center';
  g.font = '900 20px Arial';
  g.shadowBlur = 0;
  g.fillText('SKILL', laneX, (sz0+sz1)/2 + 2);
  g.fillText('SHOT', laneX, (sz0+sz1)/2 + 24);
  g.fillStyle = 'rgba(255,255,255,0.6)';
  g.font = '700 20px Arial';
  g.save();
  g.translate(laneX, H*0.88);
  g.rotate(0);
  g.fillText('PLUNGE', 0, 0);
  g.restore();
  g.restore();
  // bottom apron
  g.save();
  const apr = g.createLinearGradient(0, H*0.93, 0, H);
  apr.addColorStop(0, '#111a3a');
  apr.addColorStop(1, '#05070f');
  g.fillStyle = apr;
  g.fillRect(0, H*0.93, W, H*0.07);
  g.fillStyle = 'rgba(148,163,184,0.8)';
  g.textAlign = 'center';
  g.font = '700 24px Arial';
  g.fillText('NEON NOVA • BALL SAVE • 3 BALLS • TILT ENDS FUN', W/2, H*0.968);
  g.restore();
  // vignette edges
  const vg = g.createRadialGradient(W/2, H/2, H*0.3, W/2, H/2, H*0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.5)');
  g.fillStyle = vg;
  g.fillRect(0, 0, W, H);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function makeSideArt(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 1024;
  const g = c.getContext('2d')!;
  const grad = g.createLinearGradient(0, 0, 0, 1024);
  grad.addColorStop(0, '#1e1b4b');
  grad.addColorStop(0.5, '#0b0d20');
  grad.addColorStop(1, '#17122e');
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 1024);
  g.save();
  g.translate(128, 512);
  g.rotate(-Math.PI/2);
  g.textAlign = 'center';
  g.shadowColor = '#22d3ee'; g.shadowBlur = 26;
  g.fillStyle = '#e0faff';
  g.font = '900 84px "Arial Black", Arial';
  g.fillText('NEON NOVA', 0, 0);
  g.restore();
  for (let i = 0; i < 40; i++) {
    g.fillStyle = `hsla(${180+Math.random()*140},90%,60%,${0.12+Math.random()*0.25})`;
    g.fillRect(Math.random()*256, Math.random()*1024, 3, 20+Math.random()*80);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeLevelBadgeTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 640;
  c.height = 128;
  const g = c.getContext('2d')!;
  g.fillStyle = '#071426';
  g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = '#22d3ee';
  g.lineWidth = 7;
  g.strokeRect(5, 5, c.width - 10, c.height - 10);
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.shadowColor = '#22d3ee';
  g.shadowBlur = 18;
  g.fillStyle = '#e0faff';
  g.font = '900 62px Arial';
  g.fillText('LEVEL 02  /  NOVA HIGHWAY', c.width / 2, c.height / 2);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// coordinate helpers: physics (x,y) -> world (x, 0, -y)
const PX = (x: number) => x;
const PZ = (y: number) => -y;

type TrackPoint = { x: number; y: number; h: number };

function trackCurve(points: TrackPoint[], offset = 0) {
  const shifted = points.map((p, i) => {
    const before = points[Math.max(0, i - 1)];
    const after = points[Math.min(points.length - 1, i + 1)];
    const dx = after.x - before.x;
    const dy = after.y - before.y;
    const length = Math.hypot(dx, dy) || 1;
    const nx = -dy / length;
    const ny = dx / length;
    return new THREE.Vector3(p.x + nx * offset, p.h, PZ(p.y + ny * offset));
  });
  return new THREE.CatmullRomCurve3(shifted, false, 'centripetal', 0.2);
}

function makeTrackTube(points: TrackPoint[], radius: number, offset = 0) {
  const curve = trackCurve(points, offset);
  return new THREE.TubeGeometry(curve, Math.max(24, points.length * 18), radius, 10, false);
}

// Ribbon with self-limiting edge offsets: instead of Gaussian simplification,
// we collapse the ribbon wide enough that the smooth CR centerline can never
// cut through its own edge walls (mirrors the physics corridor exactly).
function makeTrackRibbon(points: TrackPoint[], halfWidth: number, edgeHalfWidth = halfWidth) {
  const curve = trackCurve(points, 0);
  const left = trackCurve(points, -edgeHalfWidth);
  const right = trackCurve(points, edgeHalfWidth);
  const segments = 96;
  const positions: number[] = [];
  const indices: number[] = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const c = curve.getPoint(t);
    const l = left.getPoint(t);
    const r = right.getPoint(t);
    positions.push((l.x + c.x) / 2, (l.y + c.y) / 2, (l.z + c.z) / 2);
    positions.push((r.x + c.x) / 2, (r.y + c.y) / 2, (r.z + c.z) / 2);
    if (i < segments) {
      const a = i * 2;
      indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function makeTrackSurface(points: TrackPoint[], halfWidth: number) {
  // plain offset ribbon (no corners): used for the flat spiral ramp
  const curve = trackCurve(points);
  const segments = 72;
  const positions: number[] = [];
  const indices: number[] = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const center = curve.getPoint(t);
    const tangent = curve.getTangent(t);
    const horizontalLength = Math.hypot(tangent.x, tangent.z) || 1;
    const nx = -tangent.z / horizontalLength;
    const nz = tangent.x / horizontalLength;
    positions.push(center.x + nx * halfWidth, center.y, center.z + nz * halfWidth);
    positions.push(center.x - nx * halfWidth, center.y, center.z - nz * halfWidth);
    if (i < segments) {
      const a = i * 2;
      indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

// ---------------- Physics loop + events ----------------
function PhysicsLoop() {
  const rollRef = useRef(0);
  useFrame((_, rawDt) => {
    const dt = Math.min(rawDt, 1 / 30);
    const st = useGame.getState();
    if (st.paused) { sound.setRoll(0); return; }

    if (st.phase === 'attract') {
      gameRef.left.pressed = Math.sin(gameRef.time * 5.1) > 0.1;
      gameRef.right.pressed = Math.sin(gameRef.time * 4.3 + 1.3) > 0.1;
      const act = gameRef.balls.filter(b => b.active);
      if (act.length === 0) {
        spawnBallAt((Math.random()-0.5)*16, 22, (Math.random()-0.5)*90, -30);
      }
      // keep demo ball from settling: gentle kick if slow at top
      for (const b of act) {
        if (Math.hypot(b.vx, b.vy) < 12 && b.y > -10) {
          b.vx += (Math.random()-0.5)*60;
          b.vy += 60;
        }
      }
    } else if (st.phase === 'playing') {
      if (gameRef.plungerCharging && st.ballPhase === 'plunger') {
        gameRef.plungerPower = Math.min(1, gameRef.plungerPower + dt * 0.8);
        sound.plungerTick(gameRef.plungerPower);
        useGame.setState({ plungerPower: gameRef.plungerPower });
      }
      // weak launch fell back into the lane? allow re-plunge instead of a stuck ball
      if (st.ballPhase === 'active' && !st.bonusCounting) {
        const laneBall = gameRef.balls.find(
          (b) => b.active && b.autoLaunch === undefined && b.captured <= 0 && !b.ride && b.inLane && b.y < -27 && Math.hypot(b.vx, b.vy) < 22
        );
        if (laneBall) {
          useGame.setState({ ballPhase: 'plunger', message: 'WEAK LAUNCH — PLUNGE AGAIN', messageT: Date.now() });
        }
      }
      if (st.multiball) st.tickMultiball(dt);
    }

    const events = stepPhysics(dt);

    if (st.phase === 'playing') {
      for (const e of events) {
        switch (e.type) {
          case 'bumper': st.onBumper(Number(e.id), gameRef.bumperCombo); break;
          case 'sling': st.onSling(String(e.id)); break;
          case 'post': st.onPost(); break;
          case 'target': st.onTarget(String(e.id)); break;
          case 'lane': {
            const idx = Number(String(e.id).replace('lane', ''));
            st.onLane(idx);
            break;
          }
          case 'inlane': st.onInlane(String(e.id)); break;
          case 'scoop': st.onScoop(); break;
          case 'scoopEject': st.onScoopEject(); break;
          case 'spinner': st.onSpinner(); break;
          case 'orbit': st.onOrbit(); break;
          case 'drop': st.onDrop(Number(e.id)); break;
          case 'ramp': st.onRamp(); break;
          case 'rampEject': st.onRampEject(); break;
          case 'tunnel': st.onTunnel(); break;
          case 'tunnelEject': st.onTunnelEject(); break;
          case 'drain': st.onDrain(Number(e.id)); break;
          case 'laneLaunch':
            sound.launch(1);
            gameRef.shake = Math.min(1, gameRef.shake + 0.25);
            useGame.setState({ ballsInPlay: gameRef.balls.filter(b => b.active).length, ballPhase: 'active' });
            break;
        }
      }
    } else {
      // attract: still flash lights on events
      for (const e of events) {
        if (e.type === 'bumper') gameRef.flashes.bumpers[Number(e.id)] = 1;
        if (e.type === 'sling') {
          if (String(e.id).includes('L')) gameRef.flashes.slingL = 1;
          else gameRef.flashes.slingR = 1;
        }
      }
    }

    // rolling sound
    let maxSp = 0;
    for (const b of gameRef.balls) {
      if (!b.active || b.captured > 0 || b.ride) continue;
      maxSp = Math.max(maxSp, Math.hypot(b.vx, b.vy));
    }

    // ---- stuck-ball watchdog: kick first, re-serve if the kick doesn't help ----
    if (st.phase === 'playing' && !st.paused) {
      const live = useGame.getState();
      const actives = gameRef.balls.filter((b) => b.active);
      const busy = actives.some((b) => b.captured > 0 || !!b.ride || b.autoLaunch !== undefined);
      // A ball cradled on a flipper or parked in the shooter lane is legitimate —
      // only balls that stall out in the field count toward a ball search.
      const stalledInField = actives.some((b) => {
        if (Math.hypot(b.vx, b.vy) >= 9) return false;
        if (b.x > 16.5) return false;
        if (b.y < -28.5 && Math.abs(b.x) < 12.5) return false;
        return true;
      });
      const settled =
        actives.length > 0 && !busy && live.ballPhase === 'active' && !live.bonusCounting && stalledInField;
      if (settled) {
        gameRef.stuckTimer += dt;
        if (gameRef.stuckTimer > 1.5 && !live.stuckHint) useGame.setState({ stuckHint: true });
        if (gameRef.stuckTimer > 3) {
          gameRef.stuckTimer = 0;
          gameRef.searchCount += 1;
          if (gameRef.searchCount >= 3) live.reserveBall();
          else live.ballSearch();
        }
      } else if (gameRef.stuckTimer !== 0 || gameRef.searchCount !== 0) {
        gameRef.stuckTimer = 0;
        gameRef.searchCount = 0;
        if (live.stuckHint) useGame.setState({ stuckHint: false });
      }
    }
    rollRef.current += ((maxSp / MAX_SPEED) - rollRef.current) * Math.min(1, dt * 6);
    sound.setRoll(st.phase === 'playing' ? rollRef.current : rollRef.current * 0.4);
  });
  return null;
}

// ---------------- Camera ----------------
function CameraRig() {
  const { camera } = useThree();
  const pos = useRef(new THREE.Vector3(0, 72, 50));
  const look = useRef(new THREE.Vector3(0, 0, -3));
  const tmpLook = useRef(new THREE.Vector3());
  useFrame((state, dt) => {
    const st = useGame.getState();
    const mode = st.cameraMode;
    const t = state.clock.elapsedTime;
    // follow target = average active ball
    let bx = 0, by = -6, n = 0;
    for (const b of gameRef.balls) {
      if (!b.active) continue;
      bx += b.x; by += b.y; n++;
    }
    if (n > 0) { bx /= n; by /= n; }
    bx = THREE.MathUtils.clamp(bx, -14, 14);
    by = THREE.MathUtils.clamp(by, -34, 30);

    let tp = tmpLook.current; // reuse
    void tp;
    const targetPos = new THREE.Vector3();
    const targetLook = new THREE.Vector3();
    if (mode === 'broadcast') {
      targetPos.set(0, 76, 52);
      targetLook.set(0, 0, -3);
    } else if (mode === 'top') {
      targetPos.set(0, 108, 10);
      targetLook.set(0, 0, 0);
    } else if (mode === 'cinematic') {
      const a = t * 0.18;
      targetPos.set(Math.sin(a) * 30, 60 + Math.sin(t * 0.4) * 7, 46 + Math.cos(a) * 9);
      targetLook.set(bx * 0.3, 0, -4 - by * 0.1);
    } else {
      // auto
      targetPos.set(bx * 0.22, 71 - (by + 6) * 0.14, 49);
      targetLook.set(bx * 0.34, 0, -3.5 - by * 0.2);
    }
    const k = 1 - Math.exp(-3.2 * Math.min(dt, 0.05));
    pos.current.lerp(targetPos, k);
    look.current.lerp(targetLook, k);
    // shake
    let sx = 0, sy = 0, sz = 0;
    const trauma = st.shakeEnabled ? gameRef.shake : gameRef.shake * 0.25;
    if (trauma > 0.001) {
      const s = trauma * trauma * 3.2;
      sx = (Math.random() - 0.5) * 2 * s;
      sy = (Math.random() - 0.5) * 2 * s * 0.6;
      sz = (Math.random() - 0.5) * 2 * s;
    }
    camera.position.set(pos.current.x + sx, pos.current.y + sy, pos.current.z + sz);
    camera.lookAt(look.current.x + sx * 0.5, look.current.y, look.current.z + sz * 0.3);
  });
  return null;
}

// ---------------- Playfield base + walls ----------------
function PlayfieldBase({ art }: { art: THREE.CanvasTexture }) {
  return (
    <group>
      {/* top art plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 1]} receiveShadow>
        <planeGeometry args={[47, 82]} />
        <meshStandardMaterial map={art} roughness={0.32} metalness={0.25} />
      </mesh>
      {/* base body */}
      <mesh position={[0, -1.2, 1]} receiveShadow>
        <boxGeometry args={[47.6, 2.4, 82.6]} />
        <meshStandardMaterial color="#0b0e1e" roughness={0.7} metalness={0.3} />
      </mesh>
      {/* plunger lane separator cap (metal rail top), matching the divider wall */}
      <mesh position={[17, 1.5, PZ(-10.5)]} castShadow>
        <boxGeometry args={[0.7, 3, 55]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.25} metalness={0.95} />
      </mesh>
      {/* lane floor slightly raised? */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[19.5, 0.04, PZ(-8)]}>
        <planeGeometry args={[4.6, 60]} />
        <meshStandardMaterial color="#020617" roughness={0.5} metalness={0.4} />
      </mesh>
    </group>
  );
}

function Walls() {
  const items = useMemo(() => {
    return WALLS.map((w) => {
      const dx = w.bx - w.ax, dy = w.by - w.ay;
      const len = Math.hypot(dx, dy);
      const mx = (w.ax + w.bx) / 2, my = (w.ay + w.by) / 2;
      const rotY = Math.atan2(dy, dx);
      return { ...w, len, mx, my, rotY };
    });
  }, []);
  return (
    <group>
      {items.map((w) => {
        const isSling = w.kind === 'sling';
        if (isSling) return null; // sling edges are drawn with the sling assemblies
        const h = w.id?.startsWith('arc') || w.id?.startsWith('outer') || w.id === 'divider' ? 3.2 : 2.4;
        const color = w.id === 'divider' ? '#94a3b8' : w.kind === 'guide' ? '#38bdf8' : '#e2e8f0';
        const metal = w.id === 'divider' || w.kind === 'wall' ? 0.9 : 0.4;
        return (
          <mesh
            key={w.id}
            position={[PX(w.mx), h / 2, PZ(w.my)]}
            rotation={[0, w.rotY, 0]}
            castShadow
            receiveShadow
          >
            <boxGeometry args={[w.len + 0.7, h, 0.75]} />
            <meshStandardMaterial color={color} roughness={0.3} metalness={metal} />
          </mesh>
        );
      })}
      {/* divider top cap post */}
      <mesh position={[17, 1.2, PZ(17)]} castShadow>
        <cylinderGeometry args={[0.55, 0.55, 2.6, 16]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.3} metalness={0.6} />
      </mesh>
    </group>
  );
}

function triangleGeo(ax: number, ay: number, bx: number, by: number, cx: number, cy: number, depth: number) {
  const shape = new THREE.Shape();
  shape.moveTo(ax, ay);
  shape.lineTo(bx, by);
  shape.lineTo(cx, cy);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelThickness: 0.12, bevelSize: 0.12, bevelSegments: 2 });
  return geo;
}

function Slings() {
  const L = SLING_LEFT, R = SLING_RIGHT;
  const leftGeo = useMemo(() => triangleGeo(L[0][0], L[0][1], L[1][0], L[1][1], L[2][0], L[2][1], 1.5), [L]);
  const rightGeo = useMemo(() => triangleGeo(R[0][0], R[0][1], R[1][0], R[1][1], R[2][0], R[2][1], 1.5), [R]);
  const matL = useRef<THREE.MeshStandardMaterial>(null!);
  const matR = useRef<THREE.MeshStandardMaterial>(null!);
  const lightL = useRef<THREE.PointLight>(null!);
  const lightR = useRef<THREE.PointLight>(null!);
  useFrame(() => {
    const fl = gameRef.flashes.slingL;
    const fr = gameRef.flashes.slingR;
    if (matL.current) matL.current.emissiveIntensity = 0.5 + fl * 5;
    if (matR.current) matR.current.emissiveIntensity = 0.5 + fr * 5;
    if (lightL.current) lightL.current.intensity = 2 + fl * 40;
    if (lightR.current) lightR.current.intensity = 2 + fr * 40;
  });
  return (
    <group>
      <mesh geometry={leftGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]} castShadow>
        <meshStandardMaterial ref={matL} color="#f1f5f9" roughness={0.35} metalness={0.1} emissive="#ef4444" emissiveIntensity={0.5} />
      </mesh>
      <mesh geometry={rightGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]} castShadow>
        <meshStandardMaterial ref={matR} color="#f1f5f9" roughness={0.35} metalness={0.1} emissive="#ef4444" emissiveIntensity={0.5} />
      </mesh>
      {/* rubber edge trim along the kicking faces */}
      {[
        { a: L[1], b: L[2] },
        { a: L[2], b: L[0] },
        { a: R[1], b: R[2] },
        { a: R[2], b: R[0] },
      ].map((e, i) => {
        const dx = e.b[0] - e.a[0], dy = e.b[1] - e.a[1];
        const len = Math.hypot(dx, dy);
        const mx = (e.a[0] + e.b[0]) / 2, my = (e.a[1] + e.b[1]) / 2;
        return (
          <mesh key={i} position={[mx, 1.35, -my]} rotation={[0, Math.atan2(dy, dx), 0]}>
            <boxGeometry args={[len, 0.5, 0.5]} />
            <meshStandardMaterial color="#dc2626" roughness={0.6} />
          </mesh>
        );
      })}
      <pointLight ref={lightL} position={[L[2][0], 4, PZ(L[2][1])]} color="#ef4444" intensity={2} distance={18} />
      <pointLight ref={lightR} position={[R[2][0], 4, PZ(R[2][1])]} color="#ef4444" intensity={2} distance={18} />
    </group>
  );
}

// ---------------- Bumpers ----------------
const BUMPER_COLORS = ['#22d3ee', '#e879f9', '#fbbf24', '#4ade80', '#f472b6'];
function activeBumperList() {
  return DIFF.ob.extraBumpers ? [...BUMPERS, ...EXTRA_BUMPERS] : BUMPERS;
}
function Bumpers() {
  useGame((s) => s.difficulty); // re-render when the tier swaps obstacles in/out
  const mats = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  const caps = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  const lights = useRef<(THREE.PointLight | null)[]>([]);
  const groups = useRef<(THREE.Group | null)[]>([]);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const n = activeBumperList().length;
    for (let i = 0; i < n; i++) {
      const fl = gameRef.flashes.bumpers[i];
      const pulse = 0.5 + Math.sin(t * 3 + i * 2.1) * 0.15;
      if (mats.current[i]) mats.current[i]!.emissiveIntensity = pulse + fl * 6;
      if (caps.current[i]) caps.current[i]!.emissiveIntensity = 0.4 + fl * 4;
      if (lights.current[i]) lights.current[i]!.intensity = 4 + fl * 90;
      if (groups.current[i]) {
        const s = 1 + fl * 0.12;
        groups.current[i]!.scale.set(s, 1, s);
      }
    }
  });
  return (
    <group>
      {activeBumperList().map((b, i) => (
        <group key={b.id} position={[PX(b.x), 0, PZ(b.y)]}>
          {/* base shadow ring */}
          <mesh position={[0, 0.12, 0]} receiveShadow>
            <cylinderGeometry args={[b.r + 0.7, b.r + 0.9, 0.24, 32]} />
            <meshStandardMaterial color="#020617" roughness={0.6} />
          </mesh>
          <group ref={(el) => { groups.current[i] = el; }}>
            {/* skirt */}
            <mesh position={[0, 0.75, 0]} castShadow>
              <cylinderGeometry args={[b.r + 0.15, b.r + 0.45, 1.3, 32]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.35} />
            </mesh>
            {/* body */}
            <mesh position={[0, 1.7, 0]} castShadow>
              <cylinderGeometry args={[b.r - 0.25, b.r + 0.1, 1.5, 32]} />
              <meshStandardMaterial
                ref={(el) => { mats.current[i] = el; }}
                color="#ffffff"
                roughness={0.25}
                emissive={BUMPER_COLORS[i]}
                emissiveIntensity={0.6}
              />
            </mesh>
            {/* cap */}
            <mesh position={[0, 2.7, 0]} castShadow>
              <cylinderGeometry args={[b.r - 0.7, b.r - 0.25, 0.7, 32]} />
              <meshStandardMaterial
                ref={(el) => { caps.current[i] = el; }}
                color="#0f172a"
                roughness={0.2}
                metalness={0.4}
                emissive={BUMPER_COLORS[i]}
                emissiveIntensity={0.4}
              />
            </mesh>
            {/* top jewel */}
            <mesh position={[0, 3.15, 0]}>
              <sphereGeometry args={[0.7, 16, 16]} />
              <meshStandardMaterial color="#ffffff" emissive={BUMPER_COLORS[i]} emissiveIntensity={2.2} roughness={0.15} />
            </mesh>
          </group>
          <pointLight
            ref={(el) => { lights.current[i] = el; }}
            position={[0, 4.5, 0]}
            color={BUMPER_COLORS[i]}
            intensity={4}
            distance={26}
            decay={1.8}
          />
        </group>
      ))}
    </group>
  );
}

// ---------------- Posts / targets / inserts ----------------
function Posts() {
  useGame((s) => s.difficulty);
  const list = DIFF.ob.topPosts ? [...POSTS, ...TOP_POSTS] : POSTS;
  return (
    <group>
      {list.map((p) => (
        <group key={p.id} position={[PX(p.x), boardHeightAt(p.x, p.y), PZ(p.y)]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <cylinderGeometry args={[0.28, 0.28, 2.2, 12]} />
            <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.25} />
          </mesh>
          <mesh position={[0, 1.5, 0]}>
            <torusGeometry args={[p.r, 0.32, 10, 20]} />
            <meshStandardMaterial color={String(p.id).startsWith('lane') ? '#fbbf24' : '#f43f5e'} roughness={0.55} />
          </mesh>
          <mesh position={[0, 2.3, 0]}>
            <sphereGeometry args={[0.34, 12, 12]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Targets() {
  const leftTargets = useGame((s) => s.leftTargets);
  const rightTargets = useGame((s) => s.rightTargets);
  const centerTargets = useGame((s) => s.centerTargets);
  const mats = useRef<Record<string, THREE.MeshStandardMaterial | null>>({});
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const tilted = isTilted();
    for (const tg of TARGETS) {
      const m = mats.current[String(tg.id)];
      if (!m) continue;
      const id = String(tg.id);
      let lit = false;
      if (id[0] === 'L') lit = leftTargets[Number(id[1])];
      else if (id[0] === 'R') lit = rightTargets[Number(id[1])];
      else lit = centerTargets[Number(id[1])];
      const fl = gameRef.flashes.targets[id] ?? 0;
      const base = lit ? 2.6 : 0.5 + Math.sin(t * 2 + id.charCodeAt(0)) * 0.12;
      m.emissiveIntensity = (tilted ? 1.2 : base) + fl * 5;
      if (tilted) m.emissive.set('#ef4444');
      else if (id[0] === 'L') m.emissive.set('#22d3ee');
      else if (id[0] === 'R') m.emissive.set('#e879f9');
      else m.emissive.set('#fbbf24');
    }
  });
  return (
    <group>
      {TARGETS.map((tg) => {
        const id = String(tg.id);
        const faceLeft = id[0] === 'L'; // left bank faces right (toward center)
        const rotY = id[0] === 'C' ? 0 : faceLeft ? Math.PI / 2 : -Math.PI / 2;
        return (
          <group key={id} position={[PX(tg.x), 0, PZ(tg.y)]} rotation={[0, rotY, 0]}>
            <mesh position={[0, 1.35, 0]} castShadow>
              <boxGeometry args={[0.7, 2.5, 2.1]} />
              <meshStandardMaterial color="#0f172a" roughness={0.5} />
            </mesh>
            <mesh position={[0.42, 1.35, 0]}>
              <boxGeometry args={[0.12, 2.1, 1.7]} />
              <meshStandardMaterial
                ref={(el) => { mats.current[id] = el; }}
                color="#111827"
                emissive={id[0] === 'L' ? '#22d3ee' : id[0] === 'R' ? '#e879f9' : '#fbbf24'}
                emissiveIntensity={0.6}
                roughness={0.3}
              />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

function LaneInserts() {
  const lanes = useGame((s) => s.lanes);
  const mats = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const tilted = isTilted();
    SENSORS.filter((s) => s.kind === 'lane').forEach((_sn, i) => {
      void _sn;
      const m = mats.current[i];
      if (!m) return;
      const lit = lanes[i];
      const fl = gameRef.flashes.lanes[i];
      if (tilted) {
        m.emissive.set('#ef4444');
        m.emissiveIntensity = 1.5 + Math.sin(t * 20) * 1.2;
      } else {
        m.emissive.set(lit ? '#22c55e' : '#1e293b');
        m.emissiveIntensity = (lit ? 2.4 + Math.sin(t * 4) * 0.3 : 0.35) + fl * 5;
      }
    });
  });
  return (
    <group>
      {SENSORS.filter((s) => s.kind === 'lane').map((sn, i) => (
        <group key={sn.id} position={[PX(sn.x), boardHeightAt(sn.x, sn.y), PZ(sn.y)]}>
          <mesh position={[0, 0.1, 0]}>
            <cylinderGeometry args={[sn.r, sn.r, 0.18, 24]} />
            <meshStandardMaterial
              ref={(el) => { mats.current[i] = el; }}
              color="#020617"
              emissive="#22c55e"
              emissiveIntensity={0.4}
              roughness={0.4}
            />
          </mesh>
          <mesh position={[0, 0.22, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[sn.r - 0.25, sn.r + 0.15, 24]} />
            <meshStandardMaterial color="#e2e8f0" emissive="#ffffff" emissiveIntensity={0.25} roughness={0.4} />
          </mesh>
        </group>
      ))}
      {/* orbit insert */}
      <OrbitInsert />
      {/* inlane inserts */}
      {SENSORS.filter((s) => s.kind === 'inlane').map((sn) => (
        <mesh key={sn.id} position={[PX(sn.x), 0.09, PZ(sn.y)]}>
          <cylinderGeometry args={[1.1, 1.1, 0.16, 20]} />
          <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={0.7} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function OrbitInsert() {
  const mat = useRef<THREE.MeshStandardMaterial>(null!);
  const light = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const fl = gameRef.flashes.orbit;
    if (mat.current) mat.current.emissiveIntensity = 0.8 + Math.sin(t * 2.5) * 0.3 + fl * 6;
    if (light.current) light.current.intensity = 3 + fl * 50;
  });
  const sn = SENSORS.find((s) => s.id === 'orbitL')!;
  return (
    <group position={[PX(sn.x), 0, PZ(sn.y)]}>
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[1.5, 1.5, 0.18, 24]} />
        <meshStandardMaterial ref={mat} color="#020617" emissive="#22d3ee" emissiveIntensity={1} />
      </mesh>
      <pointLight ref={light} position={[0, 3, 0]} color="#22d3ee" intensity={3} distance={20} />
    </group>
  );
}

function Scoop() {
  const jackpotLit = useGame((s) => s.jackpotLit);
  const mat = useRef<THREE.MeshStandardMaterial>(null!);
  const light = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const fl = gameRef.flashes.scoop + gameRef.flashes.jackpot * 0.7;
    if (mat.current) {
      mat.current.emissive.set(jackpotLit ? '#fbbf24' : '#22d3ee');
      mat.current.emissiveIntensity = (jackpotLit ? 2.5 + Math.sin(t * 8) * 1.5 : 0.9 + Math.sin(t * 2) * 0.25) + fl * 5;
    }
    if (light.current) {
      light.current.color.set(jackpotLit ? '#fbbf24' : '#22d3ee');
      light.current.intensity = (jackpotLit ? 14 + Math.sin(t * 8) * 8 : 4) + fl * 60;
    }
  });
  const sn = SENSORS.find((s) => s.kind === 'scoop')!;
  return (
    <group position={[PX(sn.x), 0, PZ(sn.y)]}>
      <mesh position={[0, 0.12, 0]}>
        <cylinderGeometry args={[sn.r, sn.r, 0.22, 28]} />
        <meshStandardMaterial color="#000000" roughness={0.9} />
      </mesh>
      <mesh position={[0, 0.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[sn.r - 0.15, sn.r + 0.45, 28]} />
        <meshStandardMaterial ref={mat} color="#111827" emissive="#22d3ee" emissiveIntensity={1} roughness={0.3} metalness={0.5} />
      </mesh>
      <pointLight ref={light} position={[0, 3.5, 0]} color="#22d3ee" intensity={4} distance={22} />
    </group>
  );
}

function Spinner() {
  const blade = useRef<THREE.Group>(null!);
  const mat = useRef<THREE.MeshStandardMaterial>(null!);
  useFrame(() => {
    if (blade.current) blade.current.rotation.y = gameRef.spinnerAngle;
    if (mat.current) mat.current.emissiveIntensity = 0.8 + gameRef.flashes.spinner * 5;
  });
  const sn = SENSORS.find((s) => s.kind === 'spinner')!;
  return (
    <group position={[PX(sn.x), 0, PZ(sn.y)]}>
      {/* posts */}
      {[[-2.4, 0], [2.4, 0]].map(([ox], i) => (
        <mesh key={i} position={[ox, 1.6, 0]} castShadow>
          <cylinderGeometry args={[0.3, 0.3, 3.2, 12]} />
          <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.25} />
        </mesh>
      ))}
      <mesh position={[0, 3.2, 0]}>
        <boxGeometry args={[5.4, 0.3, 0.5]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.8} roughness={0.3} />
      </mesh>
      <group ref={blade} position={[0, 1.7, 0]}>
        <mesh castShadow>
          <boxGeometry args={[4.4, 2.4, 0.18]} />
          <meshStandardMaterial
            ref={mat}
            color="#f97316"
            emissive="#f97316"
            emissiveIntensity={0.8}
            roughness={0.35}
            transparent
            opacity={0.92}
          />
        </mesh>
        <mesh position={[0, 0, 0.12]}>
          <boxGeometry args={[4.4, 0.4, 0.02]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={1.2} />
        </mesh>
      </group>
    </group>
  );
}

// A raised rear deck and two climbing ramps make the upper playfield a visible,
// navigable part of the machine rather than painted artwork.
function RaisedUpperLevel() {
  const badge = useMemo(() => makeLevelBadgeTexture(), []);
  const leftRamp: TrackPoint[] = useMemo(() => Array.from({ length: 9 }, (_, i) => {
    const t = i / 8;
    const x = -14.4 + t * 5;
    const y = 18.5 + t * 7.5;
    return { x, y, h: boardHeightAt(x, y) };
  }), []);
  const rightRamp: TrackPoint[] = useMemo(
    () => leftRamp.map((p) => ({ ...p, x: -p.x })),
    [leftRamp],
  );
  const leftSurface = useMemo(() => makeTrackSurface(leftRamp, 1.8), [leftRamp]);
  const rightSurface = useMemo(() => makeTrackSurface(rightRamp, 1.8), [rightRamp]);
  const rampRails = useMemo(() => [leftRamp, rightRamp].flatMap((path, index) => {
    const raised = path.map((p) => ({ ...p, h: p.h + 0.55 }));
    return [
      { key: `${index}-outer`, geometry: makeTrackTube(raised, 0.2, -1.72) },
      { key: `${index}-inner`, geometry: makeTrackTube(raised, 0.2, 1.72) },
    ];
  }), [leftRamp, rightRamp]);

  return (
    <group>
      {/* four steel stanchions supporting the rear mini-playfield */}
      {[-8.7, 8.7].flatMap((x) => [26.2, 32.7].map((y) => (
        <group key={`deck-support-${x}-${y}`} position={[x, 0, PZ(y)]}>
          <mesh position={[0, UPPER_DECK_HEIGHT / 2, 0]} castShadow>
            <cylinderGeometry args={[0.28, 0.4, UPPER_DECK_HEIGHT, 16]} />
            <meshStandardMaterial color="#a8b6c8" metalness={0.9} roughness={0.24} />
          </mesh>
          <mesh position={[0, 0.2, 0]}>
            <cylinderGeometry args={[0.72, 0.8, 0.3, 16]} />
            <meshStandardMaterial color="#1e293b" metalness={0.75} roughness={0.3} />
          </mesh>
        </group>
      )))}

      {/* solid elevated deck, raised enough for the ball to visibly roll above the base */}
      <mesh position={[0, UPPER_DECK_HEIGHT - 0.32, PZ(29.45)]} castShadow receiveShadow>
        <boxGeometry args={[19.6, 0.64, 8.1]} />
        <meshStandardMaterial color="#10182c" roughness={0.32} metalness={0.55} emissive="#071b36" emissiveIntensity={0.6} />
      </mesh>
      <mesh position={[0, UPPER_DECK_HEIGHT + 0.015, PZ(29.45)]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[18.9, 7.35]} />
        <meshStandardMaterial color="#10172a" roughness={0.28} metalness={0.28} />
      </mesh>
      <mesh position={[0, UPPER_DECK_HEIGHT + 0.055, PZ(26.35)]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[5.3, 1.05]} />
        <meshBasicMaterial map={badge} toneMapped={false} />
      </mesh>

      {/* three separated metal guide channels on the raised deck */}
      {[-9.45, 9.45].map((x) => (
        <mesh key={`upper-side-rail-${x}`} position={[x, UPPER_DECK_HEIGHT + 0.7, PZ(29.45)]}>
          <boxGeometry args={[0.42, 1.05, 8.05]} />
          <meshStandardMaterial color="#dbeafe" metalness={0.92} roughness={0.2} emissive="#1e3a5f" emissiveIntensity={0.5} />
        </mesh>
      ))}
      {[-3.12, 3.12].map((x, i) => (
        <group key={`upper-channel-${i}`}>
          <mesh position={[x, UPPER_DECK_HEIGHT + 0.38, PZ(29.45)]}>
            <boxGeometry args={[0.22, 0.76, 7.25]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.2} />
          </mesh>
          <mesh position={[x + 0.2, UPPER_DECK_HEIGHT + 0.79, PZ(29.45)]}>
            <boxGeometry args={[0.09, 0.08, 7.1]} />
            <meshStandardMaterial color="#ffffff" emissive={i === 0 ? '#22d3ee' : '#e879f9'} emissiveIntensity={1.6} toneMapped={false} />
          </mesh>
        </group>
      ))}

      {/* colored lane beds sit above the deck and align with the rollover sensors */}
      {[
        { x: -6.2, color: '#063d53', glow: '#22d3ee' },
        { x: 0, color: '#32133f', glow: '#e879f9' },
        { x: 6.2, color: '#3f300b', glow: '#fbbf24' },
      ].map((lane) => (
        <group key={`lane-bed-${lane.x}`} position={[lane.x, UPPER_DECK_HEIGHT + 0.08, PZ(29.45)]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[5.65, 6.65]} />
            <meshStandardMaterial color={lane.color} emissive={lane.glow} emissiveIntensity={0.22} roughness={0.32} metalness={0.35} />
          </mesh>
          <mesh position={[0, 0.05, 0]}>
            <boxGeometry args={[5.45, 0.08, 0.12]} />
            <meshStandardMaterial color="#ffffff" emissive={lane.glow} emissiveIntensity={1.2} toneMapped={false} />
          </mesh>
        </group>
      ))}

      {/* two open-top ramps lead from the lower playfield onto the raised deck */}
      {[leftSurface, rightSurface].map((geometry, i) => (
        <mesh key={`ramp-surface-${i}`} geometry={geometry} castShadow receiveShadow>
          <meshStandardMaterial color="#243650" roughness={0.3} metalness={0.72} emissive="#123c58" emissiveIntensity={0.5} side={THREE.DoubleSide} />
        </mesh>
      ))}
      {rampRails.map((rail) => (
        <mesh key={rail.key} geometry={rail.geometry} castShadow>
          <meshStandardMaterial color="#e2e8f0" metalness={0.95} roughness={0.16} emissive="#164e63" emissiveIntensity={0.65} />
        </mesh>
      ))}

      {/* cross-braced ramp supports */}
      {[-1, 1].flatMap((side) => [
        { x: side * 12.2, y: 22.8 },
        { x: side * 10.5, y: 24.7 },
      ].map((p, i) => {
        const h = boardHeightAt(p.x, p.y);
        return (
        <mesh key={`ramp-post-${side}-${i}`} position={[p.x, h / 2, PZ(p.y)]} castShadow>
          <cylinderGeometry args={[0.14, 0.2, h, 12]} />
          <meshStandardMaterial color="#718096" metalness={0.9} roughness={0.25} />
        </mesh>
      );
      }))}
    </group>
  );
}

// Wireform rails tracing the real return-guide collision paths, so what the player
// sees is exactly what the ball rolls along.
function LowerChannels() {
  const rails = useMemo(() => {
    const paths: [number, number][][] = [RETURN_GUIDE_LEFT, RETURN_GUIDE_RIGHT];
    return paths.flatMap((path, i) => {
      const pts: TrackPoint[] = path.map(([x, y]) => ({ x, y, h: 1.25 }));
      return [
        { key: `${i}-top`, tube: makeTrackTube(pts, 0.17), tone: i === 0 },
        { key: `${i}-low`, tube: makeTrackTube(pts.map((p) => ({ ...p, h: 0.35 })), 0.13), tone: i === 0 },
      ];
    });
  }, []);

  return (
    <group>
      {rails.map((rail) => (
        <mesh key={`lower-channel-${rail.key}`} geometry={rail.tube} castShadow>
          <meshStandardMaterial
            color="#b9c7d9"
            metalness={0.94}
            roughness={0.2}
            emissive={rail.tone ? '#0e7490' : '#312e81'}
            emissiveIntensity={0.55}
          />
        </mesh>
      ))}
    </group>
  );
}

function DropDoors() {
  const groups = useRef<(THREE.Group | null)[]>([]);
  const mats = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  useFrame((_, dt) => {
    for (let i = 0; i < 3; i++) {
      const g = groups.current[i];
      const m = mats.current[i];
      if (!g) continue;
      const down = gameRef.dropDown[i];
      const target = down ? Math.PI / 2 : 0;
      g.rotation.z += (target - g.rotation.z) * Math.min(1, dt * 14);
      if (m) {
        const fl = gameRef.flashes.drops[i];
        m.emissiveIntensity = (down ? 0.15 : 1.4) + fl * 5;
      }
    }
  });
  return (
    <group>
      {DROP_TARGETS.map((t, i) => (
        <group key={t.id} position={[PX(t.x), 0.15, PZ(t.y)]}>
          <mesh position={[0, 1.2, 0]}>
            <boxGeometry args={[0.5, 2.5, 2.05]} />
            <meshStandardMaterial color="#0f172a" roughness={0.45} metalness={0.4} />
          </mesh>
          <group ref={(el) => { groups.current[i] = el; }} position={[0.28, 0.15, 0]}>
            <mesh position={[0.08, 1.15, 0]} castShadow>
              <boxGeometry args={[0.22, 2.2, 1.85]} />
              <meshStandardMaterial
                ref={(el) => { mats.current[i] = el; }}
                color="#1e293b"
                emissive="#22d3ee"
                emissiveIntensity={1.4}
                roughness={0.28}
                metalness={0.35}
              />
            </mesh>
            <mesh position={[0.2, 1.15, 0]}>
              <boxGeometry args={[0.04, 1.6, 0.12]} />
              <meshStandardMaterial color="#ffffff" emissive="#e0faff" emissiveIntensity={1.6} toneMapped={false} />
            </mesh>
          </group>
        </group>
      ))}
    </group>
  );
}

// Glowing dots trailing the ball while it rides a capture path — the "speed"
// feel inside pipes and along the wire ramp.
function RideTrail({ path, kind, color, r }: { path: PathPt[]; kind: 'ramp' | 'tunnel'; color: string; r: number }) {
  const refs = useRef<(THREE.Mesh | null)[]>([]);
  const N = 6;
  useFrame(() => {
    const ball = gameRef.balls.find((b) => b.active && b.ride && b.ride.kind === kind);
    for (let i = 0; i < N; i++) {
      const m = refs.current[i];
      if (!m) continue;
      if (!ball || !ball.ride) {
        m.visible = false;
        continue;
      }
      const tt = ball.ride.t - i * 0.035;
      if (tt <= 0) {
        m.visible = false;
        continue;
      }
      m.visible = true;
      const p = samplePath(path, tt);
      m.position.set(PX(p.x), p.h + BALL_RADIUS + 0.12, PZ(p.y));
      const s = (1 - i / N) * r;
      m.scale.setScalar(Math.max(0.25, s));
    }
  });
  return (
    <group>
      {Array.from({ length: N }).map((_, i) => (
        <mesh key={i} ref={(el) => { refs.current[i] = el; }} visible={false}>
          <sphereGeometry args={[1, 12, 12]} />
          <meshBasicMaterial color={color} transparent opacity={0.85 - i * 0.12} toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}

function NovaRamp() {
  // Wide-spaced side rails leave room for the ball to visibly travel the wire.
  const rail2 = useMemo(() => {
    const raised = RAMP_PATH.map((p) => ({ ...p, h: p.h + 0.45 }));
    return {
      a: makeTrackTube(raised, 0.14, -1.7),
      b: makeTrackTube(raised, 0.14, 1.7),
    };
  }, []);
  const cross = useMemo(() => {
    const raised = RAMP_PATH.map((p) => ({ ...p, h: p.h - 0.15 }));
    return makeTrackTube(raised, 0.34, 0);
  }, []);
  const bedRib = useMemo(() => makeTrackRibbon(RAMP_PATH, 1.35), []);
  const glow = useRef<THREE.MeshStandardMaterial>(null!);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const fl = gameRef.flashes.ramp;
    const lit = useGame.getState().rampLit;
    if (glow.current) glow.current.emissiveIntensity = (lit ? 2.2 + Math.sin(t * 8) * 0.8 : 0.7) + fl * 5;
  });
  const enter = RAMP_PATH[0];
  const supports = useMemo(() => [0.28, 0.52, 0.74, 0.9].map((t) => samplePath(RAMP_PATH, t)), []);
  return (
    <group>
      {/* translucent glowing bed — ball stays visible while riding */}
      <mesh geometry={bedRib} receiveShadow>
        <meshStandardMaterial
          ref={glow}
          color="#0b3a4a"
          roughness={0.25}
          metalness={0.55}
          emissive="#22d3ee"
          emissiveIntensity={0.7}
          side={THREE.DoubleSide}
          transparent
          opacity={0.55}
        />
      </mesh>
      {/* underside spine */}
      <mesh geometry={cross} castShadow>
        <meshStandardMaterial color="#164e63" metalness={0.9} roughness={0.2} emissive="#155e75" emissiveIntensity={0.8} />
      </mesh>
      {/* guard rails */}
      <mesh geometry={rail2.a} castShadow>
        <meshStandardMaterial color="#f8fafc" metalness={0.95} roughness={0.14} />
      </mesh>
      <mesh geometry={rail2.b} castShadow>
        <meshStandardMaterial color="#f8fafc" metalness={0.95} roughness={0.14} />
      </mesh>
      {/* support stanchions down to the playfield */}
      {supports.map((p, i) => (
        <mesh key={i} position={[PX(p.x), p.h / 2, PZ(p.y)]} castShadow>
          <cylinderGeometry args={[0.16, 0.24, p.h, 10]} />
          <meshStandardMaterial color="#7dd3fc" metalness={0.9} roughness={0.25} emissive="#0c4a6e" emissiveIntensity={0.5} />
        </mesh>
      ))}
      {/* entrance hoop */}
      <mesh position={[PX(enter.x), 1.9, PZ(enter.y)]} rotation={[0, 0.25, Math.PI / 2]}>
        <torusGeometry args={[1.85, 0.18, 10, 26]} />
        <meshStandardMaterial color="#22d3ee" emissive="#22d3ee" emissiveIntensity={2.6} toneMapped={false} />
      </mesh>
      <pointLight position={[PX(enter.x), 3, PZ(enter.y)]} color="#22d3ee" intensity={9} distance={16} />
      <RideTrail path={RAMP_PATH} kind="ramp" color="#67e8f9" r={1.15} />
    </group>
  );
}

function Wormhole() {
  const pipe = useMemo(() => makeTrackTube(TUNNEL_PATH.map((p) => ({ ...p, h: p.h + 0.9 })), 1.05, 0), []);
  const glow = useRef<THREE.MeshStandardMaterial>(null!);
  const hole = useRef<THREE.MeshStandardMaterial>(null!);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const fl = gameRef.flashes.tunnel;
    if (glow.current) glow.current.emissiveIntensity = 0.9 + Math.sin(t * 3) * 0.3 + fl * 5;
    if (hole.current) hole.current.emissiveIntensity = 1.2 + fl * 4;
  });
  const enter = TUNNEL_PATH[0];
  const exit = TUNNEL_PATH[TUNNEL_PATH.length - 1];
  return (
    <group>
      <mesh geometry={pipe} castShadow>
        <meshStandardMaterial
          ref={glow}
          color="#2e1065"
          roughness={0.22}
          metalness={0.7}
          emissive="#a21caf"
          emissiveIntensity={0.9}
          transparent
          opacity={0.72}
        />
      </mesh>
      {[enter, exit].map((p, i) => (
        <group key={i} position={[PX(p.x), 0.08, PZ(p.y)]}>
          <mesh>
            <cylinderGeometry args={[1.7, 1.7, 0.22, 24]} />
            <meshStandardMaterial ref={i === 0 ? hole : undefined} color="#020617" emissive="#e879f9" emissiveIntensity={1.2} />
          </mesh>
          <mesh position={[0, 0.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[1.35, 1.9, 24]} />
            <meshStandardMaterial color="#111827" emissive={i === 0 ? '#e879f9' : '#22d3ee'} emissiveIntensity={1.8} toneMapped={false} />
          </mesh>
        </group>
      ))}
      {/* glowing energy orb riding inside the pipe (the ball itself is hidden) */}
      <RideTrail path={TUNNEL_PATH} kind="tunnel" color="#f0abfc" r={0.85} />
      <pointLight position={[PX(enter.x), 3, PZ(enter.y)]} color="#e879f9" intensity={10} distance={14} />
    </group>
  );
}

// ---------------- Difficulty obstacles ----------------
function Wrecker() {
  useGame((s) => s.difficulty); // remount when the tier toggles this obstacle
  const bar = useRef<THREE.Group>(null!);
  const glow = useRef<THREE.MeshStandardMaterial>(null!);
  const light = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    if (!DIFF.ob.wrecker) return;
    if (bar.current) bar.current.rotation.y = WRECKER.angle;
    const t = state.clock.elapsedTime;
    const rpm = WRECKER.speedFor(DIFF.id);
    if (glow.current) glow.current.emissiveIntensity = 1.4 + Math.sin(t * rpm * 4) * 0.8;
    if (light.current) light.current.intensity = 10 + Math.sin(t * rpm * 4) * 6;
  });
  if (!DIFF.ob.wrecker) return null;
  const len = WRECKER.half * 2 + WRECKER.r * 2;
  return (
    <group position={[PX(WRECKER.cx), 0.7, PZ(WRECKER.cy)]}>
      <group ref={bar}>
        <mesh castShadow>
          <boxGeometry args={[len, 0.9, 0.9]} />
          <meshStandardMaterial
            ref={glow}
            color="#7f1d1d"
            metalness={0.85}
            roughness={0.28}
            emissive="#ef4444"
            emissiveIntensity={1.4}
          />
        </mesh>
        {/* hazard caps */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * (len / 2 - 0.4), 0, 0]} castShadow>
            <sphereGeometry args={[WRECKER.r + 0.28, 14, 14]} />
            <meshStandardMaterial color="#facc15" emissive="#f59e0b" emissiveIntensity={1.6} metalness={0.5} roughness={0.3} />
          </mesh>
        ))}
      </group>
      {/* hub */}
      <mesh position={[0, 0.55, 0]}>
        <cylinderGeometry args={[0.9, 1.05, 1.6, 18]} />
        <meshStandardMaterial color="#1e293b" metalness={0.9} roughness={0.3} />
      </mesh>
      <mesh position={[0, 1.5, 0]}>
        <cylinderGeometry args={[0.4, 0.4, 0.4, 14]} />
        <meshStandardMaterial color="#f43f5e" emissive="#f43f5e" emissiveIntensity={2} toneMapped={false} />
      </mesh>
      <pointLight ref={light} position={[0, 3.4, 0]} color="#ef4444" intensity={10} distance={26} />
    </group>
  );
}

function Frickies() {
  useGame((s) => s.difficulty);
  const groups = useRef<(THREE.Group | null)[]>([]);
  useFrame(() => {
    if (!DIFF.ob.frickies) return;
    for (let i = 0; i < FRICKIES.length; i++) {
      const g = groups.current[i];
      if (g) g.position.y = Math.sin(performance.now() * 0.008 + i) * 0.12;
    }
  });
  if (!DIFF.ob.frickies) return null;
  return (
    <group>
      {FRICKIES.map((f, i) => (
        <group key={f.id} position={[PX(f.x), 0, PZ(f.y)]}>
          <group ref={(el) => { groups.current[i] = el; }}>
            <mesh position={[0, 1.2, 0]} castShadow>
              <cylinderGeometry args={[0.28, 0.28, 2.4, 12]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.25} />
            </mesh>
            {/* spring coil */}
            <mesh position={[0, 0.7, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.5, 0.14, 8, 18]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.3} />
            </mesh>
            <mesh position={[0, 2.35, 0]} castShadow>
              <sphereGeometry args={[0.75, 16, 16]} />
              <meshStandardMaterial color="#f43f5e" emissive="#be123c" emissiveIntensity={0.8} roughness={0.5} />
            </mesh>
          </group>
        </group>
      ))}
    </group>
  );
}

// ---------------- Flippers ----------------
function makeFlipperGeometry(length: number, radius: number, depth: number) {
  const shape = new THREE.Shape();
  shape.moveTo(0, -radius);
  shape.lineTo(length, -radius);
  shape.absarc(length, 0, radius, -Math.PI / 2, Math.PI / 2, false);
  shape.lineTo(0, radius);
  shape.absarc(0, 0, radius, Math.PI / 2, Math.PI * 1.5, false);
  shape.closePath();
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.12,
    bevelSegments: 3,
    curveSegments: 18,
  });
  geometry.computeVertexNormals();
  return geometry;
}

function Flippers() {
  const leftG = useRef<THREE.Group>(null!);
  const rightG = useRef<THREE.Group>(null!);
  const batGeometry = useMemo(() => makeFlipperGeometry(FLIPPER_LEN, FLIPPER_R * 0.78, 1.05), []);
  useFrame(() => {
    if (leftG.current) leftG.current.rotation.y = gameRef.left.angle;
    if (rightG.current) rightG.current.rotation.y = gameRef.right.angle;
  });
  const bat = (ref: React.Ref<THREE.Group>, pivot: { x: number; y: number }, flip: boolean) => (
    <group ref={ref} position={[PX(pivot.x), 0.35, PZ(pivot.y)]}>
      {/* pivot housing */}
      <mesh position={[0, 0.06, 0]} castShadow>
        <cylinderGeometry args={[1.12, 1.3, 0.72, 24]} />
        <meshStandardMaterial color="#1e293b" roughness={0.4} metalness={0.6} />
      </mesh>
      <mesh position={[0, 0.48, 0]}>
        <cylinderGeometry args={[0.62, 0.62, 0.32, 20]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.95} roughness={0.2} />
      </mesh>
      {/* bat */}
      <mesh geometry={batGeometry} position={[0, 0.38, 0]} rotation={[-Math.PI / 2, 0, 0]} castShadow receiveShadow>
        <meshStandardMaterial color={flip ? '#f43f5e' : '#fb923c'} roughness={0.27} metalness={0.16} emissive={flip ? '#9f1239' : '#9a3412'} emissiveIntensity={0.8} />
      </mesh>
      {/* bright inlay makes both paddles readable from the playfield camera */}
      <mesh position={[FLIPPER_LEN * 0.52, 1.48, 0]}>
        <boxGeometry args={[FLIPPER_LEN * 0.64, 0.08, 0.28]} />
        <meshStandardMaterial color="#fff7ed" emissive={flip ? '#fda4af' : '#fed7aa'} emissiveIntensity={1.5} toneMapped={false} />
      </mesh>
      {/* exposed pivot bolts */}
      {[-0.58, 0.58].map((z, i) => (
        <mesh key={i} position={[0, 0.51, z]}>
          <cylinderGeometry args={[0.12, 0.12, 0.08, 12]} />
          <meshStandardMaterial color="#f8fafc" metalness={1} roughness={0.16} />
        </mesh>
      ))}
    </group>
  );
  return (
    <group>
      {bat(leftG, LEFT_PIVOT, false)}
      {bat(rightG, RIGHT_PIVOT, true)}
    </group>
  );
}

// ---------------- Balls ----------------
function Balls() {
  const meshes = useRef<(THREE.Mesh | null)[]>([]);
  const light = useRef<THREE.PointLight>(null!);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  void dummy;
  useFrame((_, dt) => {
    const act = gameRef.balls.filter((b) => b.active);
    for (let i = 0; i < 4; i++) {
      const m = meshes.current[i];
      if (!m) continue;
      const b = act[i];
      if (!b) {
        m.visible = false;
        continue;
      }
      // In a subway the ball disappears into the pipe — the energy trail shows it.
      m.visible = !(b.ride && b.ride.kind === 'tunnel');
      const sunk = b.captured > 0 ? 0.9 : 0;
      if (b.ride) {
        m.position.set(PX(b.x), (b.h ?? 0) + BALL_RADIUS + 0.12, PZ(b.y));
      } else {
        // ease the elevation so climbing a ramp reads as a roll, not a teleport
        const targetH = boardHeightAt(b.x, b.y);
        b.h = (b.h ?? targetH) + (targetH - (b.h ?? targetH)) * Math.min(1, dt * 11);
        m.position.set(PX(b.x), b.h + BALL_RADIUS + 0.12 - sunk, PZ(b.y));
      }
      // rolling rotation
      const wx = -b.vy / BALL_RADIUS; // world vz = -vy
      const wz = b.vx / BALL_RADIUS;
      m.rotation.x += wx * dt * 0.55;
      m.rotation.z += -wz * dt * 0.55;
      if (i === 0 && light.current) {
        light.current.position.set(PX(b.x), (b.h ?? 0) + 6, PZ(b.y));
        const sp = Math.hypot(b.vx, b.vy);
        light.current.intensity = 6 + Math.min(20, sp * 0.08);
      }
    }
    if (act.length === 0 && light.current) light.current.intensity = 0;
  });
  return (
    <group>
      {[0, 1, 2, 3].map((i) => (
        <mesh
          key={i}
          ref={(el) => { meshes.current[i] = el; }}
          castShadow
        >
          <sphereGeometry args={[BALL_RADIUS, 32, 32]} />
          <meshStandardMaterial color="#f8fafc" metalness={1} roughness={0.06} envMapIntensity={1.6} />
        </mesh>
      ))}
      <pointLight ref={light} color="#bfd9ff" intensity={8} distance={30} decay={1.8} />
    </group>
  );
}

// ---------------- Plunger ----------------
function Plunger() {
  const rod = useRef<THREE.Group>(null!);
  const spring = useRef<THREE.Group>(null!);
  const powerMats = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  const springTube = useMemo(() => {
    // helix along Z
    const pts: THREE.Vector3[] = [];
    const turns = 9, segs = 140, r = 0.75, len = 7;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      const a = t * turns * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, t * len));
    }
    const curve = new THREE.CatmullRomCurve3(pts);
    return new THREE.TubeGeometry(curve, 200, 0.16, 8, false);
  }, []);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const p = gameRef.plungerPower;
    const charging = gameRef.plungerCharging;
    if (rod.current) rod.current.position.z = p * 4.2;
    if (spring.current) {
      spring.current.scale.z = 1 - p * 0.5;
      spring.current.position.z = p * 4.2 * 0.4;
    }
    for (let i = 0; i < 10; i++) {
      const m = powerMats.current[i];
      if (!m) continue;
      const lit = charging && p * 10 > i;
      const inSkill = i >= 3 && i <= 4;
      if (!charging && gameRef.balls.some((b) => b.active && b.inLane && b.y < -20)) {
        // idle pulse hint
        m.emissiveIntensity = 0.25 + Math.sin(t * 3 + i * 0.5) * 0.15;
        m.emissive.set(inSkill ? '#22c55e' : '#334155');
      } else if (lit) {
        m.emissive.set(inSkill ? '#22c55e' : i > 7 ? '#ef4444' : '#fbbf24');
        m.emissiveIntensity = 2.5 + (inSkill ? Math.sin(t * 10) * 1 : 0);
      } else {
        m.emissive.set('#1e293b');
        m.emissiveIntensity = 0.4;
      }
    }
  });
  return (
    <group>
      {/* power meter lights along lane */}
      {Array.from({ length: 10 }).map((_, i) => (
        <mesh key={i} position={[16.1, 0.12, PZ(-14 + i * 2.2)]}>
          <boxGeometry args={[1.1, 0.2, 1.5]} />
          <meshStandardMaterial
            ref={(el) => { powerMats.current[i] = el; }}
            color="#020617"
            emissive="#334155"
            emissiveIntensity={0.4}
          />
        </mesh>
      ))}
      {/* rod + tip (tip below ball, rod extends out the front) */}
      <group position={[PLUNGER_X, 1.1, PZ(-36.5)]}>
        <group ref={rod}>
          <mesh position={[0, 0, 10]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.32, 0.32, 20, 12]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.95} roughness={0.2} />
          </mesh>
          <mesh position={[0, 0, 0.8]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[1.1, 1.1, 1.1, 20]} />
            <meshStandardMaterial color="#dc2626" roughness={0.5} />
          </mesh>
          {/* spring (outside cabinet, visible) */}
          <group ref={spring} position={[0, 0, 13]}>
            <mesh geometry={springTube} rotation={[0, 0, 0]}>
              <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.3} />
            </mesh>
          </group>
          {/* handle outside */}
          <mesh position={[0, 0, 20.5]}>
            <sphereGeometry args={[1.5, 20, 20]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0, 20.5]}>
            <torusGeometry args={[1.5, 0.25, 10, 24]} />
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.8} />
          </mesh>
        </group>
      </group>
    </group>
  );
}

// ---------------- DMD (dot matrix display) ----------------
function DMD() {
  const mesh = useRef<THREE.Mesh>(null!);
  const canvas = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 512; c.height = 160;
    return c;
  }, []);
  const tex = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [canvas]);
  const acc = useRef(0);
  useFrame((state, dt) => {
    acc.current += dt;
    if (acc.current < 0.08) return;
    acc.current = 0;
    const st = useGame.getState();
    const g = canvas.getContext('2d')!;
    const t = state.clock.elapsedTime;
    // bg
    g.fillStyle = '#080302';
    g.fillRect(0, 0, 512, 160);
    // scanline glow
    const orange = '#ffb000';
    const dim = '#7a4a00';
    g.textAlign = 'left';
    if (st.phase === 'attract') {
      g.fillStyle = orange;
      g.shadowColor = orange; g.shadowBlur = 12;
      g.font = '900 52px "Courier New", monospace';
      g.fillText('NEON NOVA', 30, 62);
      g.font = '700 24px "Courier New", monospace';
      g.fillStyle = Math.sin(t * 4) > 0 ? orange : dim;
      g.fillText('> PRESS ENTER TO START <', 40, 108);
      g.fillStyle = dim;
      g.font = '700 20px "Courier New", monospace';
      g.fillText(`HIGH ${st.highScore.toLocaleString().padStart(9, ' ')}`, 40, 140);
      g.fillStyle = DIFF.accent;
      g.textAlign = 'right';
      g.fillText(`MODE ${DIFF.label}`, 486, 140);
      g.textAlign = 'left';
      // animated equalizer
      for (let i = 0; i < 24; i++) {
        const h = 6 + Math.abs(Math.sin(t * 3 + i * 0.6)) * 22;
        g.fillStyle = i % 3 === 0 ? '#ff5c00' : orange;
        g.fillRect(30 + i * 19, 150 - h, 12, h);
      }
    } else if (st.phase === 'gameover') {
      g.fillStyle = orange;
      g.shadowColor = orange; g.shadowBlur = 12;
      g.font = '900 46px "Courier New", monospace';
      g.fillText('GAME OVER', 110, 62);
      g.font = '700 30px "Courier New", monospace';
      g.fillText(`${st.score.toLocaleString()}`, 150, 104);
      g.fillStyle = Math.sin(t * 4) > 0 ? orange : dim;
      g.font = '700 20px "Courier New", monospace';
      g.fillText('PRESS ENTER - PLAY AGAIN', 110, 138);
    } else {
      // playing
      if (st.ballPhase === 'bonus' || st.bonusCounting) {
        g.fillStyle = orange;
        g.shadowColor = orange; g.shadowBlur = 10;
        g.font = '900 30px "Courier New", monospace';
        g.fillText('BONUS', 30, 48);
        g.font = '900 44px "Courier New", monospace';
        g.fillText(`${st.bonusDisplay.toLocaleString()}`, 200, 52);
        g.font = '700 22px "Courier New", monospace';
        g.fillStyle = dim;
        g.fillText(`BALL ${st.ball}  x${st.multiplier}`, 30, 92);
        g.fillStyle = orange;
        g.fillText(`TOTAL ${st.score.toLocaleString()}`, 30, 126);
      } else {
        const tilted = isTilted();
        g.fillStyle = tilted && Math.sin(t * 16) > 0 ? '#ff2200' : orange;
        g.shadowColor = orange; g.shadowBlur = 10;
        g.font = '900 56px "Courier New", monospace';
        g.fillText(st.score.toLocaleString().padStart(9, ' '), 24, 64);
        g.font = '700 22px "Courier New", monospace';
        g.fillStyle = '#ff7a00';
        g.fillText(`BALL ${st.ball}/${st.totalBalls}`, 30, 100);
        g.fillText(`x${st.multiball ? st.multiplier * 2 : st.multiplier}${st.multiball ? ' 2X MB!' : ''}`, 250, 100);
        if (st.multiball) {
          g.fillStyle = '#22c55e';
          const w = (st.multiballT / DIFF.mbTime) * 200;
          g.fillRect(250, 110, w, 10);
        }
        g.fillStyle = dim;
        g.font = '700 19px "Courier New", monospace';
        const msg = (st.bigMessage || st.message).slice(0, 34);
        g.fillText(msg, 30, 136);
        if (tilted) {
          g.fillStyle = '#ff2200';
          g.font = '900 30px "Courier New", monospace';
          g.fillText('!! TILT !!', 330, 136);
        }
      }
      // high
      g.fillStyle = '#5b3a00';
      g.font = '700 16px "Courier New", monospace';
      g.textAlign = 'right';
      g.fillText(`HI ${st.highScore.toLocaleString()}`, 492, 24);
      g.textAlign = 'left';
    }
    // dot matrix overlay
    g.fillStyle = 'rgba(0,0,0,0.28)';
    for (let y = 0; y < 160; y += 3) g.fillRect(0, y, 512, 1);
    for (let x = 0; x < 512; x += 3) g.fillRect(x, 0, 1, 160);
    tex.needsUpdate = true;
  });
  return (
    <mesh ref={mesh} position={[0, 16.5, -36.1]}>
      <planeGeometry args={[34, 10.6]} />
      <meshBasicMaterial map={tex} toneMapped={false} />
    </mesh>
  );
}

// ---------------- Cabinet ----------------
function Cabinet({ sideArt }: { sideArt: THREE.CanvasTexture }) {
  const topperMat = useRef<THREE.MeshStandardMaterial>(null!);
  const topperLight = useRef<THREE.PointLight>(null!);
  const jackpotMat = useRef<THREE.MeshStandardMaterial>(null!);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const st = useGame.getState();
    const mb = st.multiball;
    const jp = gameRef.flashes.jackpot;
    if (topperMat.current) {
      const hue = mb ? (t * 2) % 1 : 0.55 + Math.sin(t * 1.5) * 0.08;
      topperMat.current.emissive.setHSL(mb ? hue : 0.52, 0.9, 0.55);
      topperMat.current.emissiveIntensity = (mb ? 3 : 1.6) + jp * 4;
    }
    if (topperLight.current) {
      topperLight.current.intensity = (mb ? 30 : 12) + jp * 60 + Math.sin(t * 6) * 4;
      if (mb) topperLight.current.color.setHSL((t * 2) % 1, 0.9, 0.6);
      else topperLight.current.color.set('#22d3ee');
    }
    if (jackpotMat.current) {
      jackpotMat.current.emissiveIntensity = st.jackpotLit ? 2.5 + Math.sin(t * 8) * 1.5 : 0.3;
    }
  });
  return (
    <group>
      {/* side rails */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 25.2, 2, 1]} castShadow receiveShadow>
            <boxGeometry args={[3, 6.5, 87]} />
            <meshStandardMaterial map={sideArt} roughness={0.5} metalness={0.3} />
          </mesh>
          {/* neon trim */}
          <mesh position={[s * 23.6, 4.4, 1]}>
            <boxGeometry args={[0.35, 0.35, 86]} />
            <meshStandardMaterial color="#000" emissive={s < 0 ? '#22d3ee' : '#e879f9'} emissiveIntensity={2.4} toneMapped={false} />
          </mesh>
        </group>
      ))}
      {/* lockdown bar */}
      <mesh position={[0, 2.2, 45.2]} castShadow>
        <boxGeometry args={[54, 1.6, 4.5]} />
        <meshStandardMaterial color="#9aa5b5" metalness={0.95} roughness={0.25} />
      </mesh>
      {/* front body */}
      <mesh position={[0, -11.5, 1]} rotation={[0.115, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[53.5, 18, 86]} />
        <meshStandardMaterial color="#141126" roughness={0.6} metalness={0.3} />
      </mesh>
      {/* coin door */}
      <mesh position={[0, -8, 44.5]}>
        <boxGeometry args={[10, 12, 0.6]} />
        <meshStandardMaterial color="#0b0b12" roughness={0.4} metalness={0.7} />
      </mesh>
      {[[-2.2], [2.2]].map(([ox], i) => (
        <mesh key={i} position={[ox, -8, 44.9]}>
          <boxGeometry args={[2.6, 4, 0.3]} />
          <meshStandardMaterial color="#1f2937" emissive={i ? '#e879f9' : '#22d3ee'} emissiveIntensity={0.7} metalness={0.6} roughness={0.3} />
        </mesh>
      ))}
      {/* legs */}
      {[[-24, 38], [24, 38], [-24, -30], [24, -30]].map(([x, z], i) => (
        <group key={i} position={[x, -21, z]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.4, 1.1, 20, 14]} />
            <meshStandardMaterial color="#1f2937" metalness={0.85} roughness={0.35} />
          </mesh>
          <mesh position={[0, -10.2, 0]}>
            <cylinderGeometry args={[1.7, 1.9, 1, 14]} />
            <meshStandardMaterial color="#000" roughness={0.8} />
          </mesh>
        </group>
      ))}
      {/* backbox */}
      <mesh position={[0, 14, -41.5]} castShadow>
        <boxGeometry args={[54, 34, 9]} />
        <meshStandardMaterial color="#141126" roughness={0.55} metalness={0.3} />
      </mesh>
      {/* backglass art frame */}
      <mesh position={[0, 24.5, -36.9]}>
        <planeGeometry args={[50, 13]} />
        <meshStandardMaterial color="#050816" roughness={0.4} emissive="#1e1b4b" emissiveIntensity={0.5} />
      </mesh>
      {/* backglass neon title (emissive bars simulating art) */}
      <mesh position={[0, 25.5, -36.7]}>
        <boxGeometry args={[30, 0.7, 0.2]} />
        <meshStandardMaterial color="#000" emissive="#22d3ee" emissiveIntensity={3} toneMapped={false} />
      </mesh>
      <mesh position={[0, 22.8, -36.7]}>
        <boxGeometry args={[30, 0.7, 0.2]} />
        <meshStandardMaterial color="#000" emissive="#e879f9" emissiveIntensity={3} toneMapped={false} />
      </mesh>
      <mesh position={[-20, 24.2, -36.7]}>
        <boxGeometry args={[0.7, 4, 0.2]} />
        <meshStandardMaterial color="#000" emissive="#fbbf24" emissiveIntensity={2.5} toneMapped={false} />
      </mesh>
      <mesh position={[20, 24.2, -36.7]}>
        <boxGeometry args={[0.7, 4, 0.2]} />
        <meshStandardMaterial color="#000" emissive="#fbbf24" emissiveIntensity={2.5} toneMapped={false} />
      </mesh>
      {/* jackpot beacon on backbox */}
      <mesh position={[0, 32.6, -40]}>
        <cylinderGeometry args={[2.2, 2.6, 1.2, 20]} />
        <meshStandardMaterial color="#111" roughness={0.5} />
      </mesh>
      <mesh position={[0, 34, -40]}>
        <sphereGeometry args={[1.7, 20, 20]} />
        <meshStandardMaterial ref={jackpotMat} color="#3f2d06" emissive="#fbbf24" emissiveIntensity={0.3} roughness={0.3} />
      </mesh>
      {/* DMD housing */}
      <mesh position={[0, 16.5, -36.85]}>
        <boxGeometry args={[37, 13, 1.4]} />
        <meshStandardMaterial color="#000000" roughness={0.6} />
      </mesh>
      <DMD />
      {/* speakers */}
      {[[-22], [22]].map(([x], i) => (
        <group key={i} position={[x, 16.5, -36.9]}>
          <mesh>
            <circleGeometry args={[3.4, 24]} />
            <meshStandardMaterial color="#020617" roughness={0.8} />
          </mesh>
          {[2.4, 1.5, 0.6].map((r, j) => (
            <mesh key={j} position={[0, 0, 0.08]}>
              <ringGeometry args={[r - 0.18, r, 24]} />
              <meshStandardMaterial color="#334155" emissive="#475569" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>
      ))}
      {/* topper dome */}
      <mesh position={[0, 32.2, -41.5]}>
        <cylinderGeometry args={[3.4, 4, 1.6, 20]} />
        <meshStandardMaterial color="#0f172a" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh position={[0, 34.2, -41.5]}>
        <sphereGeometry args={[2.4, 24, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial ref={topperMat} color="#0b1220" emissive="#22d3ee" emissiveIntensity={1.6} roughness={0.2} transparent opacity={0.95} />
      </mesh>
      <pointLight ref={topperLight} position={[0, 36, -38]} color="#22d3ee" intensity={12} distance={60} />
    </group>
  );
}

// ---------------- Main scene ----------------
export function PinballScene() {
  const art = useMemo(() => makePlayfieldTexture(), []);
  const sideArt = useMemo(() => makeSideArt(), []);
  return (
    <>
      <color attach="background" args={['#04050d']} />
      <fog attach="fog" args={['#04050d', 140, 300]} />
      <PhysicsLoop />
      <CameraRig />

      <ambientLight intensity={0.5} />
      <directionalLight
        position={[25, 90, 55]}
        intensity={1.5}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-45}
        shadow-camera-right={45}
        shadow-camera-top={45}
        shadow-camera-bottom={-45}
        shadow-camera-far={220}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[-30, 60, -20]} intensity={0.35} color="#93c5fd" />
      <pointLight position={[0, 26, 30]} intensity={40} distance={110} color="#c4b5fd" decay={1.9} />
      <pointLight position={[0, 20, -34]} intensity={60} distance={90} color="#7c3aed" decay={1.9} />

      {/* tilted playfield group (~6.5deg slope, far edge raised) */}
      <group rotation={[0.115, 0, 0]}>
        <PlayfieldBase art={art} />
        <Walls />
        <LowerChannels />
        <Slings />
        <Bumpers />
        <Posts />
        <Targets />
        <LaneInserts />
        <RaisedUpperLevel />
        <Scoop />
        <Spinner />
        <DropDoors />
        <NovaRamp />
        <Wormhole />
        <Wrecker />
        <Frickies />
        <Flippers />
        <Balls />
        <Plunger />
        {/* glass follows playfield tilt so the ball never clips through */}
        <mesh position={[0, 11.4, 1]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[47, 82]} />
          <meshPhysicalMaterial color="#ffffff" transparent opacity={0.05} roughness={0.05} metalness={0} clearcoat={1} depthWrite={false} />
        </mesh>
      </group>

      <Cabinet sideArt={sideArt} />

      {/* floor */}
      <mesh position={[0, -31.2, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[400, 400]} />
        <meshStandardMaterial color="#070912" roughness={0.35} metalness={0.55} />
      </mesh>
      <ContactShadows position={[0, -31, 5]} opacity={0.75} scale={120} blur={2.4} far={60} color="#000000" />
      {/* floor neon strip */}
      <mesh position={[0, -30.9, 52]}>
        <boxGeometry args={[90, 0.25, 0.6]} />
        <meshStandardMaterial color="#000" emissive="#22d3ee" emissiveIntensity={2} toneMapped={false} />
      </mesh>
      <mesh position={[0, -30.9, -52]}>
        <boxGeometry args={[90, 0.25, 0.6]} />
        <meshStandardMaterial color="#000" emissive="#e879f9" emissiveIntensity={2} toneMapped={false} />
      </mesh>

      <Environment resolution={256}>
        <Lightformer intensity={3} position={[0, 20, 30]} scale={[60, 10, 1]} color="#cdd8ff" />
        <Lightformer intensity={2} position={[-30, 10, -10]} scale={[30, 6, 1]} color="#22d3ee" />
        <Lightformer intensity={2} position={[30, 10, -10]} scale={[30, 6, 1]} color="#e879f9" />
        <Lightformer intensity={1.2} position={[0, 30, -30]} scale={[50, 8, 1]} color="#fbbf24" />
      </Environment>

      <EffectComposer multisampling={0}>
        <Bloom mipmapBlur intensity={1.15} luminanceThreshold={0.5} luminanceSmoothing={0.25} />
        <Vignette darkness={0.72} offset={0.22} />
      </EffectComposer>
    </>
  );
}
