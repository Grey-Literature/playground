import { useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { PinballScene } from './components/PinballScene';
import { HUD } from './components/HUD';
import { useGame, gameRef } from './game/store';
import { sound } from './game/audio';

function useKeyboard() {
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const st = useGame.getState();
      // prevent scrolling for game keys
      if (['Space', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
        e.preventDefault();
      }
      if (e.repeat) return;
      sound.ensure();

      // global keys
      if (e.code === 'KeyH' || e.code === 'Slash' && e.shiftKey) {
        // note: Slash alone is right flipper; ? (shift+/) opens help — keep simple: H only
      }
      if (e.code === 'KeyH') { st.toggleHelp(); return; }
      if (e.code === 'Escape') {
        if (st.showHelp) { st.toggleHelp(); return; }
        if (st.phase === 'playing') st.setPaused(!st.paused);
        return;
      }

      // difficulty select (outside live play so nobody cheats a save)
      const digit = /^Digit([1-5])$/.exec(e.code);
      if (digit && st.phase !== 'playing') {
        e.preventDefault();
        st.setDifficulty((['supereasy', 'easy', 'medium', 'hard', 'impossible'] as const)[Number(digit[1]) - 1]);
        return;
      }

      // start / restart
      if (st.phase !== 'playing') {
        if (e.code === 'Enter' || e.code === 'Space' || e.code === 'NumpadEnter') {
          e.preventDefault();
          st.startGame();
        }
        return;
      }

      // playing keys
      switch (e.code) {
        case 'KeyZ':
        case 'ArrowLeft':
          st.setFlipper('left', true);
          break;
        case 'KeyM':
        case 'ArrowRight':
        case 'Slash':
          st.setFlipper('right', true);
          break;
        case 'Space':
        case 'ArrowDown':
          if (st.ballPhase === 'plunger' && !st.paused) {
            gameRef.plungerCharging = true;
            gameRef.plungerPower = 0;
            useGame.setState({ plungerCharging: true, plungerPower: 0 });
          }
          break;
        case 'KeyA':
          st.nudge('left');
          break;
        case 'KeyD':
          st.nudge('right');
          break;
        case 'KeyW':
        case 'ArrowUp':
          st.nudge('up');
          break;
        case 'Enter':
          // re-plunge convenience: if waiting in plunger, quick tap aims for skill zone
          if (st.ballPhase === 'plunger' && !gameRef.plungerCharging) {
            gameRef.plungerPower = 0.4;
            st.releasePlunger();
          }
          break;
        case 'KeyC':
          st.cycleCamera();
          break;
        case 'KeyP':
          st.setPaused(!st.paused);
          break;
        case 'KeyB':
          // rescue a stuck ball without ending the game
          st.reserveBall();
          break;
        case 'KeyR':
          st.startGame();
          break;
        case 'KeyX':
          st.nudge('left');
          break;
        case 'KeyN':
          st.nudge('right');
          break;
      }
    };

    const up = (e: KeyboardEvent) => {
      const st = useGame.getState();
      switch (e.code) {
        case 'KeyZ':
        case 'ArrowLeft':
          st.setFlipper('left', false);
          break;
        case 'KeyM':
        case 'ArrowRight':
        case 'Slash':
          st.setFlipper('right', false);
          break;
        case 'Space':
        case 'ArrowDown':
          if (gameRef.plungerCharging) {
            st.releasePlunger();
          }
          break;
      }
    };

    const blur = () => {
      const st = useGame.getState();
      if (st.phase !== 'playing') return;
      st.setFlipper('left', false);
      st.setFlipper('right', false);
      if (gameRef.plungerCharging) st.releasePlunger();
      st.setPaused(true);
    };

    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
    };
  }, []);
}

export default function App() {
  useKeyboard();

  return (
    <div
      className="fixed inset-0 overflow-hidden bg-[#04050d] text-white select-none"
      onPointerDown={() => sound.ensure()}
      onTouchStart={() => sound.ensure()}
    >
      <Canvas
        shadows
        dpr={[1, 1.75]}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        camera={{ fov: 38, position: [0, 72, 50], near: 1, far: 600 }}
      >
        <PinballScene />
      </Canvas>
      <HUD />
    </div>
  );
}
