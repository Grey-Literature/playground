import {
  BALL_RADIUS, WALL_PAD, DRAIN_Y, GRAVITY, AIR_DRAG, ROLL_FRICTION,
  WALLS, BUMPERS, POSTS, TARGETS, SENSORS, DROP_TARGETS,
  RAMP_PATH, TUNNEL_PATH, RAMP_EXIT, TUNNEL_EXIT, RAMP_DUR, TUNNEL_DUR,
  samplePath,
  LEFT_PIVOT, RIGHT_PIVOT, FLIPPER_LEN, FLIPPER_R,
  LEFT_REST, LEFT_ACTIVE, RIGHT_REST, RIGHT_ACTIVE,
  FLIP_UP_SPEED, FLIP_DOWN_SPEED, PLUNGER_X, PLUNGER_REST_Y,
  boardHeightAt,
  BallState, PhysEvent,
} from './constants';
import { gameRef, isTilted } from './store';
import { EXTRA_BUMPERS, TOP_POSTS, FRICKIES } from './constants';
import { DIFF, WRECKER } from './difficulty';

// Scale a base restitution by the difficulty's reactivity, with a sanity clamp so
// hard/impossible can never inject more energy than they absorb per bounce.
function bounciness(base: number) {
  return Math.min(1.3, base * DIFF.rest);
}

function clamp(v: number, a: number, b: number) { return Math.max(a, Math.min(b, v)); }

function tipOf(pivot: { x: number; y: number }, angle: number) {
  return { x: pivot.x + Math.cos(angle) * FLIPPER_LEN, y: pivot.y + Math.sin(angle) * FLIPPER_LEN };
}

// returns closest point param t and distance
function collideSegment(ball: BallState, ax: number, ay: number, bx: number, by: number, radius: number) {
  const abx = bx - ax, aby = by - ay;
  const len2 = abx * abx + aby * aby;
  let t = 0;
  if (len2 > 1e-9) {
    t = ((ball.x - ax) * abx + (ball.y - ay) * aby) / len2;
    t = clamp(t, 0, 1);
  }
  const cx = ax + abx * t, cy = ay + aby * t;
  const dx = ball.x - cx, dy = ball.y - cy;
  const dist = Math.hypot(dx, dy);
  return { t, cx, cy, dx, dy, dist, nx: dist > 1e-6 ? dx / dist : 0, ny: dist > 1e-6 ? dy / dist : 1, overlap: radius - dist };
}

function collideCircle(ball: BallState, cx: number, cy: number, r: number) {
  const dx = ball.x - cx, dy = ball.y - cy;
  const dist = Math.hypot(dx, dy);
  const minD = r + BALL_RADIUS;
  return {
    dist,
    nx: dist > 1e-6 ? dx / dist : 0,
    ny: dist > 1e-6 ? dy / dist : 1,
    overlap: minD - dist,
  };
}

export function stepPhysics(dt: number): PhysEvent[] {
  const events: PhysEvent[] = [];
  const G = gameRef;
  if (G.paused) return events;
  G.time += dt;

  // decay flashes
  const f = G.flashes;
  for (let i = 0; i < f.bumpers.length; i++) f.bumpers[i] = Math.max(0, f.bumpers[i] - dt * 2.6);
  f.slingL = Math.max(0, f.slingL - dt * 3);
  f.slingR = Math.max(0, f.slingR - dt * 3);
  for (let i = 0; i < 3; i++) f.lanes[i] = Math.max(0, f.lanes[i] - dt * 2.2);
  f.scoop = Math.max(0, f.scoop - dt * 1.8);
  f.spinner = Math.max(0, f.spinner - dt * 2.5);
  f.orbit = Math.max(0, f.orbit - dt * 1.6);
  f.drain = Math.max(0, f.drain - dt * 1.5);
  f.jackpot = Math.max(0, f.jackpot - dt * 1.2);
  f.ramp = Math.max(0, f.ramp - dt * 1.3);
  f.tunnel = Math.max(0, f.tunnel - dt * 1.3);
  f.kickback = Math.max(0, f.kickback - dt * 1.8);
  for (let i = 0; i < 3; i++) f.drops[i] = Math.max(0, f.drops[i] - dt * 2.4);
  for (const k of Object.keys(f.targets)) {
    f.targets[k] = Math.max(0, f.targets[k] - dt * 2.5);
    if (f.targets[k] <= 0) delete f.targets[k];
  }
  G.shake = Math.max(0, G.shake - dt * 1.6);
  if (G.bumperComboTimer > 0) {
    G.bumperComboTimer -= dt;
    if (G.bumperComboTimer <= 0) G.bumperCombo = 0;
  }
  if (G.skillWindow > 0) G.skillWindow -= dt;
  if (G.launchCooldown > 0) G.launchCooldown -= dt;

  // spinner physics
  G.spinnerAngle += G.spinnerVel * dt;
  G.spinnerVel *= Math.exp(-2.2 * dt);

  const tilted = isTilted();

  // ---- wrecker bar (kinematic obstacle) ----
  if (DIFF.ob.wrecker) {
    WRECKER.angle += WRECKER.speedFor(DIFF.id) * dt;
  }

  // ---- flippers ----
  const updateFlipper = (side: 'left' | 'right') => {
    const fl = side === 'left' ? G.left : G.right;
    const rest = side === 'left' ? LEFT_REST : RIGHT_REST;
    const active = side === 'left' ? LEFT_ACTIVE : RIGHT_ACTIVE;
    const pressed = tilted ? false : fl.pressed;
    const target = pressed ? active : rest;
    let diff = target - fl.angle;
    // normalize for right flipper wrap not needed since range small
    const dir = Math.sign(diff);
    const maxSpeed = (pressed ? FLIP_UP_SPEED : FLIP_DOWN_SPEED) * DIFF.flipSpeed;
    // for right flipper, active < rest, diff negative when pressing
    const step = maxSpeed * dt;
    let newAngle: number;
    if (Math.abs(diff) <= step) {
      newAngle = target;
      fl.angVel = diff / dt;
    } else {
      newAngle = fl.angle + dir * step;
      fl.angVel = dir * maxSpeed;
    }
    fl.angle = newAngle;
  };
  updateFlipper('left');
  updateFlipper('right');

  // consume nudge
  const nudgeX = G.pendingNudge.x;
  const nudgeY = G.pendingNudge.y;
  G.pendingNudge.x = 0;
  G.pendingNudge.y = 0;

  const sub = 3;
  const h = dt / sub;

  for (let s = 0; s < sub; s++) {
    for (const ball of G.balls) {
      if (!ball.active) continue;

      // auto-launch countdown (multiball second ball)
      if (ball.autoLaunch !== undefined) {
        ball.autoLaunch -= h;
        ball.x = PLUNGER_X;
        ball.y = PLUNGER_REST_Y;
        ball.vx = 0; ball.vy = 0;
        if (ball.autoLaunch <= 0) {
          ball.autoLaunch = undefined;
          ball.vy = (235 + Math.random() * 15) * DIFF.launch;
          ball.vx = (Math.random() - 0.5) * 4;
          events.push({ type: 'laneLaunch', x: ball.x, y: ball.y });
        }
        continue;
      }

      // captured in scoop
      if (ball.captured > 0) {
        ball.captured -= h;
        // pull to scoop center
        const scoop = SENSORS.find(sn => sn.kind === 'scoop')!;
        ball.x += (scoop.x - ball.x) * Math.min(1, 10 * h);
        ball.y += (scoop.y - ball.y) * Math.min(1, 10 * h);
        ball.vx = 0; ball.vy = 0;
        if (ball.captured <= 0) {
          ball.captureCooldown = 2.5;
          const ang = -Math.PI / 2 + (Math.random() - 0.5) * 1.1; // upward-ish in xy? actually +y is up
          // upward = +y -> angle PI/2
          const a = Math.PI / 2 + (Math.random() - 0.5) * 0.9;
          const sp = 130 + Math.random() * 30;
          ball.vx = Math.cos(a) * sp;
          ball.vy = Math.sin(a) * sp;
          void ang;
          events.push({ type: 'scoopEject', id: 'scoop', x: ball.x, y: ball.y });
        }
        continue;
      }
      if (ball.captureCooldown > 0) ball.captureCooldown -= h;

      // Ride a capture-path (ramp / tunnel). No collision while in transit —
      // that's the whole point of a pipe. The ball is guaranteed to eject.
      if (ball.ride) {
        ball.ride.t += h / ball.ride.dur;
        const pts = ball.ride.kind === 'ramp' ? RAMP_PATH : TUNNEL_PATH;
        const p = samplePath(pts, Math.min(1, ball.ride.t));
        ball.x = p.x;
        ball.y = p.y;
        ball.h = p.h;
        ball.vx = 0;
        ball.vy = 0;
        if (ball.ride.t >= 1) {
          const ride = ball.ride;
          ball.ride = undefined;
          ball.captureCooldown = 0.9;
          ball.vx = ride.exitVx;
          ball.vy = ride.exitVy;
          ball.h = 0;
          events.push({
            type: ride.kind === 'ramp' ? 'rampEject' : 'tunnelEject',
            id: ride.kind,
            x: ball.x,
            y: ball.y,
          });
        }
        continue;
      }

      // plunger hold: if ball in lane near bottom and charging (or waiting in plunger phase), hold
      const inLaneArea = ball.x > 17 && ball.y < 22;
      ball.inLane = inLaneArea && ball.x > 16.5;
      if (inLaneArea && ball.y < -28 && G.plungerCharging && ball.vy < 1) {
        ball.x = PLUNGER_X;
        ball.y = PLUNGER_REST_Y;
        ball.vx = 0; ball.vy = 0;
        continue;
      }
      // also hold waiting ball at rest in lane if slow and at bottom (before charge)
      if (inLaneArea && ball.y <= PLUNGER_REST_Y + 0.5 && Math.abs(ball.vy) < 8 && G.launchCooldown <= 0) {
        // check if this is a waiting plunger ball (vy ~0 due to bottom wall) — let bottom wall handle, but damp
      }

      // apply nudge once per frame (first substep)
      if (s === 0 && (nudgeX !== 0 || nudgeY !== 0)) {
        ball.vx += nudgeX;
        ball.vy += nudgeY;
      }

      // gravity + integration (difficulty scales gravity: super-easy genuinely plays slower)
      ball.vy += GRAVITY * DIFF.grav * h;

      // Slope force from the raised deck / ramps. Using the real height gradient
      // means inclines decelerate a climbing ball AND accelerate a descending one,
      // so a ball can never come to rest partway up a ramp.
      {
        const e = 0.35;
        const gx = (boardHeightAt(ball.x + e, ball.y) - boardHeightAt(ball.x - e, ball.y)) / (2 * e);
        const gy = (boardHeightAt(ball.x, ball.y + e) - boardHeightAt(ball.x, ball.y - e)) / (2 * e);
        if (gx !== 0 || gy !== 0) {
          const SLOPE_G = 165 * DIFF.grav;
          ball.vx -= SLOPE_G * gx * h;
          ball.vy -= SLOPE_G * gy * h;
        }
      }
      // drag
      const drag = 1 - AIR_DRAG * h;
      ball.vx *= drag;
      ball.vy *= drag;
      // rolling friction (stronger when slow)
      const sp0 = Math.hypot(ball.vx, ball.vy);
      if (sp0 > 1) {
        const fr = Math.min(sp0, ROLL_FRICTION * 8 * h * (sp0 < 30 ? 2 : 1));
        ball.vx -= (ball.vx / sp0) * fr;
        ball.vy -= (ball.vy / sp0) * fr;
      }
      // clamp
      const sp1 = Math.hypot(ball.vx, ball.vy);
      if (sp1 > DIFF.maxSpeed) {
        ball.vx = (ball.vx / sp1) * DIFF.maxSpeed;
        ball.vy = (ball.vy / sp1) * DIFF.maxSpeed;
      }

      ball.x += ball.vx * h;
      ball.y += ball.vy * h;
      ball.spin += sp1 * h * 0.4;

      // Remember where integration left the ball so we can measure how hard the
      // colliders had to shove it back this step (see un-wedge below).
      const solveX = ball.x, solveY = ball.y;

      // ---- one-way gate: block playfield -> lane above divider top ----
      // divider top at y=20; gate region y in [20, 36]; if ball left of 17 moving right, push back
      if (ball.y > 16.5 && ball.y < 36 && ball.x > 17 - BALL_RADIUS - WALL_PAD && ball.x < 17 + 1 && ball.vx > 0 && ball.x - ball.vx * h < 17) {
        // Park it exactly on the divider's collision surface, otherwise the gate and
        // the wall fight each other and the ball buzzes in place.
        ball.x = 17 - BALL_RADIUS - WALL_PAD;
        ball.vx = -Math.abs(ball.vx) * 0.4;
      }

      // ---- walls ----
      for (const w of WALLS) {
        const col = collideSegment(ball, w.ax, w.ay, w.bx, w.by, BALL_RADIUS + WALL_PAD);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          if (vn < 0) {
            const rest = bounciness(w.rest ?? 0.4);
            ball.vx -= (1 + rest) * vn * col.nx;
            ball.vy -= (1 + rest) * vn * col.ny;
            if (w.kind === 'sling') {
              const kick = (w.kick ?? 90) * (DIFF.slingKick / 92);
              ball.vx += col.nx * kick;
              ball.vy += col.ny * kick;
              events.push({ type: 'sling', id: w.id, x: ball.x, y: ball.y, speed: Math.abs(vn) });
            }
          }
        }
      }

      // divider top cap (rounded)
      {
        const col = collideCircle(ball, 17, 17, 0.45);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          if (vn < 0) {
            ball.vx -= 1.45 * vn * col.nx;
            ball.vy -= 1.45 * vn * col.ny;
          }
        }
      }

      // ---- bumpers (extra pair is difficulty-gated) ----
      const bumperList = DIFF.ob.extraBumpers ? [...BUMPERS, ...EXTRA_BUMPERS] : BUMPERS;
      for (const b of bumperList) {
        const col = collideCircle(ball, b.x, b.y, b.r);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          // kick outward
          const kick = DIFF.bumperKick;
          if (vn < 20) {
            ball.vx += col.nx * (kick - Math.min(0, vn) * 0.9);
            ball.vy += col.ny * (kick - Math.min(0, vn) * 0.9);
            // slight tangent damping for control
            const tx = -col.ny, ty = col.nx;
            const vt = ball.vx * tx + ball.vy * ty;
            ball.vx -= tx * vt * 0.12;
            ball.vy -= ty * vt * 0.12;
          }
          G.bumperCombo += 1;
          G.bumperComboTimer = 2.2;
          events.push({ type: 'bumper', id: b.id, x: ball.x, y: ball.y });
        }
      }

      // ---- posts (+ difficulty-gated top posts) ----
      const postList = DIFF.ob.topPosts ? [...POSTS, ...TOP_POSTS] : POSTS;
      for (const p of postList) {
        const col = collideCircle(ball, p.x, p.y, p.r);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          if (vn < 0) {
            const rest = bounciness(p.rest ?? 0.75);
            ball.vx -= (1 + rest) * vn * col.nx;
            ball.vy -= (1 + rest) * vn * col.ny;
            if (Math.abs(vn) > 25) events.push({ type: 'post', id: p.id, x: ball.x, y: ball.y });
          }
        }
      }

      // ---- frickies: spring posts that punch the ball back into the pit ----
      if (DIFF.ob.frickies) {
        for (const fk of FRICKIES) {
          const col = collideCircle(ball, fk.x, fk.y, fk.r);
          if (col.overlap > 0) {
            ball.x += col.nx * col.overlap;
            ball.y += col.ny * col.overlap;
            const vn = ball.vx * col.nx + ball.vy * col.ny;
            if (vn < 12) {
              ball.vx += col.nx * (DIFF.frickyKick - Math.min(0, vn) * 0.6);
              ball.vy += col.ny * (DIFF.frickyKick - Math.min(0, vn) * 0.6);
              events.push({ type: 'post', id: fk.id, x: ball.x, y: ball.y });
            }
          }
        }
      }

      // ---- wrecker: rotating bar that swats low balls into the drain ----
      if (DIFF.ob.wrecker) {
        const dirX = Math.cos(WRECKER.angle), dirY = Math.sin(WRECKER.angle);
        const ax = WRECKER.cx - dirX * WRECKER.half, ay = WRECKER.cy - dirY * WRECKER.half;
        const bx = WRECKER.cx + dirX * WRECKER.half, by = WRECKER.cy + dirY * WRECKER.half;
        const col = collideSegment(ball, ax, ay, bx, by, BALL_RADIUS + WRECKER.r);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          // surface velocity of the spinning bar at the contact point (v = ω × r)
          const dx = col.cx - WRECKER.cx, dy = col.cy - WRECKER.cy;
          const w = WRECKER.speedFor(DIFF.id);
          const vsx = -w * dy, vsy = w * dx;
          const rvx = ball.vx - vsx, rvy = ball.vy - vsy;
          const vn = rvx * col.nx + rvy * col.ny;
          if (vn < 0) {
            const rest = bounciness(0.65);
            ball.vx -= (1 + rest) * vn * col.nx;
            ball.vy -= (1 + rest) * vn * col.ny;
            // swat energy from the bar's motion
            ball.vx += vsx * 0.55;
            ball.vy += vsy * 0.55;
            events.push({ type: 'post', id: 'wrecker', x: ball.x, y: ball.y });
          }
        }
      }

      // ---- targets ----
      for (const t of TARGETS) {
        const col = collideCircle(ball, t.x, t.y, t.r);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          if (vn < 0) {
            const rest = bounciness(0.65);
            ball.vx -= (1 + rest) * vn * col.nx;
            ball.vy -= (1 + rest) * vn * col.ny;
            events.push({ type: 'target', id: t.id, x: ball.x, y: ball.y });
          }
        }
      }

      // ---- drop-target doors (no collision once down) ----
      for (const t of DROP_TARGETS) {
        const idx = Number(t.id);
        if (G.dropDown[idx]) continue;
        const col = collideCircle(ball, t.x, t.y, t.r);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          const vn = ball.vx * col.nx + ball.vy * col.ny;
          if (vn < 0) {
            ball.vx -= 1.55 * vn * col.nx;
            ball.vy -= 1.55 * vn * col.ny;
            G.dropDown[idx] = true;
            G.flashes.drops[idx] = 1;
            events.push({ type: 'drop', id: idx, x: ball.x, y: ball.y });
          }
        }
      }

      // NOTE: no separate pivot collider — the flipper segment below already starts at
      // the pivot with a larger radius, and the extra disc only created a wedge pocket.

      // ---- flippers (segments) ----
      const flipperCols: { pivot: { x: number; y: number }; angle: number; angVel: number }[] = [
        { pivot: LEFT_PIVOT, angle: G.left.angle, angVel: G.left.angVel },
        { pivot: RIGHT_PIVOT, angle: G.right.angle, angVel: G.right.angVel },
      ];
      for (const fc of flipperCols) {
        const tip = tipOf(fc.pivot, fc.angle);
        const col = collideSegment(ball, fc.pivot.x, fc.pivot.y, tip.x, tip.y, BALL_RADIUS + FLIPPER_R);
        if (col.overlap > 0) {
          ball.x += col.nx * col.overlap;
          ball.y += col.ny * col.overlap;
          // surface velocity due to rotation at contact point
          const dx = col.cx - fc.pivot.x, dy = col.cy - fc.pivot.y;
          const dist = Math.hypot(dx, dy);
          // perpendicular direction * omega
          const svx = -Math.sin(fc.angle) * fc.angVel * dist * 0.12 + (-dy / (dist || 1)) * fc.angVel * dist * 0.0;
          // simpler: v = omega x r
          const w = fc.angVel;
          const vsx = -w * dy;
          const vsy = w * dx;
          // relative velocity
          const rvx = ball.vx - vsx;
          const rvy = ball.vy - vsy;
          const vn = rvx * col.nx + rvy * col.ny;
          if (vn < 0) {
            const rest = 0.35;
            ball.vx -= (1 + rest) * vn * col.nx;
            ball.vy -= (1 + rest) * vn * col.ny;
            // add extra flip boost when swinging up (difficulty-tuned reactivity)
            const swingBoost = Math.abs(w) > 4 ? Math.abs(w) * DIFF.flipperBoost : 0;
            if (swingBoost > 0) {
              ball.vx += col.nx * swingBoost * 0.95 + vsx * 0.32;
              ball.vy += col.ny * swingBoost * 0.95 + vsy * 0.32;
            }
            void svx;
          } else {
            // even if separating, impart some swing energy
            if (Math.abs(w) > 8) {
              ball.vx += vsx * 0.12;
              ball.vy += vsy * 0.12;
            }
          }
        }
      }

      // ---- sensors ----
      for (const sn of SENSORS) {
        const d = Math.hypot(ball.x - sn.x, ball.y - sn.y);
        const inside = d < sn.r;
        const was = ball.inside.has(sn.id);
        if (inside && !was) {
          ball.inside.add(sn.id);
          if (sn.kind === 'lane') events.push({ type: 'lane', id: sn.id, x: ball.x, y: ball.y });
          else if (sn.kind === 'spinner') events.push({ type: 'spinner', id: sn.id, x: ball.x, y: ball.y });
          else if (sn.kind === 'orbit') {
            if (Math.hypot(ball.vx, ball.vy) > 60) events.push({ type: 'orbit', id: sn.id, x: ball.x, y: ball.y });
          }
          else if (sn.kind === 'inlane') events.push({ type: 'inlane', id: sn.id, x: ball.x, y: ball.y });
          else if (sn.kind === 'scoop') {
            if (ball.captureCooldown <= 0 && Math.hypot(ball.vx, ball.vy) < 150) {
              ball.captured = 1.25;
              events.push({ type: 'scoop', id: sn.id, x: ball.x, y: ball.y });
            }
          } else if (sn.kind === 'ramp') {
            const sp = Math.hypot(ball.vx, ball.vy);
            if (ball.captureCooldown <= 0 && sp > 72 && ball.vy > 42) {
              ball.ride = { kind: 'ramp', t: 0, dur: RAMP_DUR, exitVx: RAMP_EXIT.vx, exitVy: RAMP_EXIT.vy };
              events.push({ type: 'ramp', id: 'ramp', x: ball.x, y: ball.y, speed: sp });
            }
          } else if (sn.kind === 'tunnel') {
            if (ball.captureCooldown <= 0 && Math.hypot(ball.vx, ball.vy) < 85) {
              ball.ride = { kind: 'tunnel', t: 0, dur: TUNNEL_DUR, exitVx: TUNNEL_EXIT.vx, exitVy: TUNNEL_EXIT.vy };
              events.push({ type: 'tunnel', id: 'tunnel', x: ball.x, y: ball.y });
            }
          }
        } else if (!inside && was) {
          ball.inside.delete(sn.id);
        }
      }

      // ---- drain ----
      if (ball.y < DRAIN_Y) {
        ball.active = false;
        ball.vx = 0; ball.vy = 0;
        events.push({ type: 'drain', id: ball.id, x: ball.x, y: ball.y });
      }

      // ---- un-wedge safety net ----
      // A wedged ball is one the solver keeps pushing every step while it barely
      // moves. The push direction is the way out, so ease it along that vector and
      // add a small kick if it persists. This guarantees no permanent stick even if
      // a future layout edit introduces a tight spot.
      const corrX = ball.x - solveX;
      const corrY = ball.y - solveY;
      const corrMag = Math.hypot(corrX, corrY);
      const speedNow = Math.hypot(ball.vx, ball.vy);
      const onFlipper = ball.y < -28.5 && Math.abs(ball.x) < 11;
      const inLaneRest = ball.x > 17;
      if (corrMag > 0.02 && speedNow < 26 && !onFlipper && !inLaneRest) {
        ball.stuck = (ball.stuck ?? 0) + h;
        if (ball.stuck > 0.25) {
          const nx = corrX / corrMag, ny = corrY / corrMag;
          ball.x += nx * 0.06;
          ball.y += ny * 0.06;
          ball.vx += nx * 26 * h * 12;
          ball.vy += ny * 26 * h * 12;
        }
      } else if ((ball.stuck ?? 0) > 0) {
        ball.stuck = Math.max(0, (ball.stuck ?? 0) - h * 3);
      }

      // safety: keep in bounds
      if (ball.x < -24) { ball.x = -24; ball.vx = Math.abs(ball.vx) * 0.5; }
      if (ball.x > 24) { ball.x = 24; ball.vx = -Math.abs(ball.vx) * 0.5; }
      if (ball.y > 40) { ball.y = 40; ball.vy = -Math.abs(ball.vy) * 0.5; }
    }

    // ball-ball collisions
    const actives = G.balls.filter(b => b.active && b.captured <= 0 && !b.ride && b.autoLaunch === undefined);
    for (let i = 0; i < actives.length; i++) {
      for (let j = i + 1; j < actives.length; j++) {
        const a = actives[i], b = actives[j];
        const dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.hypot(dx, dy);
        const minD = BALL_RADIUS * 2;
        if (dist < minD && dist > 1e-6) {
          const nx = dx / dist, ny = dy / dist;
          const overlap = (minD - dist) / 2;
          a.x -= nx * overlap; a.y -= ny * overlap;
          b.x += nx * overlap; b.y += ny * overlap;
          const rvx = b.vx - a.vx, rvy = b.vy - a.vy;
          const vn = rvx * nx + rvy * ny;
          if (vn < 0) {
            const e = 0.92;
            const jimp = -(1 + e) * vn / 2;
            a.vx -= jimp * nx; a.vy -= jimp * ny;
            b.vx += jimp * nx; b.vy += jimp * ny;
          }
        }
      }
    }
  }

  return events;
}
