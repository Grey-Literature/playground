// Playfield layout & physics constants. Units: playfield coordinates.
// x: -22 (left wall) .. +17 (plunger divider). Plunger lane: x in [17,22].
// y: -41 (drain) .. +36 (top of arch).
//
// CLEARANCE RULE — the ball is a disc of radius 1.55 and walls are inflated by
// WALL_PAD, so a ball can only pass a gap whose *centre-to-centre* width exceeds:
//     wall <-> wall   : 2*(1.55+0.35) = 3.80
//     wall <-> post   : (1.55+0.35) + (1.55+r)
//     post <-> post   : (1.55+ra) + (1.55+rb)
// Any gap smaller than that must be fully sealed, otherwise the ball wedges.
// scripts/stuckcheck.ts verifies this empirically — run it after layout edits.

export const BALL_RADIUS = 1.55;
export const WALL_PAD = 0.35;
export const GRAVITY = -118;
export const MAX_SPEED = 260;
export const AIR_DRAG = 0.06;
export const ROLL_FRICTION = 0.12;
export const DRAIN_Y = -41;

// Flipper spacing is load-bearing: at rest the two tips must be more than
// 2*(BALL_RADIUS + FLIPPER_R) = 5.8 apart or the ball physically cannot drain
// between them and the game can never end.
export const LEFT_PIVOT = { x: -9.0, y: -31.2 };
export const RIGHT_PIVOT = { x: 9.0, y: -31.2 };
export const FLIPPER_LEN = 7.8;
export const FLIPPER_R = 1.35;
export const LEFT_REST = -0.78;
export const LEFT_ACTIVE = 0.60;
export const RIGHT_REST = Math.PI + 0.78;
export const RIGHT_ACTIVE = Math.PI - 0.60;
export const FLIP_UP_SPEED = 30;
export const FLIP_DOWN_SPEED = 10;

export const PLUNGER_X = 19.5;
export const PLUNGER_REST_Y = -35.8;

// Raised rear deck: two ball channels climb onto a three-lane upper level.
export const UPPER_DECK_HEIGHT = 5.1;

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const smooth01 = (v: number) => {
  const t = clamp01(v);
  return t * t * (3 - 2 * t);
};

export const DECK_Y0 = 25.5;
export const DECK_Y1 = 33.6;
export const DECK_HALF_X = 9.8;
export const RAMP_Y0 = 18.5;
export const RAMP_Y1 = 26.0;

// 1 inside `inner`, easing to 0 at `outer` — keeps the ball from snapping between levels.
function falloff(d: number, inner: number, outer: number) {
  if (d <= inner) return 1;
  if (d >= outer) return 0;
  return smooth01(1 - (d - inner) / (outer - inner));
}

export function rampCenters(t: number) {
  const left = -14.4 + t * 5.0;
  return [left, -left];
}

export function boardHeightAt(x: number, y: number) {
  let h = 0;

  // Raised rear deck. It only slopes down at the FRONT edge — giving it a back
  // edge as well created a ledge where the up-slope exactly cancelled gravity and
  // balls parked there forever.
  if (y > DECK_Y0 - 2.5) {
    const fx = falloff(Math.abs(x), DECK_HALF_X - 1.2, DECK_HALF_X + 1.7);
    const fy = y >= DECK_Y0 ? 1 : falloff(DECK_Y0 - y, 0.2, 2.2);
    h = Math.max(h, UPPER_DECK_HEIGHT * fx * fy);
  }

  // two climbing ramps
  const t = (y - RAMP_Y0) / (RAMP_Y1 - RAMP_Y0);
  if (t > 0 && t < 1.2) {
    const tc = Math.min(1, t);
    const climb = smooth01(tc) * (UPPER_DECK_HEIGHT - 0.35);
    const [leftCenter, rightCenter] = rampCenters(tc);
    const f = Math.max(
      falloff(Math.abs(x - leftCenter), 1.5, 1.62),
      falloff(Math.abs(x - rightCenter), 1.5, 1.62),
    );
    h = Math.max(h, climb * f);
  }

  return h;
}

export interface WallSeg {
  ax: number; ay: number; bx: number; by: number;
  rest?: number;
  kind?: 'wall' | 'sling' | 'gate' | 'guide';
  id?: string;
  kick?: number;
}

export interface CircleBody {
  x: number; y: number; r: number;
  kind: 'bumper' | 'post' | 'target' | 'pivot' | 'drop';
  id: string | number;
  rest?: number;
}

export interface Sensor {
  x: number; y: number; r: number;
  kind: 'lane' | 'scoop' | 'spinner' | 'orbit' | 'inlane' | 'skill' | 'ramp' | 'tunnel';
  id: string;
}

export interface PathPt { x: number; y: number; h: number; }

export function samplePath(pts: PathPt[], t: number): PathPt {
  const n = pts.length - 1;
  const u = Math.max(0, Math.min(0.9999, t)) * n;
  const i = Math.floor(u);
  const f = u - i;
  const p0 = pts[Math.max(0, i - 1)];
  const p1 = pts[i];
  const p2 = pts[Math.min(n, i + 1)];
  const p3 = pts[Math.min(n, i + 2)];
  const f2 = f * f, f3 = f2 * f;
  const cr = (a: number, b: number, c: number, d: number) =>
    0.5 * ((2 * b) + (-a + c) * f + (2 * a - 5 * b + 4 * c - d) * f2 + (-a + 3 * b - 3 * c + d) * f3);
  return { x: cr(p0.x, p1.x, p2.x, p3.x), y: cr(p0.y, p1.y, p2.y, p3.y), h: cr(p0.h, p1.h, p2.h, p3.h) };
}

function arcWalls(cx: number, cy: number, radius: number, a0: number, a1: number, n: number): WallSeg[] {
  const segs: WallSeg[] = [];
  let px = cx + radius * Math.cos(a0);
  let py = cy + radius * Math.sin(a0);
  for (let i = 1; i <= n; i++) {
    const a = a0 + ((a1 - a0) * i) / n;
    const x = cx + radius * Math.cos(a);
    const y = cy + radius * Math.sin(a);
    segs.push({ ax: px, ay: py, bx: x, by: y, rest: 0.42, kind: 'wall', id: `arc${i}` });
    px = x; py = y;
  }
  return segs;
}

function polyWalls(points: [number, number][], prefix: string, kind: WallSeg['kind'], rest: number): WallSeg[] {
  return points.slice(1).map((p, i) => ({
    ax: points[i][0], ay: points[i][1], bx: p[0], by: p[1],
    rest, kind, id: `${prefix}${i}`,
  }));
}

// Outer arch spans the whole cabinet so the plunger lane feeds under it.
const arch = arcWalls(0, 14, 22, 0, Math.PI, 24);

// Return guides funnel the ball from the outer walls down onto the flipper tips.
// They stop 3.0 from each pivot — just clear of the flipper's own collision radius
// (BALL_RADIUS + FLIPPER_R = 2.9) so the ball can never be crushed between them.
export const RETURN_GUIDE_LEFT: [number, number][] = [[-22, -22], [-18, -26], [-14.5, -28.2], [-11.6, -28.9]];
export const RETURN_GUIDE_RIGHT: [number, number][] = [[17, -22], [14.2, -25.6], [13.0, -28.2], [11.6, -28.9]];

// Slingshots sit flush against the side walls, so there is no narrow outlane
// channel behind them for the ball to jam into.
export const SLING_LEFT: [number, number][] = [[-22, -9], [-22, -19], [-17.3, -14]];
export const SLING_RIGHT: [number, number][] = [[17, -9], [17, -19], [12.3, -14]];

export const WALLS: WallSeg[] = [
  { ax: -22, ay: -22, bx: -22, by: 14, rest: 0.4, kind: 'wall', id: 'outerL' },
  { ax: 22, ay: -38, bx: 22, by: 14, rest: 0.4, kind: 'wall', id: 'outerR' },
  // Divider tops out at 17: any higher and its end cap plus the arch squeeze the
  // shooter-lane exit below one ball width, sealing the ball in the lane.
  { ax: 17, ay: -38, bx: 17, by: 17, rest: 0.35, kind: 'wall', id: 'divider' },
  { ax: 17, ay: -38, bx: 22, by: -38, rest: 0.3, kind: 'wall', id: 'laneBottom' },

  ...polyWalls(RETURN_GUIDE_LEFT, 'guideL', 'guide', 0.35),
  ...polyWalls(RETURN_GUIDE_RIGHT, 'guideR', 'guide', 0.35),

  // slingshot kicking faces
  { ax: -22, ay: -19, bx: -17.3, by: -14, rest: 0.55, kind: 'sling', id: 'slingL-b', kick: 92 },
  { ax: -17.3, ay: -14, bx: -22, by: -9, rest: 0.55, kind: 'sling', id: 'slingL-a', kick: 92 },
  { ax: 17, ay: -19, bx: 12.3, by: -14, rest: 0.55, kind: 'sling', id: 'slingR-b', kick: 92 },
  { ax: 12.3, ay: -14, bx: 17, by: -9, rest: 0.55, kind: 'sling', id: 'slingR-a', kick: 92 },

  ...arch,
];

export const BUMPERS: CircleBody[] = [
  { x: -6.6, y: 13.5, r: 2.9, kind: 'bumper', id: 0 },
  { x: 6.6, y: 13.5, r: 2.9, kind: 'bumper', id: 1 },
  { x: 0, y: 21.5, r: 2.9, kind: 'bumper', id: 2 },
];

export const POSTS: CircleBody[] = [
  { x: -7.5, y: 4.0, r: 0.62, kind: 'post', id: 'p0', rest: 0.8 },
  { x: 2.5, y: 4.0, r: 0.62, kind: 'post', id: 'p1', rest: 0.8 },
  // NOTE: there used to be posts at (±11, 24.5) — they sat directly under the
  // ramp's dive and were removed so the wire can descend cleanly.
  { x: -3.4, y: 29.6, r: 0.55, kind: 'post', id: 'lanePost0', rest: 0.7 },
  { x: 3.4, y: 29.6, r: 0.55, kind: 'post', id: 'lanePost1', rest: 0.7 },
];

export const TARGETS: CircleBody[] = [
  // left bank — 3.4 clear of the side wall
  { x: -14.0, y: -1.0, r: 1.15, kind: 'target', id: 'L0' },
  { x: -14.0, y: 2.7, r: 1.15, kind: 'target', id: 'L1' },
  { x: -14.0, y: 6.4, r: 1.15, kind: 'target', id: 'L2' },
  // right bank — 3.4 clear of the plunger divider
  { x: 9.0, y: -1.0, r: 1.15, kind: 'target', id: 'R0' },
  { x: 9.0, y: 2.7, r: 1.15, kind: 'target', id: 'R1' },
  { x: 9.0, y: 6.4, r: 1.15, kind: 'target', id: 'R2' },
  // centre standups — 7.4 apart so the ball can shoot the gap
  { x: -6.2, y: -4.5, r: 1.05, kind: 'target', id: 'C0' },
  { x: 1.2, y: -4.5, r: 1.05, kind: 'target', id: 'C1' },
];

// ---- difficulty-gated obstacles (validated by scripts/stuckcheck.ts) ----
// Upper pop bumper pair. Flanks the orbit/center lanes; sealed clusters with the
// main bumpers (surface gaps < one ball diameter, so no wedge pocket is possible).
export const EXTRA_BUMPERS: CircleBody[] = [
  { x: -10.8, y: 19.4, r: 2.6, kind: 'bumper', id: 3 },
  { x: 10.8, y: 19.4, r: 2.6, kind: 'bumper', id: 4 },
];

// Rubber posts that scatter top-of-field shots (medium+).
export const TOP_POSTS: CircleBody[] = [
  { x: 0, y: 17.6, r: 0.62, kind: 'post', id: 'tp0', rest: 0.95 },
  { x: -7.2, y: 17.5, r: 0.62, kind: 'post', id: 'tp1', rest: 0.95 },
  { x: 7.2, y: 17.5, r: 0.62, kind: 'post', id: 'tp2', rest: 0.95 },
];

// Spring-loaded frickies above the flippers (impossible only) — they punch the
// ball back into the pit. Positioned so a raised flipper still leaves >1 ball
// width of clearance to each post.
export const FRICKIES: CircleBody[] = [
  { x: -7.2, y: -22.6, r: 0.8, kind: 'post', id: 'fk0', rest: 1.0 },
  { x: 7.2, y: -22.6, r: 0.8, kind: 'post', id: 'fk1', rest: 1.0 },
];

export const SENSORS: Sensor[] = [
  // Top lanes ride the arch itself (ball centre path is the r≈20.1 circle about
  // (0,14)) — placed any further inboard and launched balls fly clean over them,
  // which silently killed the skill shot. Radii are generous so a fast ball can't
  // tunnel between substeps.
  { x: -7.5, y: 32.9, r: 2.8, kind: 'lane', id: 'lane0' },
  { x: 0, y: 34.2, r: 2.8, kind: 'lane', id: 'lane1' },
  { x: 7.5, y: 32.9, r: 2.8, kind: 'lane', id: 'lane2' },
  { x: -11.5, y: -3.5, r: 2.3, kind: 'scoop', id: 'scoop' },
  { x: -2.5, y: 6.2, r: 2.2, kind: 'spinner', id: 'spinner' },
  { x: -19.5, y: 18, r: 2.4, kind: 'orbit', id: 'orbitL' },
  { x: -14.0, y: -27.0, r: 1.8, kind: 'inlane', id: 'inlaneL' },
  { x: 12.2, y: -26.8, r: 1.8, kind: 'inlane', id: 'inlaneR' },
  // Ramp & tunnel are sensors only — the ball is captured and rides a 3D path,
  // so they never introduce a collision gap.
  { x: -18.2, y: 7.2, r: 2.15, kind: 'ramp', id: 'ramp' },
  { x: 6.2, y: -8.0, r: 1.85, kind: 'tunnel', id: 'tunnel' },
];

// Drop-target "doors". r=1.05, centres 2.2 apart so the ball cannot squeeze
// between them while they're up. 6.8 from the left wall (need 4.50). Lowest
// target is 5.9 from L2 (need 5.30). When dropped they have no collision.
export const DROP_TARGETS: CircleBody[] = [
  { x: -15.2, y: 12.2, r: 1.05, kind: 'drop', id: 0 },
  { x: -15.2, y: 14.4, r: 1.05, kind: 'drop', id: 1 },
  { x: -15.2, y: 16.6, r: 1.05, kind: 'drop', id: 2 },
];

// Left-orbit wire ramp. Rises along the left wall, sails over the raised deck
// (staying above the deck's own side rails at ~6.3), then dives down the right
// side and feeds the right flipper. Every point was checked for >= one-rail
// clearance from bumpers, posts, drop doors and the upper deck rails.
export const RAMP_PATH: PathPt[] = [
  { x: -18.2, y: 7.2, h: 0.3 },
  { x: -19.0, y: 12.8, h: 2.0 },
  { x: -19.2, y: 18.8, h: 3.8 },
  { x: -16.2, y: 24.8, h: 6.2 },
  { x: -11.5, y: 29.6, h: 7.7 },
  { x: -6.0, y: 31.2, h: 7.8 },
  { x: -0.5, y: 31.2, h: 7.8 },
  { x: 5.0, y: 31.2, h: 7.6 },
  { x: 7.0, y: 26.5, h: 7.9 },
  { x: 9.2, y: 24.6, h: 8.3 },
  { x: 12.5, y: 23.5, h: 8.6 },
  { x: 14.8, y: 19.0, h: 5.4 },
  { x: 14.6, y: 9.6, h: 0.4 },
];
export const RAMP_EXIT = { vx: -6, vy: -95 };
export const RAMP_DUR = 1.6;

// Wormhole conduit — climbs the right flank, crosses between the bumper clusters
// (each transit keeps the 1.05-radius tube >= ~0.25 clear of every boosted bumper),
// then bends down the west corridor and spits the ball up toward the drop doors.
export const TUNNEL_PATH: PathPt[] = [
  { x: 6.2, y: -8.0, h: 0.3 },
  { x: 5.4, y: -2.0, h: 1.6 },
  { x: 5.8, y: 3.5, h: 2.5 },
  { x: 5.5, y: 8.5, h: 3.4 },
  { x: 3.2, y: 9.8, h: 3.9 },
  { x: 1.9, y: 15.0, h: 4.5 },
  { x: 2.0, y: 17.3, h: 4.9 },
  { x: -2.8, y: 17.15, h: 4.85 },
  { x: -5.0, y: 17.9, h: 4.75 },
  { x: -9.2, y: 17.9, h: 4.55 },
  { x: -10.8, y: 17.3, h: 4.4 },
  { x: -11.0, y: 12.0, h: 3.2 },
  { x: -11.2, y: 7.5, h: 2.0 },
  { x: -11.9, y: 5.0, h: 0.3 },
];
// Ejects the ball straight up the west corridor — into the drop-door bank.
export const TUNNEL_EXIT = { vx: -6.5, vy: 78 };
export const TUNNEL_DUR = 1.7;

export const SKILL_ZONE: [number, number] = [0.32, 0.48];

export interface BallState {
  id: number;
  x: number; y: number;
  vx: number; vy: number;
  active: boolean;
  inLane: boolean;
  captured: number; // seconds remaining captured
  captureCooldown: number;
  inside: Set<string>;
  spin: number;
  h?: number; // smoothed render height (raised deck / ramps)
  stuck?: number; // seconds spent barely moving — drives the auto un-wedge
  autoLaunch?: number; // countdown to auto launch (multiball)
  ride?: {
    kind: 'ramp' | 'tunnel';
    t: number;
    dur: number;
    exitVx: number;
    exitVy: number;
  };
}

export interface FlipperState {
  angle: number;
  angVel: number;
  pressed: boolean;
}

export type PhysEventType =
  | 'bumper' | 'sling' | 'post' | 'target' | 'lane' | 'scoop' | 'scoopEject'
  | 'spinner' | 'orbit' | 'inlane' | 'drain' | 'laneLaunch' | 'wall'
  | 'drop' | 'ramp' | 'rampEject' | 'tunnel' | 'tunnelEject' | 'kickback';

export interface PhysEvent {
  type: PhysEventType;
  id?: string | number;
  x: number; y: number;
  speed?: number;
}
