import { create } from 'zustand';
import { BallState, FlipperState, LEFT_REST, RIGHT_REST, PLUNGER_X, PLUNGER_REST_Y, SKILL_ZONE } from './constants';
import { sound } from './audio';
import { DIFF, DIFFS, DIFF_ORDER, applyDifficulty, type DiffId } from './difficulty';

// ---------- Mutable real-time ref (physics + visuals, 60fps, no react re-render) ----------
export interface MutableGame {
  balls: BallState[];
  left: FlipperState;
  right: FlipperState;
  plungerPower: number;
  plungerCharging: boolean;
  nextBallId: number;
  time: number;
  shake: number; // trauma 0..1
  flashes: {
    bumpers: number[]; // 0..1 intensity
    slingL: number;
    slingR: number;
    lanes: number[];
    scoop: number;
    spinner: number;
    orbit: number;
    targets: Record<string, number>;
    drain: number;
    jackpot: number;
    ramp: number;
    tunnel: number;
    kickback: number;
    drops: number[];
  };
  dropDown: boolean[];
  spinnerAngle: number;
  spinnerVel: number;
  bumperCombo: number;
  bumperComboTimer: number;
  nudgeTimes: number[];
  tiltedUntil: number;
  tiltWarnings: number;
  pendingNudge: { x: number; y: number };
  launchCooldown: number;
  stuckTimer: number;
  searchCount: number;
  autoLaunchQueue: number; // balls waiting to auto-launch
  skillWindow: number; // seconds after launch where skill shot counts
  lastLaunchPower: number;
  paused: boolean;
}

export const gameRef: MutableGame = {
  balls: [],
  left: { angle: LEFT_REST, angVel: 0, pressed: false },
  right: { angle: RIGHT_REST, angVel: 0, pressed: false },
  plungerPower: 0,
  plungerCharging: false,
  nextBallId: 1,
  time: 0,
  shake: 0,
  flashes: {
    bumpers: [0, 0, 0, 0, 0],
    slingL: 0,
    slingR: 0,
    lanes: [0, 0, 0],
    scoop: 0,
    spinner: 0,
    orbit: 0,
    targets: {},
    drain: 0,
    jackpot: 0,
    ramp: 0,
    tunnel: 0,
    kickback: 0,
    drops: [0, 0, 0],
  },
  dropDown: [false, false, false],
  spinnerAngle: 0,
  spinnerVel: 0,
  bumperCombo: 0,
  bumperComboTimer: 0,
  nudgeTimes: [],
  tiltedUntil: 0,
  tiltWarnings: 0,
  pendingNudge: { x: 0, y: 0 },
  launchCooldown: 0,
  stuckTimer: 0,
  searchCount: 0,
  autoLaunchQueue: 0,
  skillWindow: 0,
  lastLaunchPower: 0,
  paused: false,
};

export function resetMutable() {
  gameRef.balls = [];
  gameRef.left = { angle: LEFT_REST, angVel: 0, pressed: false };
  gameRef.right = { angle: RIGHT_REST, angVel: 0, pressed: false };
  gameRef.plungerPower = 0;
  gameRef.plungerCharging = false;
  gameRef.shake = 0;
  gameRef.flashes = {
    bumpers: [0, 0, 0, 0, 0],
    slingL: 0,
    slingR: 0,
    lanes: [0, 0, 0],
    scoop: 0,
    spinner: 0,
    orbit: 0,
    targets: {},
    drain: 0,
    jackpot: 0,
    ramp: 0,
    tunnel: 0,
    kickback: 0,
    drops: [0, 0, 0],
  };
  gameRef.dropDown = [false, false, false];
  gameRef.spinnerAngle = 0;
  gameRef.spinnerVel = 0;
  gameRef.bumperCombo = 0;
  gameRef.bumperComboTimer = 0;
  gameRef.nudgeTimes = [];
  gameRef.tiltedUntil = 0;
  gameRef.tiltWarnings = 0;
  gameRef.pendingNudge = { x: 0, y: 0 };
  gameRef.autoLaunchQueue = 0;
  gameRef.skillWindow = 0;
  gameRef.launchCooldown = 0;
  gameRef.stuckTimer = 0;
  gameRef.searchCount = 0;
}

export function spawnBallInLane(autoLaunchAfter?: number): BallState {
  const b: BallState = {
    id: gameRef.nextBallId++,
    x: PLUNGER_X,
    y: PLUNGER_REST_Y,
    vx: 0,
    vy: 0,
    active: true,
    inLane: true,
    captured: 0,
    captureCooldown: 0,
    inside: new Set(),
    spin: 0,
    autoLaunch: autoLaunchAfter,
  };
  gameRef.balls.push(b);
  return b;
}

export function spawnBallAt(x: number, y: number, vx: number, vy: number): BallState {
  const b: BallState = {
    id: gameRef.nextBallId++,
    x, y, vx, vy,
    active: true,
    inLane: false,
    captured: 0,
    captureCooldown: 1,
    inside: new Set(),
    spin: 0,
  };
  gameRef.balls.push(b);
  return b;
}

export function isTilted() {
  return gameRef.time < gameRef.tiltedUntil;
}

// ---------- Zustand UI store ----------
export type Phase = 'attract' | 'playing' | 'gameover';
export type BallPhase = 'plunger' | 'active' | 'bonus';
export type CameraMode = 'auto' | 'broadcast' | 'top' | 'cinematic';

export interface ScorePopup { id: number; text: string; sub?: string; t: number }

interface GameStore {
  phase: Phase;
  ballPhase: BallPhase;
  score: number;
  highScore: number;
  ball: number;
  totalBalls: number;
  multiplier: number;
  bonus: number;
  message: string;
  messageT: number;
  bigMessage: string;
  bigMessageT: number;
  lanes: boolean[];
  leftTargets: boolean[];
  rightTargets: boolean[];
  centerTargets: boolean[];
  scoopLit: boolean;
  jackpotLit: boolean;
  multiball: boolean;
  multiballT: number;
  tiltWarnings: number;
  tilted: boolean;
  plungerPower: number;
  plungerCharging: boolean;
  leftPressed: boolean;
  rightPressed: boolean;
  muted: boolean;
  cameraMode: CameraMode;
  shakeEnabled: boolean;
  popups: ScorePopup[];
  nextPopupId: number;
  bonusCounting: boolean;
  bonusDisplay: number;
  lastSkill: string;
  extraBallsAwarded: number[];
  showHelp: boolean;
  ballsInPlay: number;
  stuckHint: boolean;
  dropTargets: boolean[];
  kickbackLit: boolean;
  rampLit: boolean;
  combo: number;
  rampChain: number;
  difficulty: DiffId;

  setDifficulty: (id: DiffId) => void;
  cycleDifficulty: (dir: 1 | -1) => void;
  ballSearch: () => void;
  reserveBall: () => void;
  startGame: () => void;
  toAttract: () => void;
  setFlipper: (side: 'left' | 'right', pressed: boolean) => void;
  setPlunger: (charging: boolean, power?: number) => void;
  releasePlunger: () => void;
  nudge: (dir: 'left' | 'right' | 'up') => void;
  addScore: (pts: number, label?: string) => void;
  popup: (text: string, sub?: string) => void;
  setMessage: (m: string) => void;
  setBigMessage: (m: string) => void;
  onBumper: (id: number, combo: number) => void;
  onSling: (side: string) => void;
  onPost: () => void;
  onTarget: (id: string) => void;
  onLane: (idx: number) => void;
  onInlane: (id: string) => void;
  onScoop: () => void;
  onScoopEject: () => void;
  onSpinner: () => void;
  onOrbit: () => void;
  onDrop: (idx: number) => void;
  onRamp: () => void;
  onRampEject: () => void;
  onTunnel: () => void;
  onTunnelEject: () => void;
  onDrain: (ballId: number) => void;
  onLaunch: (power: number) => void;
  endBall: () => void;
  finishBonus: () => void;
  triggerTilt: () => void;
  startMultiball: () => void;
  tickMultiball: (dt: number) => void;
  toggleMute: () => void;
  setCamera: (m: CameraMode) => void;
  cycleCamera: () => void;
  toggleShake: () => void;
  toggleHelp: () => void;
  setPaused: (p: boolean) => void;
  paused: boolean;
  syncBalls: (n: number) => void;
}

const loadHigh = () => {
  try { return Number(localStorage.getItem('neon-nova-high') || 0); } catch { return 0; }
};

let bonusInterval: any = null;
let lastShot = '';
let lastShotT = 0;
let lastRampAt = -99;

function noteCombo(
  get: () => GameStore,
  set: (p: Partial<GameStore>) => void,
  shot: string,
) {
  const now = Date.now();
  if (lastShot && lastShot !== shot && now - lastShotT < 7000) {
    const combo = get().combo + 1;
    set({ combo });
    const pts = 1800 * combo;
    get().addScore(pts, `COMBO x${combo}`);
    if (combo >= 3) get().setBigMessage(`COMBO x${combo}`);
  } else {
    set({ combo: 1 });
  }
  lastShot = shot;
  lastShotT = now;
}

export const useGame = create<GameStore>()((set, get) => ({
  phase: 'attract',
  ballPhase: 'plunger',
  score: 0,
  highScore: loadHigh(),
  ball: 1,
  totalBalls: 3,
  multiplier: 1,
  bonus: 0,
  message: 'PRESS ENTER TO START',
  messageT: 0,
  bigMessage: '',
  bigMessageT: 0,
  lanes: [false, false, false],
  leftTargets: [false, false, false],
  rightTargets: [false, false, false],
  centerTargets: [false, false],
  scoopLit: true,
  jackpotLit: false,
  multiball: false,
  multiballT: 0,
  tiltWarnings: 0,
  tilted: false,
  plungerPower: 0,
  plungerCharging: false,
  leftPressed: false,
  rightPressed: false,
  muted: false,
  cameraMode: 'auto',
  shakeEnabled: true,
  popups: [],
  nextPopupId: 1,
  bonusCounting: false,
  bonusDisplay: 0,
  lastSkill: '',
  extraBallsAwarded: [],
  showHelp: false,
  paused: false,
  ballsInPlay: 0,
  stuckHint: false,
  dropTargets: [false, false, false],
  kickbackLit: false,
  rampLit: false,
  combo: 0,
  rampChain: 0,
  difficulty: DIFF.id as DiffId,

  setDifficulty: (id) => {
    applyDifficulty(id);
    try { localStorage.setItem('neon-nova-diff', id); } catch { /* noop */ }
    const st = get();
    set({
      difficulty: id,
      message: st.phase === 'playing' ? `DIFFICULTY: ${DIFFS[id].label}` : `MODE ${DIFFS[id].label} — ${DIFFS[id].blurb}`,
      messageT: Date.now(),
    });
  },

  cycleDifficulty: (dir) => {
    const i = DIFF_ORDER.indexOf(get().difficulty);
    const next = DIFF_ORDER[(i + dir + DIFF_ORDER.length) % DIFF_ORDER.length];
    get().setDifficulty(next);
  },

  // Frees a ball that has come to rest somewhere it cannot escape from.
  ballSearch: () => {
    if (get().phase !== 'playing') return;
    let kicked = false;
    for (const b of gameRef.balls) {
      if (!b.active || b.captured > 0 || b.ride || b.autoLaunch !== undefined) continue;
      b.vx += (Math.random() - 0.5) * 95;
      b.vy += 72;
      kicked = true;
    }
    if (!kicked) return;
    gameRef.shake = Math.min(1, gameRef.shake + 0.45);
    sound.nudge();
    get().setMessage('BALL SEARCH — KICKING BALL FREE');
  },

  // Re-serves a fresh ball to the plunger without costing the player a ball.
  reserveBall: () => {
    if (get().phase !== 'playing') return;
    for (const b of gameRef.balls) b.active = false;
    gameRef.balls = [];
    gameRef.stuckTimer = 0;
    gameRef.searchCount = 0;
    gameRef.plungerCharging = false;
    gameRef.plungerPower = 0;
    spawnBallInLane();
    sound.eject();
    set({
      ballPhase: 'plunger',
      plungerCharging: false,
      plungerPower: 0,
      ballsInPlay: 1,
      multiball: false,
      multiballT: 0,
      stuckHint: false,
      message: 'BALL RE-SERVED — NO BALL LOST',
      messageT: Date.now(),
      bigMessage: 'BALL RESET',
      bigMessageT: Date.now(),
    });
    setTimeout(() => {
      if (get().bigMessage === 'BALL RESET') set({ bigMessage: '' });
    }, 1500);
  },

  startGame: () => {
    sound.ensure();
    sound.start();
    resetMutable();
    lastShot = '';
    lastShotT = 0;
    lastRampAt = -99;
    spawnBallInLane();
    set({
      phase: 'playing', ballPhase: 'plunger', score: 0, ball: 1, totalBalls: 3,
      multiplier: 1, bonus: 0, lanes: [false, false, false],
      leftTargets: [false, false, false], rightTargets: [false, false, false],
      centerTargets: [false, false], scoopLit: true, jackpotLit: false,
      multiball: false, multiballT: 0, tiltWarnings: 0, tilted: false,
      plungerPower: 0, plungerCharging: false, popups: [], bonusCounting: false,
      bonusDisplay: 0, extraBallsAwarded: [], ballsInPlay: 1, stuckHint: false,
      dropTargets: [false, false, false], kickbackLit: false, rampLit: false, combo: 0, rampChain: 0,
      difficulty: DIFF.id as DiffId,
      message: `${DIFF.label} MODE — BALL 1 — HOLD SPACE TO PLUNGE`, messageT: Date.now(),
      bigMessage: 'BALL 1', bigMessageT: Date.now(),
    });
  },

  toAttract: () => {
    resetMutable();
    // attract mode demo ball
    spawnBallAt(0, 10, 30, 0);
    set({ phase: 'attract', bigMessage: '', message: `MODE ${DIFF.label} — PRESS ENTER TO START` });
  },

  setFlipper: (side, pressed) => {
    if (side === 'left') {
      gameRef.left.pressed = pressed;
      set({ leftPressed: pressed });
    } else {
      gameRef.right.pressed = pressed;
      set({ rightPressed: pressed });
    }
    if (!get().muted) {
      if (pressed) sound.flipperUp();
      else sound.flipperDown();
    }
  },

  setPlunger: (charging, power) => {
    gameRef.plungerCharging = charging;
    if (power !== undefined) gameRef.plungerPower = power;
    set({ plungerCharging: charging, plungerPower: power ?? get().plungerPower });
  },

  releasePlunger: () => {
    const s = get();
    if (s.phase !== 'playing' || s.ballPhase !== 'plunger') return;
    const power = gameRef.plungerPower;
    const ball = gameRef.balls.find(b => b.active && b.inLane && b.autoLaunch === undefined);
    if (!ball) return;
    const v = (80 + power * 175) * DIFF.launch;
    ball.vy = v;
    ball.vx = (Math.random() - 0.5) * 4;
    ball.inLane = true; // still in lane until it exits top
    gameRef.lastLaunchPower = power;
    gameRef.skillWindow = 5;
    gameRef.plungerCharging = false;
    gameRef.plungerPower = 0;
    sound.launch(power);
    gameRef.shake = Math.min(1, gameRef.shake + 0.12 + power * 0.15);
    set({ plungerCharging: false, plungerPower: 0, ballPhase: 'active', ballsInPlay: gameRef.balls.filter(b => b.active).length });
    get().onLaunch(power);
  },

  nudge: (dir) => {
    const s = get();
    if (s.phase !== 'playing' || s.paused) return;
    if (isTilted()) return;
    sound.ensure();
    const now = gameRef.time;
    gameRef.nudgeTimes = gameRef.nudgeTimes.filter(t => now - t < 2.5);
    gameRef.nudgeTimes.push(now);
    const force = DIFF.nudge;
    if (dir === 'left') { gameRef.pendingNudge.x -= force; gameRef.pendingNudge.y += 8; }
    if (dir === 'right') { gameRef.pendingNudge.x += force; gameRef.pendingNudge.y += 8; }
    if (dir === 'up') { gameRef.pendingNudge.y += force * 0.9; }
    gameRef.shake = Math.min(1, gameRef.shake + 0.35);
    sound.nudge();
    const limit = DIFF.tiltLimit;
    const len = gameRef.nudgeTimes.length;
    if (len >= limit) {
      get().triggerTilt();
    } else if (len === limit - 1) {
      set({ tiltWarnings: 2 });
      get().setMessage('TILT WARNING — EASY!');
      sound.warn();
      gameRef.tiltWarnings = 2;
    } else if (len === limit - 2) {
      set({ tiltWarnings: 1 });
      gameRef.tiltWarnings = 1;
    }
  },

  addScore: (pts, label) => {
    const s = get();
    if (s.phase !== 'playing') return;
    if (isTilted()) return;
    const mult = s.multiball ? s.multiplier * 2 : s.multiplier;
    const gain = Math.round(pts * mult * DIFF.score);
    const score = s.score + gain;
    const patch: Partial<GameStore> = { score, bonus: s.bonus + Math.round(pts * 0.1 * DIFF.score) };
    if (score > s.highScore) {
      patch.highScore = score;
      try { localStorage.setItem('neon-nova-high', String(score)); } catch { /* noop */ }
    }
    // extra balls at 120k, 300k, 600k
    const thresholds = [120000, 300000, 600000].map((t) => Math.round(t * DIFF.score));
    thresholds.forEach((th, i) => {
      if (score >= th && !s.extraBallsAwarded.includes(i)) {
        patch.extraBallsAwarded = [...s.extraBallsAwarded, i];
        patch.totalBalls = s.totalBalls + 1;
        setTimeout(() => {
          get().popup('EXTRA BALL!', 'SHOOT AGAIN');
          get().setBigMessage('EXTRA BALL');
          sound.extraBall();
        }, 300);
      }
    });
    set(patch);
    if (label && gain >= 1000) get().popup(`+${gain.toLocaleString()}`, label);
  },

  popup: (text, sub) => {
    const id = get().nextPopupId;
    set({ nextPopupId: id + 1, popups: [...get().popups.slice(-4), { id, text, sub, t: Date.now() }] });
    setTimeout(() => {
      set({ popups: get().popups.filter(p => p.id !== id) });
    }, 2200);
  },

  setMessage: (m) => set({ message: m, messageT: Date.now() }),
  setBigMessage: (m) => {
    set({ bigMessage: m, bigMessageT: Date.now() });
    setTimeout(() => {
      if (get().bigMessage === m) set({ bigMessage: '' });
    }, 1800);
  },

  onBumper: (id, combo) => {
    gameRef.flashes.bumpers[id] = 1;
    gameRef.shake = Math.min(1, gameRef.shake + 0.08);
    sound.bumper(combo);
    const pts = 120 + Math.min(combo, 15) * 25;
    get().addScore(pts);
    if (combo > 0 && combo % 8 === 0) {
      get().popup(`COMBO x${combo}`, 'BUMPER FRENZY');
    }
  },

  onSling: (side) => {
    if (side.includes('L')) gameRef.flashes.slingL = 1; else gameRef.flashes.slingR = 1;
    gameRef.shake = Math.min(1, gameRef.shake + 0.1);
    sound.sling();
    get().addScore(80);
  },

  onPost: () => {
    sound.post();
    get().addScore(30);
  },

  onTarget: (id) => {
    gameRef.flashes.targets[id] = 1;
    sound.target();
    gameRef.shake = Math.min(1, gameRef.shake + 0.06);
    const s = get();
    let { leftTargets, rightTargets, centerTargets } = s;
    if (id[0] === 'L') {
      const i = Number(id[1]);
      if (leftTargets[i]) { get().addScore(250); return; }
      leftTargets = [...leftTargets]; leftTargets[i] = true;
      set({ leftTargets });
      get().addScore(600, leftTargets.every(Boolean) ? 'LEFT BANK COMPLETE!' : undefined);
      get().setMessage('LEFT TARGET DOWN');
    } else if (id[0] === 'R') {
      const i = Number(id[1]);
      if (rightTargets[i]) { get().addScore(250); return; }
      rightTargets = [...rightTargets]; rightTargets[i] = true;
      set({ rightTargets });
      get().addScore(600, rightTargets.every(Boolean) ? 'RIGHT BANK COMPLETE!' : undefined);
      get().setMessage('RIGHT TARGET DOWN');
    } else {
      const i = Number(id[1]);
      if (centerTargets[i]) { get().addScore(250); return; }
      centerTargets = [...centerTargets]; centerTargets[i] = true;
      set({ centerTargets });
      get().addScore(800, centerTargets.every(Boolean) ? 'CENTER COMPLETE!' : undefined);
      if (centerTargets.every(Boolean)) {
        set({ centerTargets: [false, false], jackpotLit: true });
        get().setBigMessage('JACKPOT LIT');
        get().setMessage('SHOOT THE SCOOP FOR JACKPOT');
        sound.jackpot();
        gameRef.flashes.jackpot = 1;
      }
      return;
    }
    // bank completion
    const L = get().leftTargets; const R = get().rightTargets;
    if (L.every(Boolean) && R.every(Boolean)) {
      get().addScore(8000, 'BANKS COMPLETE');
      get().startMultiball();
      set({ leftTargets: [false, false, false], rightTargets: [false, false, false] });
    } else if (L.every(Boolean) || R.every(Boolean)) {
      get().addScore(2500);
      get().setMessage('BANK COMPLETE — FINISH BOTH FOR MULTIBALL');
    }
  },

  onLane: (idx) => {
    gameRef.flashes.lanes[idx] = 1;
    sound.lane();
    const s = get();
    if (s.lanes[idx]) { get().addScore(150); return; }
    const lanes = [...s.lanes]; lanes[idx] = true;
    // skill shot check
    if (gameRef.skillWindow > 0) {
      const p = gameRef.lastLaunchPower;
      if (p >= SKILL_ZONE[0] && p <= SKILL_ZONE[1]) {
        get().addScore(15000, 'SKILL SHOT!');
        get().setBigMessage('SKILL SHOT +15K');
        sound.skillshot();
        gameRef.skillWindow = 0;
        set({ lanes });
        return;
      }
    }
    get().addScore(400);
    if (lanes.every(Boolean)) {
      const mult = Math.min(5, s.multiplier + 1);
      set({ lanes: [false, false, false], multiplier: mult });
      get().addScore(2500, mult >= 5 ? 'MAX MULTIPLIER 5X!' : `MULTIPLIER ${mult}X`);
      get().setBigMessage(mult >= 5 ? 'MAX 5X!' : `${mult}X MULTIPLIER`);
      sound.jackpot();
    } else {
      set({ lanes });
      get().setMessage(`LANE ${idx + 1}/3 — LIGHT ALL FOR MULTIPLIER`);
    }
  },

  onInlane: (id) => {
    sound.inlane();
    get().addScore(200);
    const s = get();
    if (id === 'inlaneL' && s.kickbackLit) {
      const b = gameRef.balls.find((ball) => ball.active && ball.inside.has('inlaneL') && !ball.ride);
      if (b) {
        b.vy = 158;
        b.vx = 16;
        b.stuck = 0;
        set({ kickbackLit: false });
        gameRef.flashes.kickback = 1;
        gameRef.shake = Math.min(1, gameRef.shake + 0.35);
        sound.eject();
        get().addScore(2500, 'KICKBACK!');
        get().setBigMessage('KICKBACK');
      }
    }
    const lanes = [s.lanes[2], s.lanes[0], s.lanes[1]];
    if (JSON.stringify(lanes) !== JSON.stringify(s.lanes)) set({ lanes });
  },

  onScoop: () => {
    gameRef.flashes.scoop = 1;
    sound.scoop();
    const s = get();
    if (s.jackpotLit) {
      set({ jackpotLit: false, centerTargets: [false, false] });
      get().addScore(25000, 'JACKPOT!!!');
      get().setBigMessage('JACKPOT 25K!');
      sound.jackpot();
      gameRef.flashes.jackpot = 1;
      gameRef.shake = Math.min(1, gameRef.shake + 0.5);
    } else if (s.multiball) {
      get().addScore(5000, 'MULTIBALL SCOOP');
      sound.jackpot();
    } else {
      get().addScore(2500, 'SCOOP!');
      get().setMessage('SCOOP — CENTER TARGETS LIGHT JACKPOT');
    }
  },

  onScoopEject: () => {
    sound.eject();
  },

  onSpinner: () => {
    gameRef.flashes.spinner = Math.min(1, gameRef.flashes.spinner + 0.5);
    gameRef.spinnerVel += 14;
    sound.spinner();
    get().addScore(180);
  },

  onOrbit: () => {
    gameRef.flashes.orbit = 1;
    sound.orbit();
    get().addScore(1200, 'ORBIT SHOT');
    get().setMessage('ORBIT SHOT!');
    noteCombo(get, set, 'orbit');
  },

  onDrop: (idx) => {
    gameRef.flashes.drops[idx] = 1;
    sound.target();
    gameRef.shake = Math.min(1, gameRef.shake + 0.1);
    const dropTargets = [...get().dropTargets];
    dropTargets[idx] = true;
    set({ dropTargets });
    get().addScore(800);
    if (dropTargets.every(Boolean)) {
      get().addScore(7500, 'DOORS OPEN!');
      get().setBigMessage('DOORS OPEN');
      get().setMessage('KICKBACK LIT • RAMP 3X');
      sound.jackpot();
      set({ kickbackLit: true, rampLit: true });
      gameRef.flashes.jackpot = 1;
      gameRef.shake = Math.min(1, gameRef.shake + 0.4);
      setTimeout(() => {
        gameRef.dropDown = [false, false, false];
        set({ dropTargets: [false, false, false] });
      }, 2200);
    } else {
      get().setMessage(`DOOR ${idx + 1}/3 DOWN`);
    }
    noteCombo(get, set, 'drop');
  },

  onRamp: () => {
    gameRef.flashes.ramp = 1;
    gameRef.shake = Math.min(1, gameRef.shake + 0.32);
    sound.ramp();
    const lit = get().rampLit;
    // ramp chain: repeated ramps within 12s escalate by 30% each time
    const now = gameRef.time;
    const chain = now - lastRampAt < 12 ? get().rampChain + 1 : 1;
    lastRampAt = now;
    set({ rampChain: chain });
    const base = lit ? 9000 : 3500;
    const pts = Math.round(base * (1 + 0.3 * (chain - 1)));
    get().addScore(pts, chain > 1 ? `RAMP x${chain}!` : lit ? 'SUPER RAMP!' : 'RAMP');
    if (lit) {
      set({ rampLit: false });
      get().setBigMessage('SUPER RAMP');
    } else if (chain > 1) {
      get().setBigMessage(`RAMP x${chain}`);
    } else {
      get().setMessage('RAMP SHOT — DROP THE DOORS FOR 3X');
    }
    noteCombo(get, set, 'ramp');
  },

  onRampEject: () => {
    sound.eject();
  },

  onTunnel: () => {
    gameRef.flashes.tunnel = 1;
    gameRef.shake = Math.min(1, gameRef.shake + 0.22);
    sound.tunnel();
    get().addScore(2200, 'WORMHOLE');
    // mystery award
    const roll = Math.random();
    if (roll < 0.22) {
      set({ kickbackLit: true });
      get().popup('KICKBACK LIT', 'WORMHOLE');
      get().setMessage('WORMHOLE — KICKBACK LIT');
    } else if (roll < 0.4) {
      const m = Math.min(5, get().multiplier + 1);
      set({ multiplier: m });
      get().popup(`${m}X MULTIPLIER`, 'WORMHOLE');
      get().setBigMessage(`${m}X`);
    } else if (roll < 0.55) {
      get().addScore(8000, 'WORMHOLE JACKPOT');
      get().setBigMessage('+8K MYSTERY');
    } else if (roll < 0.7 && !get().jackpotLit) {
      set({ jackpotLit: true });
      get().popup('JACKPOT LIT', 'WORMHOLE');
      get().setMessage('WORMHOLE — JACKPOT LIT, SHOOT SCOOP');
    } else {
      get().addScore(1500);
      get().setMessage('WORMHOLE TRANSIT');
    }
    noteCombo(get, set, 'tunnel');
  },

  onTunnelEject: () => {
    sound.eject();
  },

  onDrain: (_ballId) => {
    void _ballId;
    gameRef.flashes.drain = 1;
    const remaining = gameRef.balls.filter(b => b.active);
    set({ ballsInPlay: remaining.length });
    if (remaining.length > 0) {
      get().setMessage('BALL DRAINED — MULTIBALL CONTINUES!');
      sound.drain();
      return;
    }
    // all drained
    sound.drain();
    gameRef.shake = Math.min(1, gameRef.shake + 0.4);
    if (get().ballPhase === 'bonus') return;
    set({ ballPhase: 'bonus', bonusCounting: true, multiball: false, multiballT: 0 });
    get().endBall();
  },

  onLaunch: (power) => {
    set({ ballPhase: 'active' });
    const inZone = power >= SKILL_ZONE[0] && power <= SKILL_ZONE[1];
    if (inZone) {
      get().setMessage('SKILL SHOT WINDOW — HIT A TOP LANE!');
    } else if (power < SKILL_ZONE[0]) {
      get().setMessage('WEAK LAUNCH...');
    } else {
      get().setMessage('FULL POWER!');
    }
  },

  endBall: () => {
    const s = get();
    const bonus = Math.round(s.bonus * s.multiplier);
    set({ bonusDisplay: 0 });
    // count up bonus
    if (bonusInterval) clearInterval(bonusInterval);
    let shown = 0;
    const step = Math.max(100, Math.round(bonus / 24));
    bonusInterval = setInterval(() => {
      shown += step;
      if (shown >= bonus) {
        shown = bonus;
        clearInterval(bonusInterval);
        setTimeout(() => get().finishBonus(), 650);
      } else {
        sound.bonusTick();
      }
      set({ bonusDisplay: shown });
    }, 55);
    if (bonus <= 0) {
      clearInterval(bonusInterval);
      setTimeout(() => get().finishBonus(), 700);
    }
  },

  finishBonus: () => {
    const s = get();
    const bonus = Math.round(s.bonus * s.multiplier);
    let score = s.score + bonus;
    let highScore = s.highScore;
    if (score > highScore) {
      highScore = score;
      try { localStorage.setItem('neon-nova-high', String(score)); } catch { /* noop */ }
    }
    if (s.ball >= s.totalBalls) {
      sound.gameOver();
      set({
        phase: 'gameover', score, highScore, bonusCounting: false,
        bigMessage: 'GAME OVER', bigMessageT: Date.now(),
        message: score >= highScore && score > 0 ? 'NEW HIGH SCORE!' : 'PRESS ENTER TO PLAY AGAIN',
      });
      // attract demo ball
      resetMutable();
      spawnBallAt(0, 12, 40, 10);
    } else {
      const nb = s.ball + 1;
      resetMutable();
      spawnBallInLane();
      sound.start();
      set({
        ball: nb, score, highScore, bonus: 0, multiplier: Math.max(1, s.multiplier - 0 > 0 ? 1 : 1),
        lanes: [false, false, false],
        leftTargets: [false, false, false], rightTargets: [false, false, false],
        centerTargets: [false, false], jackpotLit: false, multiball: false,
        dropTargets: [false, false, false], kickbackLit: false, rampLit: false, combo: 0, rampChain: 0,
        ballPhase: 'plunger', bonusCounting: false, bonusDisplay: 0, tiltWarnings: 0, tilted: false,
        ballsInPlay: 1,
        bigMessage: `BALL ${nb}`, bigMessageT: Date.now(),
        message: `BALL ${nb} — HOLD SPACE TO PLUNGE`,
      });
    }
  },

  triggerTilt: () => {
    gameRef.tiltedUntil = gameRef.time + 5;
    gameRef.tiltWarnings = 0;
    gameRef.left.pressed = false;
    gameRef.right.pressed = false;
    sound.tilt();
    gameRef.shake = 1;
    set({
      tilted: true, tiltWarnings: 0, leftPressed: false, rightPressed: false,
      bigMessage: 'TILT!', bigMessageT: Date.now(), message: 'TILT — FLIPPERS DEAD FOR 5s',
    });
    setTimeout(() => {
      set({ tilted: false, message: 'RECOVERED — EASY ON THE NUDGE' });
    }, 5000);
  },

  startMultiball: () => {
    const s = get();
    if (s.multiball) {
      get().addScore(5000, 'MULTIBALL EXTENDED');
      set({ multiballT: DIFF.mbTime });
      return;
    }
    set({ multiball: true, multiballT: DIFF.mbTime });
    get().setBigMessage('MULTIBALL!');
    get().setMessage('MULTIBALL — ALL SCORES 2X!');
    sound.multiball();
    gameRef.shake = Math.min(1, gameRef.shake + 0.6);
    gameRef.flashes.jackpot = 1;
    // queue second ball auto-launch in lane
    const b = spawnBallInLane(0.9);
    void b;
    set({ ballsInPlay: gameRef.balls.filter(x => x.active).length });
  },

  tickMultiball: (dt) => {
    const s = get();
    if (!s.multiball) return;
    const t = s.multiballT - dt;
    if (t <= 0) {
      set({ multiball: false, multiballT: 0, message: 'MULTIBALL OVER' });
    } else {
      set({ multiballT: t });
    }
  },

  toggleMute: () => {
    const m = !get().muted;
    sound.setEnabled(!m);
    set({ muted: m });
  },
  setCamera: (m) => set({ cameraMode: m }),
  cycleCamera: () => {
    const order: CameraMode[] = ['auto', 'broadcast', 'top', 'cinematic'];
    const cur = get().cameraMode;
    set({ cameraMode: order[(order.indexOf(cur) + 1) % order.length] });
  },
  toggleShake: () => set({ shakeEnabled: !get().shakeEnabled }),
  toggleHelp: () => set({ showHelp: !get().showHelp }),
  setPaused: (p) => {
    gameRef.paused = p;
    set({ paused: p });
  },
  syncBalls: (n) => set({ ballsInPlay: n }),
}));
