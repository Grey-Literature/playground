// Difficulty system: velocity scaling, physics reactivity, and progressive obstacles.
// Every knob here feeds physics.ts directly. Obstacles are gated per-tier and each
// tier is validated by scripts/stuckcheck.ts (ball-wedge soak test).

export type DiffId = 'supereasy' | 'easy' | 'medium' | 'hard' | 'impossible';
export type ObKey = 'extraBumpers' | 'topPosts' | 'wrecker' | 'frickies';

export interface DifficultyCfg {
  id: DiffId;
  label: string;
  blurb: string;
  accent: string;
  launch: number;      // plunger + auto-launch velocity scale
  grav: number;        // gravity scale (super easy literally plays slower)
  rest: number;        // bounciness of everything (reactivity)
  bumperKick: number;
  slingKick: number;
  frickyKick: number;
  flipperBoost: number;
  flipSpeed: number;   // flipper angular speed scale
  maxSpeed: number;
  nudge: number;       // nudge impulse
  mbTime: number;      // multiball duration (s)
  tiltLimit: number;   // nudges within window before TILT
  score: number;       // global score multiplier reward
  ob: Record<ObKey, boolean>;
}

export const DIFFS: Record<DiffId, DifficultyCfg> = {
  supereasy: {
    id: 'supereasy', label: 'SUPER EASY', accent: '#34d399',
    blurb: 'Slower gravity, dead bumpers, starter obstacles only.',
    launch: 0.84, grav: 0.74, rest: 0.55, bumperKick: 84, slingKick: 70, frickyKick: 0,
    flipperBoost: 2.6, flipSpeed: 0.8, maxSpeed: 210, nudge: 26, mbTime: 35, tiltLimit: 6, score: 0.8,
    ob: { extraBumpers: false, topPosts: false, wrecker: false, frickies: false },
  },
  easy: {
    id: 'easy', label: 'EASY', accent: '#22d3ee',
    blurb: 'Slightly slower, less reactive — plus the upper pop bumpers.',
    launch: 0.92, grav: 0.88, rest: 0.75, bumperKick: 96, slingKick: 82, frickyKick: 0,
    flipperBoost: 3.0, flipSpeed: 0.9, maxSpeed: 235, nudge: 34, mbTime: 30, tiltLimit: 5, score: 0.9,
    ob: { extraBumpers: true, topPosts: false, wrecker: false, frickies: false },
  },
  medium: {
    id: 'medium', label: 'MEDIUM', accent: '#a78bfa',
    blurb: 'Tournament baseline + two extra obstacle sets.',
    launch: 1.0, grav: 1.0, rest: 1.0, bumperKick: 108, slingKick: 92, frickyKick: 0,
    flipperBoost: 3.4, flipSpeed: 1.0, maxSpeed: 260, nudge: 42, mbTime: 25, tiltLimit: 4, score: 1,
    ob: { extraBumpers: true, topPosts: true, wrecker: false, frickies: false },
  },
  hard: {
    id: 'hard', label: 'HARD', accent: '#fb923c',
    blurb: 'Livelier everything — and the Wrecker is spinning.',
    launch: 1.1, grav: 1.14, rest: 1.22, bumperKick: 124, slingKick: 108, frickyKick: 0,
    flipperBoost: 4.1, flipSpeed: 1.12, maxSpeed: 295, nudge: 50, mbTime: 22, tiltLimit: 4, score: 1.25,
    ob: { extraBumpers: true, topPosts: true, wrecker: true, frickies: false },
  },
  impossible: {
    id: 'impossible', label: 'IMPOSSIBLE', accent: '#f43f5e',
    blurb: 'Everything faster, everything bouncier, everything angry.',
    launch: 1.24, grav: 1.3, rest: 1.45, bumperKick: 140, slingKick: 124, frickyKick: 62,
    flipperBoost: 4.8, flipSpeed: 1.25, maxSpeed: 330, nudge: 58, mbTime: 20, tiltLimit: 3, score: 1.5,
    ob: { extraBumpers: true, topPosts: true, wrecker: true, frickies: true },
  },
};

export const DIFF_ORDER: DiffId[] = ['supereasy', 'easy', 'medium', 'hard', 'impossible'];

// Live mutable config — physics/scene read this every frame (no react round-trip).
export const DIFF: DifficultyCfg = { ...DIFFS.medium, ob: { ...DIFFS.medium.ob } };

// The Wrecker's spinning bar lives on the config object so physics + visuals share it.
export const WRECKER = {
  cx: 0, cy: -14.5, half: 5.2, r: 0.55, angle: 0,
  speedFor(id: DiffId) { return id === 'impossible' ? 3.4 : 2.1; },
};

export function applyDifficulty(id: DiffId) {
  const cfg = DIFFS[id];
  Object.assign(DIFF, cfg);
  DIFF.ob = { ...cfg.ob };
  WRECKER.angle = 0;
}

try {
  const saved = localStorage.getItem('neon-nova-diff') as DiffId | null;
  if (saved && DIFFS[saved]) applyDifficulty(saved);
} catch { /* default stays medium */ }

export function obstacleCount(id: DiffId) {
  const ob = DIFFS[id].ob;
  return (Object.keys(ob) as ObKey[]).reduce((n, k) => n + (ob[k] ? 1 : 0), 0);
}
