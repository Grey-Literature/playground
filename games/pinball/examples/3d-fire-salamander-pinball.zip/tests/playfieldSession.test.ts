import assert from 'node:assert/strict';
import test from 'node:test';
import {
  BALL_RADIUS, LOWER_BALL_Y, UPPER_BALL_Y, PLAYFIELD,
  containPlayfield, type FieldBall,
} from '../src/pinballPhysics.ts';
import { selectDifficultyForNextRun } from '../src/pinballSession.ts';

function ball(overrides: Partial<FieldBall> = {}): FieldBall {
  return {
    x: 0, z: 0, y: LOWER_BALL_Y, vx: 0, vz: 0, spin: 0,
    onUpper: false, falling: false, inShooter: false, ramp: -1, hold: 0,
    ...overrides,
  };
}

test('completed score and its best stay tied to the run, not the next intensity', () => {
  const finished = { status: 'gameover' as const, difficulty: 0, scoreDifficulty: 0, score: 12850, best: 12850 };
  const bestFor = (n: number) => n === 4 ? 99 : 1400;
  for (const n of [1, 2, 3, 4]) {
    const next = selectDifficultyForNextRun({ ...finished, difficulty: 0 }, n, bestFor);
    assert.ok(next);
    assert.equal(next.difficulty, n);
    assert.equal(next.scoreDifficulty, 0);
    assert.equal(next.score, 12850);
    assert.equal(next.best, 12850);
    assert.deepEqual(finished, { status: 'gameover', difficulty: 0, scoreDifficulty: 0, score: 12850, best: 12850 });
  }
});

test('difficulty cannot change in flight or while paused, but changes the ready preview', () => {
  const ready = { status: 'ready' as const, difficulty: 0, scoreDifficulty: 0, score: 0, best: 8700 };
  const bestFor = (n: number) => n === 4 ? 350 : 0;
  assert.equal(selectDifficultyForNextRun({ ...ready, status: 'playing' }, 4, bestFor), null);
  assert.equal(selectDifficultyForNextRun({ ...ready, status: 'paused' }, 4, bestFor), null);
  const selected = selectDifficultyForNextRun(ready, 4, bestFor);
  assert.deepEqual(selected, { ...ready, difficulty: 4, scoreDifficulty: 4, best: 350 });
});

test('the lower playfield reflects an extreme miss at the back and both side rails', () => {
  const rail = BALL_RADIUS + 0.075;
  const left = ball({ x: -6, z: 0, vx: -64, vz: -10 });
  const right = ball({ x: 5.9, z: 1, vx: 72, vz: 4 });
  const back = ball({ x: 0, z: -9, vx: 0, vz: -82 });
  assert.ok(containPlayfield(left));
  assert.ok(containPlayfield(right));
  assert.ok(containPlayfield(back));
  assert.ok(left.x >= PLAYFIELD.left + rail);
  assert.ok(right.x <= PLAYFIELD.right - rail);
  assert.ok(back.z >= PLAYFIELD.top + rail);
  assert.ok(left.vx > 0 && right.vx < 0 && back.vz > 0);
});

test('the upper deck contains high-speed side and rear shots but still permits its front drops', () => {
  const rail = BALL_RADIUS + 0.075;
  const left = ball({ onUpper: true, y: UPPER_BALL_Y, x: -6, z: -4.5, vx: -50 });
  const right = ball({ onUpper: true, y: UPPER_BALL_Y, x: 5, z: -5, vx: 58 });
  const rear = ball({ onUpper: true, y: UPPER_BALL_Y, x: 0, z: -9, vz: -64 });
  for (const b of [left, right, rear]) assert.ok(containPlayfield(b));
  assert.ok(left.x >= PLAYFIELD.upperLeft + rail);
  assert.ok(right.x <= PLAYFIELD.upperRight - rail);
  assert.ok(rear.z >= PLAYFIELD.upperTop + rail);
  const waterfall = ball({ onUpper: true, y: UPPER_BALL_Y, x: -1.3, z: -2.37, vz: 14 });
  assert.equal(containPlayfield(waterfall), 0);
  assert.equal(waterfall.z, -2.37);
});

test('the sloped outlanes feed an open drain instead of launching the ball off-table', () => {
  const left = ball({ x: -5.3, z: 6.8, vx: -28, vz: 18 });
  const right = ball({ x: 4.7, z: 6.6, vx: 30, vz: 19 });
  assert.ok(containPlayfield(left));
  assert.ok(containPlayfield(right));
  assert.ok(left.x > PLAYFIELD.left && right.x < PLAYFIELD.right);
  assert.ok(Number.isFinite(left.vz + right.vz));
  const drain = ball({ x: -4.9, z: 7.75, vx: -35, vz: 5 });
  assert.ok(containPlayfield(drain));
  assert.ok(drain.x >= PLAYFIELD.leftDrainX + BALL_RADIUS);
  assert.ok(drain.vz >= 3);
  assert.equal(drain.z, 7.75, 'the drain stays open');
});

test('rails do not pull a ball out of a legitimate tube, drop, saucer, or shooter lane', () => {
  for (const flags of [{ ramp: 2 }, { falling: true }, { hold: .5 }, { inShooter: true }]) {
    const b = ball({ x: 5, z: -8, vx: 45, vz: -45, ...flags });
    const original = { ...b };
    assert.equal(containPlayfield(b), 0);
    assert.deepEqual(b, original);
  }
});

test('1000 fast lower and upper rail crossings stay finite and inside the physical table', () => {
  let seed = 76431;
  const random = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const rail = BALL_RADIUS + 0.075;
  for (let i = 0; i < 1000; i++) {
    const upper = i % 2 === 0;
    const b = ball({
      onUpper: upper, y: upper ? UPPER_BALL_Y : LOWER_BALL_Y,
      x: upper ? -3.3 + random() * 6.3 : -4 + random() * 7.6,
      z: upper ? -6.7 + random() * 3 : -7 + random() * 12,
      vx: (random() - .5) * 140, vz: (random() - .5) * 140,
    });
    b.x += b.vx / 120;
    b.z += b.vz / 120;
    containPlayfield(b);
    assert.ok(Number.isFinite(b.x + b.z + b.vx + b.vz));
    if (upper) {
      assert.ok(b.x >= PLAYFIELD.upperLeft + rail - .01);
      assert.ok(b.x <= PLAYFIELD.upperRight - rail + .01);
      assert.ok(b.z >= PLAYFIELD.upperTop + rail - .01);
    } else {
      assert.ok(b.z >= PLAYFIELD.top + rail - .01);
      if (b.z <= PLAYFIELD.shoulderZ) {
        assert.ok(b.x >= PLAYFIELD.left + rail - .01);
        assert.ok(b.x <= PLAYFIELD.right - rail + .01);
      }
    }
  }
});