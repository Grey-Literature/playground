# Physics Regression Checks

The tests import the same pure physics functions used by `src/PinballGame.tsx`.
No renderer, browser, third-party test package, or copied physics formulas are needed.

Run with Node 22.6 or newer:

```sh
node --experimental-strip-types --test tests/*.test.ts
```

Coverage includes zero-energy and short-pull rollbacks across every difficulty,
repeated launches, high-power rail collisions, retained crown speed, timestep
stability, swept vent hits, one pulse per visit, independent vent cooldowns,
upper/lower deck isolation, and clearance over a complete pendulum sweep.
`playfieldSession.test.ts` additionally checks that the final score and its
mode-specific best stay frozen while selecting a future run, and that upper,
lower, sloped outlane and drain boundaries keep fast shots on the physical
table without blocking legitimate drops or tube rides.

Browser checks still matter: hold/release Space and the pointer launch control,
cancel a charge by leaving the window, pause during a shot, launch all three balls,
and watch a vent blast and its recharge on Extra Hard.