import assert from 'node:assert/strict';
import test from 'node:test';
import {
  BALL_RADIUS, LOWER_BALL_Y, UPPER_BALL_Y, UPPER_SURFACE_Y,
  BELL_POSITIONS, UPPER_PENDULUM, SHOOTER, SKYSHOT_SPEED,
  INFERNO_VENTS, VENT_RADIUS, VENT_RECHARGE,
  plungeSpeed, plungeVelocity, advanceShooter,
  pendulumPosition, resolveMovingBumper,
  createVentState, fireInfernoVent, sweptCircleEntry,
  type FieldBall,
} from '../src/pinballPhysics.ts';

function randomFor(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function fieldBall(overrides: Partial<FieldBall> = {}): FieldBall {
  return {
    x: 0, z: 0, y: LOWER_BALL_Y, vx: 0, vz: 0, spin: 0,
    onUpper: false, falling: false, inShooter: false, ramp: -1, hold: 0,
    ...overrides,
  };
}

function simulatePlunge(power: number, difficulty: number, seed = 42, dt = 1 / 360) {
  const random = randomFor(seed);
  const ball = { x: SHOOTER.x, z: SHOOTER.restZ, ...plungeVelocity(power, difficulty, random) };
  let hits = 0, highestZ = ball.z;
  for (let time = 0; time < 12; time += dt) {
    const event = advanceShooter(ball, dt, difficulty, random);
    hits += event.wallHits;
    highestZ = Math.min(highestZ, ball.z);
    assert.ok(Number.isFinite(ball.x + ball.z + ball.vx + ball.vz + ball.spin), 'finite lane state');
    assert.ok(ball.x >= SHOOTER.innerRail + SHOOTER.railRadius + BALL_RADIUS - 1e-8, 'inside left rail');
    assert.ok(ball.x <= SHOOTER.outerRail - SHOOTER.railRadius - BALL_RADIUS + 1e-8, 'inside right rail');
    if (event.kind !== 'moving') return { kind: event.kind, speed: -ball.vz, hits, highestZ, time, ball };
  }
  assert.fail(`Unresolved plunge: power=${power}, difficulty=${difficulty}, seed=${seed}`);
}

test('zero compression means zero release energy at every difficulty', () => {
  for (let difficulty = 0; difficulty < 5; difficulty++) {
    assert.equal(plungeSpeed(0, difficulty), 0);
    assert.equal(Math.hypot(...Object.values(plungeVelocity(0, difficulty, () => 0.5))), 0);
  }
});

test('short taps roll back and settle rather than exiting or needing rescue', () => {
  for (let difficulty = 0; difficulty < 5; difficulty++) {
    for (const power of [0, 0.015, 0.04, 0.1, 0.2, 0.35]) {
      for (let seed = 1; seed <= 12; seed++) {
        const shot = simulatePlunge(power, difficulty, seed);
        assert.equal(shot.kind, 'settled');
        assert.ok(shot.highestZ > SHOOTER.topZ);
        assert.equal(shot.ball.z, SHOOTER.restZ);
        assert.equal(shot.ball.vx, 0);
        assert.equal(shot.ball.vz, 0);
      }
    }
  }
});

test('full pulls clear the lane with real rail impacts at all five difficulties', () => {
  for (let difficulty = 0; difficulty < 5; difficulty++) {
    for (let seed = 1; seed <= 32; seed++) {
      const shot = simulatePlunge(1, difficulty, seed);
      assert.equal(shot.kind, 'exit');
      assert.ok(shot.hits >= 1, 'a hard pull should hit a rail');
      assert.ok(shot.speed > SKYSHOT_SPEED + 0.5, 'enough energy remains for the skyshot');
      assert.ok(shot.speed < plungeSpeed(1, difficulty), 'rails and gravity must not add energy');
    }
  }
});

test('difficulty increases rail ricochets and preserves the stronger plunge', () => {
  let calmHits = 0, hardHits = 0;
  for (let seed = 1; seed <= 40; seed++) {
    const calm = simulatePlunge(1, 0, seed);
    const hard = simulatePlunge(1, 4, seed);
    calmHits += calm.hits; hardHits += hard.hits;
    assert.ok(hard.speed > calm.speed);
  }
  assert.ok(hardHits > calmHits * 1.5);
});

test('medium and full pulls retain distinct exit speeds, including successive launches', () => {
  for (let difficulty = 0; difficulty < 5; difficulty++) {
    for (let repeat = 0; repeat < 6; repeat++) {
      assert.equal(simulatePlunge(0.05, difficulty, repeat + 1).kind, 'settled');
      const medium = simulatePlunge(0.72, difficulty, repeat + 1);
      const full = simulatePlunge(1, difficulty, repeat + 1);
      assert.equal(medium.kind, 'exit');
      assert.equal(full.kind, 'exit');
      assert.ok(full.speed - medium.speed > 5);
    }
  }
});

test('rail time-of-impact remains stable across physics step sizes', () => {
  for (let difficulty = 0; difficulty < 5; difficulty++) {
    const coarse = simulatePlunge(1, difficulty, 9, 1 / 120);
    const fine = simulatePlunge(1, difficulty, 9, 1 / 480);
    assert.equal(coarse.kind, fine.kind);
    assert.ok(Math.abs(coarse.hits - fine.hits) <= 1);
    assert.ok(Math.abs(coarse.speed - fine.speed) < 0.3);
  }
});

test('a fast ball crossing an entire vent in one step still triggers a substantial impulse', () => {
  for (const vent of INFERNO_VENTS) {
    const previous = { x: vent.x, z: vent.z - 1.3 };
    const ball = fieldBall({ x: vent.x, z: vent.z + 1.3, vz: 28 });
    const state = createVentState();
    const hit = fireInfernoVent(ball, previous, vent, state, 1, 0.1, 4, () => 0.5);
    assert.ok(hit);
    assert.ok(hit.deltaV > 25);
    assert.ok(ball.vz < -10, 'the pressure burst must visibly reverse a head-on shot');
    assert.ok(Math.abs(ball.vx) > 3, 'the jet also gives a cross-table deflection');
    assert.ok(Math.abs(ball.spin) >= 8);
    assert.ok(Math.hypot(ball.vx, ball.vz) <= 27.5 + 1e-8);
    assert.equal(state.latched, true);
  }
});

test('the vent impulse does not disappear when the timestep is small', () => {
  const vent = INFERNO_VENTS[0];
  const previous = { x: vent.x, z: vent.z - 1.2 };
  const coarse = fieldBall({ x: vent.x, z: vent.z + 0.2, vz: 24 });
  const fine = { ...coarse };
  assert.ok(fireInfernoVent(coarse, previous, vent, createVentState(), 1, 1 / 30, 4, () => 0.5));
  assert.ok(fireInfernoVent(fine, previous, vent, createVentState(), 1, 1 / 480, 4, () => 0.5));
  assert.equal(coarse.vx, fine.vx);
  assert.equal(coarse.vz, fine.vz);
  assert.equal(coarse.spin, fine.spin);
});

test('vents fire only once per visit, recharge independently, and rearm after an exit', () => {
  const vent = INFERNO_VENTS[0];
  const state = createVentState();
  const previous = { x: vent.x, z: vent.z - 1.3 };
  const ball = fieldBall({ x: vent.x, z: vent.z, vz: 22 });
  assert.ok(fireInfernoVent(ball, previous, vent, state, 1, 1 / 120, 4, () => 0.5));
  const inside = fieldBall({ x: vent.x, z: vent.z, vz: 3 });
  assert.equal(fireInfernoVent(inside, inside, vent, state, 1.1, 1 / 120, 4), null);
  assert.equal(fireInfernoVent(inside, inside, vent, state, 3, 1 / 120, 4), null);
  Object.assign(inside, { x: vent.x, z: vent.z, vz: 22 });
  assert.ok(fireInfernoVent(inside, previous, vent, state, 3.1, 1 / 120, 4));
  assert.equal(state.readyAt, 3.1 + VENT_RECHARGE);
  const other = INFERNO_VENTS[1];
  assert.ok(fireInfernoVent(fieldBall({ x: other.x, z: other.z, vz: 22 }), { x: other.x, z: other.z - 1.3 }, other, createVentState(), 3.1, 1 / 120, 4));
});

test('vent center has a defined outward response, even for a stationary ball', () => {
  const vent = INFERNO_VENTS[0];
  const ball = fieldBall({ x: vent.x, z: vent.z });
  assert.ok(fireInfernoVent(ball, { ...vent }, vent, createVentState(), 1, 1 / 120, 4));
  assert.ok(Number.isFinite(ball.x + ball.z + ball.vx + ball.vz));
  assert.ok(Math.hypot(ball.vx, ball.vz) >= 12);
});

test('vents cannot affect the upper deck, a tube ride, a held ball, or the shooter lane', () => {
  const vent = INFERNO_VENTS[0];
  for (const flags of [{ onUpper: true, y: UPPER_BALL_Y }, { ramp: 2 }, { falling: true }, { hold: 0.4 }, { inShooter: true }]) {
    const ball = fieldBall({ ...vent, vz: 20, ...flags });
    const copy = { ...ball };
    assert.equal(fireInfernoVent(ball, ball, vent, createVentState(), 1, 1 / 120, 4), null);
    assert.deepEqual(ball, copy);
  }
  for (let difficulty = 0; difficulty < 4; difficulty++) {
    const ball = fieldBall({ ...vent, vz: 20 });
    assert.equal(fireInfernoVent(ball, ball, vent, createVentState(), 1, 1 / 120, difficulty), null);
  }
});

test('upper pendulum changes an upper ball but lets a lower ball pass underneath', () => {
  const pose = pendulumPosition(0);
  const bumper = { ...pose, r: UPPER_PENDULUM.r, layer: 'upper' as const };
  const upper = fieldBall({ x: pose.x, z: pose.z - 0.44, vz: 10, onUpper: true, y: UPPER_BALL_Y });
  assert.ok(resolveMovingBumper(upper, bumper, 2, () => 0.5));
  assert.ok(upper.vz < 0);
  const lower = fieldBall({ x: pose.x, z: pose.z - 0.44, vz: 10 });
  const copy = { ...lower };
  assert.equal(resolveMovingBumper(lower, bumper, 2), false);
  assert.deepEqual(lower, copy);
  assert.ok(UPPER_SURFACE_Y - 0.18 > LOWER_BALL_Y + BALL_RADIUS);
});

test('the entire upper pendulum sweep leaves ball-width gaps around bells, rails and drops', () => {
  const margin = BALL_RADIUS * 2 + 0.08;
  for (let sample = 0; sample <= 360; sample++) {
    const pose = pendulumPosition(sample / 360 * (Math.PI * 2 / UPPER_PENDULUM.freq));
    for (const bell of BELL_POSITIONS) {
      assert.ok(Math.hypot(pose.x - bell.x, pose.z - bell.z) - UPPER_PENDULUM.r - 0.55 > margin);
    }
    for (const hole of [{ x: -2.8, z: -3.3 }, { x: 2.5, z: -3.4 }]) {
      assert.ok(Math.hypot(pose.x - hole.x, pose.z - hole.z) - UPPER_PENDULUM.r - 0.43 > margin);
    }
    assert.ok(-2.5 - pose.z - UPPER_PENDULUM.r - 0.1 > margin);
    assert.ok(pose.x - (-3.9) - UPPER_PENDULUM.r - 0.1 > margin);
    assert.ok(3.6 - pose.x - UPPER_PENDULUM.r - 0.1 > margin);
  }
});

test('swept vent trigger has no false positive outside the visible trigger radius', () => {
  const radius = VENT_RADIUS + BALL_RADIUS;
  assert.equal(sweptCircleEntry({ x: radius + 0.1, z: -2 }, { x: radius + 0.1, z: 2 }, { x: 0, z: 0 }, radius), null);
});