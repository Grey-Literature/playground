import { useEffect, useRef, useState, type RefObject, type ReactNode } from 'react';
import { ArrowUpRight, Cat, ChevronRight, Flame, Gauge, Layers, Maximize2, Pause, Play, RotateCcw, Volume2, VolumeX, Zap } from 'lucide-react';
import PinballGame, { type GameHandle, type GameSnapshot } from './PinballGame';
import { DIFF_INFO, plungeSpeed } from './pinballPhysics';
import './index.css';

const initial: GameSnapshot = {
  status: 'ready', score: 0, best: 0, balls: 3, bells: 0, tunnel: false,
  message: 'THE FORGE AWAITS', muted: false, level: 'SHOOTER', power: 0,
  tilt: false, difficulty: 0, scoreDifficulty: 0, charging: false,
  canLaunch: false, catAlert: false,
};

function Keycap({ children }: { children: ReactNode }) {
  return <span className="keycap">{children}</span>;
}

function FlipperButton({ side, game }: { side: 'left' | 'right'; game: RefObject<GameHandle | null> }) {
  const release = () => game.current?.setFlipper(side, false);
  return (
    <button
      className={`flip-button flip-${side}`}
      aria-label={`${side} flipper`}
      onPointerDown={e => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        game.current?.setFlipper(side, true);
      }}
      onPointerUp={e => {
        release();
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
      }}
      onPointerCancel={release}
      onLostPointerCapture={release}
    >
      <span className="flip-decor">{side === 'left' ? '↖' : '↗'}</span>
      <span className="flip-copy"><strong>{side} flipper</strong><small>{side === 'left' ? 'A / LEFT ARROW' : 'D / RIGHT ARROW'}</small></span>
    </button>
  );
}

export default function App() {
  const game = useRef<GameHandle>(null);
  const stage = useRef<HTMLDivElement>(null);
  const [snapshot, setSnapshot] = useState<GameSnapshot>(initial);
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => {
    const update = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', update);
    return () => document.removeEventListener('fullscreenchange', update);
  }, []);

  const startOrResume = () => {
    if (snapshot.status === 'paused') game.current?.togglePause();
    else if (snapshot.status === 'ready' || snapshot.status === 'gameover') game.current?.start();
  };

  const toggleFullscreen = async () => {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await stage.current?.requestFullscreen();
  };

  const charging = snapshot.status === 'playing' && snapshot.charging;
  const selectionLocked = snapshot.status === 'playing' || snapshot.status === 'paused';
  const chosenDiff = DIFF_INFO[snapshot.difficulty];
  const scoreDiff = DIFF_INFO[snapshot.scoreDifficulty];
  const deckClass = snapshot.level.includes('NEST') || snapshot.level === 'SKYSHOT' ? 'nest'
    : snapshot.level.includes('UNDER') ? 'under'
      : snapshot.level.includes('SERPENT') ? 'serpent'
        : snapshot.level === 'RAMP' ? 'ramp' : '';

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="brand"><span className="brand-mark"><Flame size={21} fill="currentColor" strokeWidth={1.6} /></span> PYRE<span className="brand-divider">/</span><span className="brand-light">ARCADE</span></div>
        <span className="header-center"><span className="online-dot" /> ORIGINAL PINBALL EXPERIENCE <span className="header-index">// 003</span></span>
        <button className="header-sound" onClick={() => game.current?.toggleMute()} aria-label={snapshot.muted ? 'Unmute sound' : 'Mute sound'}>
          {snapshot.muted ? <VolumeX size={17} /> : <Volume2 size={17} />} <span>SOUND {snapshot.muted ? 'OFF' : 'ON'}</span>
        </button>
      </header>

      <main className="main-layout">
        <section className="game-column" aria-label="Salamander pinball machine">
          <div className="cabinet-marquee">
            <div className="cabinet-identity">
              <span className="eyebrow"><span className="eyebrow-line" /> THE FIRE TRIAL</span>
              <h1>SALAMAN<span>DER</span><i>.</i></h1>
              <p>CHASE THE HEAT. RULE THE NEST.</p>
            </div>
            <div className="marquee-readout">
              <span className="readout-label">{snapshot.status === 'gameover' ? 'FINAL SCORE' : 'SCORE'} <span>// {scoreDiff.name}</span></span>
              <strong className="score-value" key={snapshot.score}>{snapshot.score.toLocaleString().padStart(6, '0')}</strong>
              <span className="marquee-best">PERSONAL BEST <strong>{snapshot.best.toLocaleString().padStart(6, '0')}</strong></span>
            </div>
            <div className="marquee-balls" aria-label={`${snapshot.balls} balls remaining`}>
              <span className="readout-label">BALLS <strong>0{snapshot.balls} / 03</strong></span>
              <span className="ball-indicators">{[0, 1, 2].map(i => <span key={i} className={`ball-indicator ${i < snapshot.balls ? 'active' : ''}`} />)}</span>
            </div>
          </div>

          <div className="game-stage" ref={stage}>
            <div className="stage-grain" />
            <PinballGame ref={game} onUpdate={setSnapshot} />
            <div className="stage-top-left"><span className="live-dot" /> {snapshot.status === 'playing' ? 'LIVE PLAYFIELD' : snapshot.status === 'paused' ? 'GAME PAUSED' : snapshot.status === 'gameover' ? 'FINAL BALL DRAINED' : 'READY TO IGNITE'}</div>
            <div className="stage-top-right">
              <span className={`diff-badge d${snapshot.scoreDifficulty}`}>{scoreDiff.name}</span>
              <span className={`deck-badge ${deckClass}`}><Layers size={12} /> {snapshot.level}</span>
              {snapshot.tilt && <span className="tilt-badge">TILT!</span>}
            </div>
            <button className="fullscreen-button" onClick={toggleFullscreen} aria-label={fullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}><Maximize2 size={17} /></button>

            {charging && (
              <div className="power-hud" aria-label="Launch power">
                <span><Gauge size={14} /> {Math.round(snapshot.power * 100)}% PULL</span>
                <div className="power-track"><span style={{ width: `${Math.round(snapshot.power * 100)}%` }} className={snapshot.power > .85 ? 'skyshot' : ''} /></div>
                <strong>{plungeSpeed(snapshot.power, snapshot.scoreDifficulty).toFixed(1)} u/s</strong>
              </div>
            )}

            {snapshot.catAlert && <div className="cat-alert" role="status"><Cat size={20} /> THE CAT HISSED. BALL RECOVERED.</div>}

            {(snapshot.status === 'ready' || snapshot.status === 'gameover' || snapshot.status === 'paused') && (
              <div className="stage-overlay">
                <span className="overlay-ornament"><Flame size={27} fill="currentColor" /></span>
                <span className="overlay-eyebrow">{snapshot.status === 'gameover' ? `${scoreDiff.name} / RUN COMPLETE` : snapshot.status === 'paused' ? 'THE FLAME IS WAITING' : 'STEP UP TO THE MACHINE'}</span>
                <h2>{snapshot.status === 'gameover' ? 'GAME OVER' : snapshot.status === 'paused' ? 'PAUSED' : 'LIGHT IT UP'}</h2>
                <p>{snapshot.status === 'gameover'
                  ? `${snapshot.score.toLocaleString()} points are locked in. Choose the intensity for your next run.`
                  : snapshot.status === 'paused'
                    ? 'Take a breather. The ball will be right where you left it.'
                    : 'Three balls. Two decks. Hold SPACE or the launch control, then release to fire.'}</p>
                {snapshot.status !== 'paused' && (
                  <div className="overlay-choose">
                    <span>{snapshot.status === 'gameover' ? 'NEXT RUN' : 'CHOOSE YOUR INTENSITY'}</span>
                    <div className="overlay-diff" aria-label="Choose difficulty">
                      {DIFF_INFO.map((d, i) => (
                        <button key={d.name} aria-pressed={snapshot.difficulty === i} className={snapshot.difficulty === i ? 'sel' : ''} onClick={() => game.current?.setDifficulty(i)}>{d.name}</button>
                      ))}
                    </div>
                    <small>{chosenDiff.desc}</small>
                  </div>
                )}
                <button className="overlay-button" onClick={startOrResume}>
                  <Play size={15} fill="currentColor" /> {snapshot.status === 'gameover' ? 'PLAY NEXT RUN' : snapshot.status === 'paused' ? 'RESUME GAME' : 'START GAME'}
                </button>
                {snapshot.status === 'ready' && <span className="overlay-footnote">OR HOLD SPACE TO START AND CHARGE</span>}
              </div>
            )}
            <div className="stage-bottom-label">{snapshot.canLaunch
              ? charging ? 'RELEASE TO FIRE / MORE PULL, MORE POWER' : 'HOLD SPACE TO CHARGE / RELEASE TO PLUNGE'
              : <>FLIP <span>•</span> BOUNCE <span>•</span> BURN BRIGHT</>}</div>
          </div>

          <div className="under-stage">
            <span><span className="status-spark">✳</span> {snapshot.message}</span>
            <span>BELLS LIT <strong>0{snapshot.bells} / 03</strong></span>
          </div>

          <div className="cabinet-controls">
            <FlipperButton side="left" game={game} />
            <div className="action-area">
              <button
                className={`primary-action ${charging ? 'is-charging' : ''}`}
                disabled={snapshot.status === 'playing' && !snapshot.canLaunch && !charging}
                onClick={() => { if (snapshot.status !== 'playing') startOrResume(); }}
                onPointerDown={e => {
                  if (snapshot.status !== 'playing') return;
                  e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId);
                  game.current?.beginCharge();
                }}
                onPointerUp={e => {
                  if (snapshot.status !== 'playing') return;
                  e.preventDefault(); game.current?.releaseCharge();
                  if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
                }}
                onPointerCancel={() => game.current?.cancelCharge()}
                onLostPointerCapture={() => game.current?.cancelCharge()}
                onKeyDown={e => {
                  if (snapshot.status === 'playing' && (e.key === ' ' || e.key === 'Enter')) {
                    e.preventDefault(); e.stopPropagation(); if (!e.repeat) game.current?.beginCharge();
                  }
                }}
                onKeyUp={e => {
                  if (snapshot.status === 'playing' && (e.key === ' ' || e.key === 'Enter')) {
                    e.preventDefault(); e.stopPropagation(); game.current?.releaseCharge();
                  }
                }}
                onBlur={() => game.current?.cancelCharge()}
              >
                <span>{snapshot.status === 'ready' || snapshot.status === 'gameover' ? 'START GAME' : snapshot.status === 'paused' ? 'RESUME GAME' : charging ? 'RELEASE TO LAUNCH' : snapshot.canLaunch ? 'HOLD TO LAUNCH' : 'BALL IN PLAY'}</span>
                <ArrowUpRight size={20} />
              </button>
              <div className="secondary-actions">
                <button onClick={() => game.current?.rescue()}><RotateCcw size={15} /> RESCUE</button>
                <button onClick={() => game.current?.nudge()}><Zap size={15} /> NUDGE</button>
                <button onClick={() => game.current?.togglePause()}>{snapshot.status === 'paused' ? <Play size={15} /> : <Pause size={15} />} {snapshot.status === 'paused' ? 'RESUME' : 'PAUSE'}</button>
              </div>
            </div>
            <FlipperButton side="right" game={game} />
          </div>
          <p className="cabinet-hint">KEYBOARD: A / D OR ARROWS TO FLIP <span>+</span> HOLD SPACE TO PLUNGE <span>+</span> W TO NUDGE</p>
        </section>

        <aside className="sidebar" aria-label="Machine setup and instructions">
          <div className="diff-section">
            <div className="section-heading"><span>CHOOSE YOUR FORGE</span><span>{selectionLocked ? 'LOCKED UNTIL THIS RUN ENDS' : snapshot.status === 'gameover' ? 'SELECT YOUR NEXT RUN' : 'KEYS 1-5'}</span></div>
            <div className="diff-grid">{DIFF_INFO.map((d, i) => (
              <button key={d.name} className={`diff-btn d${i}${i === snapshot.difficulty ? ' sel' : ''}`} disabled={selectionLocked} onClick={() => game.current?.setDifficulty(i)} aria-pressed={i === snapshot.difficulty}>
                <span className="diff-number">0{i + 1}</span>
                <span className="diff-text"><strong>{d.name}</strong><em>{d.obstacle ?? 'BASE TABLE'}</em></span>
                <ChevronRight size={16} className="diff-arrow" />
              </button>
            ))}</div>
            <p className="diff-desc">{chosenDiff.desc} Each intensity keeps the obstacles from the levels below it. Your run's score and best remain tied to its starting difficulty.</p>
          </div>
          <div className="objective-section">
            <div className="section-heading"><span>THE CHALLENGE</span><Flame size={16} /></div>
            <h3>Ring the fire bells.</h3>
            <p>Climb to the Ember Nest, strike all three bells and ignite a <strong>5,000 point</strong> inferno bonus.</p>
            <div className="objective-progress"><span style={{ width: `${snapshot.bells / 3 * 100}%` }} /></div>
            <div className="objective-meta"><span>BELLS LIT</span><strong>0{snapshot.bells} / 03</strong></div>
          </div>
          <div className="controls-section">
            <div className="section-heading"><span>AT THE MACHINE</span><span>KEYBOARD / TOUCH</span></div>
            <div className="control-row"><span>Flip</span><div><Keycap>A</Keycap><Keycap>D</Keycap><Keycap>←</Keycap><Keycap>→</Keycap></div></div>
            <div className="control-row"><span>Hold / release to launch</span><div><Keycap>SPACE</Keycap></div></div>
            <div className="control-row"><span>Nudge / rescue / pause</span><div><Keycap>W</Keycap><Keycap>R</Keycap><Keycap>P</Keycap></div></div>
            <p className="control-footnote">If the ball rolls back, try a longer pull. It will not cost you a ball.</p>
          </div>
        </aside>
      </main>
      <footer className="footer"><span>© 2026 PYRE ARCADE</span><span>MADE TO BE PLAYED LOUD <Flame size={12} fill="currentColor" /></span></footer>
    </div>
  );
}