import { difficultyIndex } from './pinballPhysics.ts';

export type SelectionState = {
  status: 'ready' | 'playing' | 'paused' | 'gameover';
  difficulty: number;
  scoreDifficulty: number;
  score: number;
  best: number;
};

// A completed run owns its score and best even while the next run is being configured.
export function selectDifficultyForNextRun(
  state: SelectionState,
  requested: number,
  bestFor: (difficulty: number) => number,
): SelectionState | null {
  if (state.status === 'playing' || state.status === 'paused') return null;
  const difficulty = difficultyIndex(requested);
  if (difficulty === state.difficulty) return null;
  if (state.status === 'gameover') return { ...state, difficulty };
  return { ...state, difficulty, scoreDifficulty: difficulty, best: bestFor(difficulty) };
}