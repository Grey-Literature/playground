export const BALL_RADIUS = 0.235;
export const LOWER_BALL_Y = 0.34;
export const UPPER_SURFACE_Y = 1.15;
export const UPPER_BALL_Y = UPPER_SURFACE_Y + BALL_RADIUS + 0.005;
export const CHARGE_SECONDS = 1.1;
export const SKYSHOT_SPEED = 17.5;

export const DIFF_INFO = [
  { name: 'SUPER EASY', desc: 'The calm forge. Base speed, gentle rubber, no extra obstacles.', obstacle: null as string | null },
  { name: 'EASY', desc: 'Livelier ball, harder kicks. Adds the EMBER SPIRE bumper.', obstacle: 'EMBER SPIRE' },
  { name: 'MEDIUM', desc: 'The ASH PENDULUM now sweeps the upper Ember Nest. Time your ramp entries.', obstacle: 'ASH PENDULUM / UPPER' },
  { name: 'HARD', desc: 'Brutal gravity, violent bells. Adds the orbiting CINDER MOONS below.', obstacle: 'CINDER MOONS' },
  { name: 'EXTRA HARD', desc: 'INFERNO VENTS fire a hard, spinning blast on entry, then visibly recharge.', obstacle: 'INFERNO VENTS' },
];

export const DIFFS = [
  { grav: 1.0, jitter: 1.0, kick: 1.0, magnus: 1.0, vmax: 1.0, spin: 1.0, bell: 1.0, drag: 1.0, slope: 1.0, shake: 1.0, plunge: 1.0 },
  { grav: 1.06, jitter: 1.35, kick: 1.12, magnus: 1.2, vmax: 1.08, spin: 1.15, bell: 1.1, drag: 0.95, slope: 1.2, shake: 1.15, plunge: 1.04 },
  { grav: 1.12, jitter: 1.7, kick: 1.25, magnus: 1.4, vmax: 1.16, spin: 1.3, bell: 1.2, drag: 0.9, slope: 1.4, shake: 1.3, plunge: 1.08 },
  { grav: 1.2, jitter: 2.1, kick: 1.4, magnus: 1.65, vmax: 1.25, spin: 1.5, bell: 1.32, drag: 0.85, slope: 1.65, shake: 1.45, plunge: 1.12 },
  { grav: 1.32, jitter: 2.6, kick: 1.6, magnus: 2.0, vmax: 1.35, spin: 1.7, bell: 1.45, drag: 0.8, slope: 2.0, shake: 1.6, plunge: 1.16 },
];

export const SHOOTER = {
  innerRail: 4.12,
  outerRail: 5.17,
  railRadius: 0.075,
  x: (4.12 + 5.17) / 2,
  restZ: 6.7,
  topZ: -6.55,
  pullMax: 0.6,
};

export const BELL_POSITIONS = [
  { x: -1.9, z: -5.9 },
  { x: 1.5, z: -5.6 },
  { x: -0.2, z: -4.98 },
];
export const UPPER_PENDULUM = { cx: -0.15, z: -3.55, amp: 1.2, freq: 1.7, r: 0.24 };
export const INFERNO_VENTS = [{ x: -1.6, z: 4.9 }, { x: 1.6, z: 4.9 }];
export const VENT_RADIUS = 0.75;
export const VENT_RECHARGE = 1.15;

export type Point2 = { x: number; z: number };
export type MovingBall = Point2 & { vx: number; vz: number; spin: number };
export type FieldBall = MovingBall & {
  y: number;
  onUpper: boolean;
  falling: boolean;
  inShooter: boolean;
  ramp: number;
  hold: number;
};
export type RandomSource = () => number;
export type VentState = { latched: boolean; readyAt: number; firedAt: number };
export type MovingBumper = Point2 & { vx: number; vz: number; r: number; layer: 'upper' | 'lower' };

export const PLAYFIELD = {
  left: -4.63,
  right: 4.12,
  top: -7.55,
  shoulderZ: 5.5,
  drainZ: 7.46,
  leftDrainX: -2.6,
  rightDrainX: 2.6,
  upperLeft: -3.9,
  upperRight: 3.6,
  upperTop: -7.3,
};

const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
export const difficultyIndex = (n: number) => Number.isFinite(n) ? clamp(Math.round(n), 0, 4) : 0;
const tuning = (difficulty: number) => DIFFS[difficultyIndex(difficulty)];

// Spring energy is proportional to compression squared, so release speed is proportional to pull.
export function plungeSpeed(power: number, difficulty = 0) {
  return 27.4 * clamp(power, 0, 1) * tuning(difficulty).plunge;
}

export function plungeVelocity(power: number, difficulty: number, random: RandomSource = Math.random) {
  const pull = clamp(power, 0, 1);
  const speed = plungeSpeed(pull, difficulty);
  const side = random() < 0.5 ? -1 : 1;
  const spread = (0.002 + (0.027 + difficultyIndex(difficulty) * 0.014) * pull * pull);
  const angle = side * spread * (0.82 + random() * 0.36);
  return {
    vx: Math.sin(angle) * speed,
    vz: -Math.cos(angle) * speed,
    spin: side * pull * (0.15 + difficultyIndex(difficulty) * 0.16),
  };
}

export function advanceShooter(
  ball: MovingBall,
  dt: number,
  difficulty: number,
  random: RandomSource = Math.random,
) {
  const lo = SHOOTER.innerRail + SHOOTER.railRadius + BALL_RADIUS;
  const hi = SHOOTER.outerRail - SHOOTER.railRadius - BALL_RADIUS;
  let wallHits = 0;
  let lastWall: 'left' | 'right' | null = null;
  let impact = 0;

  ball.vz = (ball.vz + 7.8 * dt) * Math.exp(-0.05 * dt);
  ball.vx *= Math.exp(-0.1 * dt);
  ball.spin *= Math.exp(-1.8 * dt);
  ball.x = clamp(ball.x, lo, hi);

  // Resolve actual time-of-impact, including the remaining travel after a rail bounce.
  // Only normal energy is strongly damped; forward speed is not multiplied down on every scrape.
  let remaining = dt;
  for (let i = 0; i < 12 && remaining > 1e-9; i++) {
    const wall = ball.vx > 0 ? hi : lo;
    const hitTime = Math.abs(ball.vx) > 1e-7 ? (wall - ball.x) / ball.vx : Infinity;
    if (hitTime > remaining || hitTime < 0) {
      ball.x += ball.vx * remaining;
      break;
    }
    ball.x = wall;
    remaining -= hitTime;
    const normalSpeed = Math.abs(ball.vx);
    const restitution = clamp(0.70 + difficultyIndex(difficulty) * 0.04 + (random() - 0.5) * 0.05, 0.64, 0.9);
    lastWall = ball.vx > 0 ? 'right' : 'left';
    ball.vx *= -restitution;
    const friction = Math.min(Math.abs(ball.vz) * 0.005, normalSpeed * 0.028);
    ball.vz -= Math.sign(ball.vz) * friction;
    ball.spin = clamp(ball.spin + (lastWall === 'right' ? -1 : 1) * normalSpeed * 0.6, -8, 8);
    ball.x += lastWall === 'right' ? -1e-6 : 1e-6;
    wallHits++;
    impact = Math.max(impact, normalSpeed);
  }
  ball.x = clamp(ball.x, lo, hi);
  ball.z += ball.vz * dt;

  if (ball.z <= SHOOTER.topZ && ball.vz < 0) {
    ball.z = SHOOTER.topZ;
    return { kind: 'exit' as const, wallHits, lastWall, impact };
  }
  if (ball.z >= SHOOTER.restZ && ball.vz >= 0) {
    ball.z = SHOOTER.restZ;
    if (ball.vz > 1.3) {
      ball.vz *= -0.18;
      ball.vx *= 0.3;
      ball.spin *= 0.2;
    } else {
      ball.x = SHOOTER.x;
      ball.vx = 0;
      ball.vz = 0;
      ball.spin = 0;
      return { kind: 'settled' as const, wallHits, lastWall, impact };
    }
  }
  return { kind: 'moving' as const, wallHits, lastWall, impact };
}

export function containPlayfield(ball: FieldBall, restitution = 0.76) {
  if (ball.inShooter || ball.falling || ball.ramp >= 0 || ball.hold > 0) return 0;
  let hits = 0;
  const rail = BALL_RADIUS + 0.075;
  const bounce = (nx: number, nz: number, penetration: number) => {
    if (penetration <= 0) return;
    ball.x += nx * (penetration + 0.002);
    ball.z += nz * (penetration + 0.002);
    const vn = ball.vx * nx + ball.vz * nz;
    if (vn < 0) {
      ball.vx -= (1 + restitution) * vn * nx;
      ball.vz -= (1 + restitution) * vn * nz;
    }
    hits++;
  };

  if (ball.onUpper) {
    bounce(1, 0, PLAYFIELD.upperLeft + rail - ball.x);
    bounce(-1, 0, ball.x - (PLAYFIELD.upperRight - rail));
    bounce(0, 1, PLAYFIELD.upperTop + rail - ball.z);
    // The front edge is handled separately: its two gaps drop onto the lower deck.
    return hits;
  }

  bounce(0, 1, PLAYFIELD.top + rail - ball.z);
  if (ball.z <= PLAYFIELD.shoulderZ) {
    bounce(1, 0, PLAYFIELD.left + rail - ball.x);
    bounce(-1, 0, ball.x - (PLAYFIELD.right - rail));
  } else if (ball.z <= PLAYFIELD.drainZ) {
    const diagonal = (ax: number, bx: number, nxSign: number) => {
      const az = PLAYFIELD.shoulderZ, bz = PLAYFIELD.drainZ;
      const dx = bx - ax, dz = bz - az, length = Math.hypot(dx, dz);
      const nx = nxSign * dz / length, nz = -Math.abs(dx) / length;
      const distance = (ball.x - ax) * nx + (ball.z - az) * nz;
      bounce(nx, nz, rail - distance);
    };
    diagonal(PLAYFIELD.left, PLAYFIELD.leftDrainX, 1);
    diagonal(PLAYFIELD.right, PLAYFIELD.rightDrainX, -1);
    // A hard diagonal hit can move the center back above the shoulder junction.
    if (ball.z <= PLAYFIELD.shoulderZ) {
      bounce(1, 0, PLAYFIELD.left + rail - ball.x);
      bounce(-1, 0, ball.x - (PLAYFIELD.right - rail));
    }
  } else {
    // The open throat is a drain, not a wall. Guide an outlane ball down instead of
    // reflecting it back for an unintended extra life or letting it leave the mesh.
    if (ball.x < PLAYFIELD.leftDrainX + rail) {
      ball.x = PLAYFIELD.leftDrainX + rail;
      ball.vx = Math.max(0, ball.vx * 0.25);
      ball.vz = Math.max(3, ball.vz);
      hits++;
    }
    if (ball.x > PLAYFIELD.rightDrainX - rail) {
      ball.x = PLAYFIELD.rightDrainX - rail;
      ball.vx = Math.min(0, ball.vx * 0.25);
      ball.vz = Math.max(3, ball.vz);
      hits++;
    }
  }
  return hits;
}

export function pendulumPosition(time: number) {
  const p = UPPER_PENDULUM;
  return {
    x: p.cx + p.amp * Math.sin(p.freq * time),
    z: p.z,
    vx: p.amp * p.freq * Math.cos(p.freq * time),
    vz: 0,
  };
}

export function resolveMovingBumper(
  ball: FieldBall,
  bumper: MovingBumper,
  difficulty: number,
  random: RandomSource = Math.random,
) {
  if (ball.onUpper !== (bumper.layer === 'upper') || ball.falling || ball.ramp >= 0 || ball.hold > 0 || ball.inShooter) return false;
  const dx = ball.x - bumper.x, dz = ball.z - bumper.z;
  const distance = Math.hypot(dx, dz), separation = bumper.r + BALL_RADIUS;
  if (distance >= separation) return false;
  const rvx = ball.vx - bumper.vx, rvz = ball.vz - bumper.vz;
  const relativeSpeed = Math.hypot(rvx, rvz);
  const nx = distance > 1e-5 ? dx / distance : relativeSpeed > 1e-5 ? -rvx / relativeSpeed : 0;
  const nz = distance > 1e-5 ? dz / distance : relativeSpeed > 1e-5 ? -rvz / relativeSpeed : 1;
  ball.x = bumper.x + nx * (separation + 0.006);
  ball.z = bumper.z + nz * (separation + 0.006);
  const vn = rvx * nx + rvz * nz;
  if (vn >= 0) return false;
  const d = tuning(difficulty);
  const vt = -rvx * nz + rvz * nx;
  const restitution = Math.min(1.02 * d.kick, 1.25) * (1 + (random() - 0.5) * 0.16 * d.jitter);
  const outward = -vn * restitution + (2.5 + random() * 2) * d.kick;
  const tangent = vt * 0.94 - ball.spin * 0.3 * d.magnus + (random() - 0.5) * 1.2 * d.jitter;
  ball.vx = nx * outward - nz * tangent + bumper.vx;
  ball.vz = nz * outward + nx * tangent + bumper.vz;
  ball.spin = clamp(ball.spin * 0.5 + vt * 0.32 * d.magnus + (random() - 0.5) * 3.2 * d.jitter, -12 * d.spin, 12 * d.spin);
  return true;
}

export function sweptCircleEntry(from: Point2, to: Point2, center: Point2, radius: number) {
  const dx = to.x - from.x, dz = to.z - from.z;
  const ox = from.x - center.x, oz = from.z - center.z;
  const c = ox * ox + oz * oz - radius * radius;
  if (c <= 0) return { x: from.x, z: from.z, t: 0 };
  const a = dx * dx + dz * dz;
  if (a < 1e-12) return null;
  const b = 2 * (ox * dx + oz * dz);
  const discriminant = b * b - 4 * a * c;
  if (discriminant < 0) return null;
  const t = (-b - Math.sqrt(discriminant)) / (2 * a);
  return t >= 0 && t <= 1 ? { x: from.x + dx * t, z: from.z + dz * t, t } : null;
}

export function createVentState(): VentState {
  return { latched: false, readyAt: 0, firedAt: -100 };
}

export function fireInfernoVent(
  ball: FieldBall,
  previous: Point2,
  vent: Point2,
  state: VentState,
  time: number,
  dt: number,
  difficulty: number,
  random: RandomSource = Math.random,
) {
  if (difficulty < 4 || ball.onUpper || ball.falling || ball.ramp >= 0 || ball.hold > 0 || ball.inShooter || ball.y > LOWER_BALL_Y + 0.1) return null;
  const radius = VENT_RADIUS + BALL_RADIUS;
  if (Math.hypot(previous.x - vent.x, previous.z - vent.z) > radius + 0.12) state.latched = false;
  if (state.latched || time < state.readyAt) return null;
  const hit = sweptCircleEntry(previous, ball, vent, radius);
  if (!hit) return null;

  const incomingX = ball.vx, incomingZ = ball.vz;
  const incomingSpeed = Math.hypot(incomingX, incomingZ);
  const dx = hit.x - vent.x, dz = hit.z - vent.z, distance = Math.hypot(dx, dz);
  const nx = distance > 1e-5 ? dx / distance : incomingSpeed > 1e-5 ? -incomingX / incomingSpeed : 0;
  const nz = distance > 1e-5 ? dz / distance : incomingSpeed > 1e-5 ? -incomingZ / incomingSpeed : -1;
  const radialIn = incomingX * nx + incomingZ * nz;
  const side = vent.x < 0 ? 1 : -1;
  const d = tuning(difficulty);

  // A pressure pulse is an impulse, not a tiny force integrated during a fast crossing.
  const outward = Math.max(0, -radialIn * 0.42, radialIn * 0.65) + (9 + random() * 3) * d.kick;
  const tangent = (-incomingX * nz + incomingZ * nx) * 0.45 + side * (3.5 + random() * 2.5) * d.kick;
  ball.vx = nx * outward - nz * tangent;
  ball.vz = nz * outward + nx * tangent;
  const outSpeed = Math.hypot(ball.vx, ball.vz);
  const limit = 27.5;
  if (outSpeed > limit) { ball.vx *= limit / outSpeed; ball.vz *= limit / outSpeed; }
  ball.spin = clamp(ball.spin * 0.35 + side * (8 + random() * 6), -12 * d.spin, 12 * d.spin);
  const remainder = dt * (1 - hit.t);
  ball.x = hit.x + ball.vx * remainder;
  ball.z = hit.z + ball.vz * remainder;
  state.latched = true;
  state.firedAt = time;
  state.readyAt = time + VENT_RECHARGE;
  return { x: hit.x, z: hit.z, deltaV: Math.hypot(ball.vx - incomingX, ball.vz - incomingZ) };
}