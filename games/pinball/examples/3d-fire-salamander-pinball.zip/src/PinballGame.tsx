import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import * as THREE from 'three';
import {
  BALL_RADIUS as BALL_R, LOWER_BALL_Y as FLOOR_Y, UPPER_BALL_Y as UPPER_Y,
  UPPER_SURFACE_Y, BELL_POSITIONS as bellPositions, UPPER_PENDULUM as PEND,
  DIFF_INFO, DIFFS, SHOOTER, CHARGE_SECONDS, SKYSHOT_SPEED,
  INFERNO_VENTS as VENTS, VENT_RADIUS as VENT_R, VENT_RECHARGE,
  plungeSpeed, plungeVelocity, advanceShooter, pendulumPosition,
  resolveMovingBumper, createVentState, fireInfernoVent, difficultyIndex, containPlayfield,
} from './pinballPhysics';
import { selectDifficultyForNextRun } from './pinballSession';

export { DIFF_INFO, DIFFS } from './pinballPhysics';
export type GameSnapshot = { status: 'ready' | 'playing' | 'paused' | 'gameover'; score: number; best: number; balls: number; bells: number; tunnel: boolean; message: string; muted: boolean; level: string; power: number; tilt: boolean; difficulty: number; scoreDifficulty: number; charging: boolean; canLaunch: boolean; catAlert: boolean };
export type GameHandle = { start: () => void; launch: () => void; beginCharge: () => void; releaseCharge: () => void; cancelCharge: () => void; rescue: () => void; togglePause: () => void; toggleMute: () => void; setFlipper: (side: 'left' | 'right', down: boolean) => void; nudge: () => void; setDifficulty: (d: number) => void };

// Cumulative obstacles, with the pendulum on a separate physical deck.
const SPIRE = { x: -1.1, z: 3.6, r: .32 };
const MOONS = { cx: 0, cz: 2.0, r: 1.35, orb: .22, w: 1.1 };

type Point = { x: number; z: number };
type Segment = { a: Point; b: Point; bounce?: number; points?: number; color?: number };
const UX0 = -3.9, UX1 = 3.6, UZ0 = -7.3, UZ1 = -2.5;
const FLEN = 1.62, REST_L = .52, ACT_L = -.60, REST_R = Math.PI - .52, ACT_R = Math.PI + .60;
const upperHoles = [{ x: -2.8, z: -3.3 }, { x: 2.5, z: -3.4 }];
const rollovers = [{ x: -1.3, z: -6.6 }, { x: .1, z: -6.8 }, { x: 1.5, z: -6.5 }];
const mainPosts = [
  { x: -3.6, z: -2.75, r: .14 }, { x: 3.3, z: -2.75, r: .14 }, { x: -3.6, z: -6.95, r: .14 }, { x: 3.3, z: -6.95, r: .14 },
  { x: -2.5, z: 2.2, r: .14 }, { x: 2.4, z: 2.2, r: .14 }, { x: -3.3, z: 5.6, r: .12 }, { x: 3.2, z: 5.6, r: .12 },
  { x: -3.85, z: -.5, r: .12 }, { x: -2.85, z: -.5, r: .12 }, { x: 2.75, z: -.7, r: .12 }, { x: 3.75, z: -.7, r: .12 },
];
const mainWalls: Segment[] = [
  { a: { x: -4.63, z: -7.55 }, b: { x: -4.63, z: 5.5 } },
  { a: { x: -4.63, z: -7.55 }, b: { x: SHOOTER.outerRail, z: -7.55 } },
  { a: { x: SHOOTER.outerRail, z: -7.55 }, b: { x: SHOOTER.outerRail, z: 7.35 } },
  { a: { x: 4.12, z: -6.52 }, b: { x: 4.12, z: 7.35 } },
  { a: { x: -4.63, z: 5.5 }, b: { x: -2.6, z: 7.46 } },
  { a: { x: 4.12, z: 5.5 }, b: { x: 2.6, z: 7.46 } },
  { a: { x: -4.2, z: 2.45 }, b: { x: -2.3, z: 3.95 }, bounce: 1.1, points: 75, color: 0xff7527 },
  { a: { x: 3.95, z: 2.45 }, b: { x: 2.15, z: 3.95 }, bounce: 1.1, points: 75, color: 0xff7527 },
  { a: { x: -4.0, z: 4.65 }, b: { x: -2.45, z: 5.3 } },
  { a: { x: 3.8, z: 4.65 }, b: { x: 2.45, z: 5.3 } },
  { a: { x: -1.9, z: -1.7 }, b: { x: -.9, z: -.9 }, bounce: .92 },
  { a: { x: 1.9, z: -1.7 }, b: { x: .9, z: -.9 }, bounce: .92 },
];
const upperWalls: Segment[] = [
  { a: { x: UX0, z: UZ0 }, b: { x: UX1, z: UZ0 } },
  { a: { x: UX0, z: UZ0 }, b: { x: UX0, z: UZ1 } },
  { a: { x: UX1, z: UZ0 }, b: { x: UX1, z: UZ1 } },
  { a: { x: UX0, z: UZ1 }, b: { x: -2.1, z: UZ1 } },
  { a: { x: -.5, z: UZ1 }, b: { x: .5, z: UZ1 } },
  { a: { x: 2.0, z: UZ1 }, b: { x: UX1, z: UZ1 } },
];
const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
const rand = (a = 1, b?: number) => b === undefined ? Math.random() * a : a + Math.random() * (b - a);
const rampL = { mouth: { x: -3.35, z: -.7 }, ctrl: { x: -4.05, z: -1.9 }, exit: { x: -2.4, z: -4.8 }, evx: 2.2, evz: 1.2 };
const rampR = { mouth: { x: 3.25, z: -.9 }, ctrl: { x: 3.9, z: -2.2 }, exit: { x: 2.2, z: -4.9 }, evx: -2.2, evz: 1.2 };
const saucers = [{ x: -2.55, z: .9 }, { x: 2.7, z: .7 }];
const MAW = { x: 0, z: 1.8 };
const SPINNER = { x: -4.05, z: -.3 };
// Shooter lane / plunger geometry.
const LANE_X = SHOOTER.x, BALL_REST_Z = SHOOTER.restZ, TIP_REST_Z = BALL_REST_Z + BALL_R, PULL_MAX = SHOOTER.pullMax, LANE_TOP_Z = SHOOTER.topZ;
// New tunnel: the Serpent — entrance mid-right, delivers to the left inlane.
const SERP_MOUTH = { x: 3.1, z: 1.5 };

function boardTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 1600;
  const ctx = c.getContext('2d')!;
  const bg = ctx.createLinearGradient(0, 0, 900, 1600);
  bg.addColorStop(0, '#1d1512'); bg.addColorStop(.45, '#30201a'); bg.addColorStop(1, '#171215');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, 1024, 1600);
  const glow = ctx.createRadialGradient(495, 900, 80, 495, 900, 620);
  glow.addColorStop(0, '#a7381c88'); glow.addColorStop(.55, '#6b241c38'); glow.addColorStop(1, '#00000000');
  ctx.fillStyle = glow; ctx.fillRect(0, 0, 1024, 1600);
  ctx.strokeStyle = '#b66b37aa'; ctx.lineWidth = 3; ctx.strokeRect(30, 30, 964, 1540);
  ctx.strokeStyle = '#77513788'; ctx.lineWidth = 1; ctx.strokeRect(45, 45, 934, 1510);
  // Under-deck runway guides so players can read the tunnel path.
  ctx.strokeStyle = '#e9802b55'; ctx.lineWidth = 2; ctx.setLineDash([14, 12]);
  ctx.beginPath(); ctx.moveTo(150, 60); ctx.lineTo(150, 500); ctx.moveTo(830, 60); ctx.lineTo(830, 500); ctx.stroke();
  ctx.setLineDash([]);
  for (let i = 0; i < 34; i++) {
    const x = 95 + (i * 227) % 825, y = 135 + (i * 311) % 1300;
    ctx.fillStyle = i % 3 ? '#e9802b50' : '#ffc17985'; ctx.beginPath(); ctx.arc(x, y, i % 4 === 0 ? 3 : 1.6, 0, Math.PI * 2); ctx.fill();
  }
  ctx.textAlign = 'center';
  ctx.fillStyle = '#eab470'; ctx.font = 'bold 40px Barlow Condensed, sans-serif';
  try { (ctx as unknown as { letterSpacing: string }).letterSpacing = '8px'; } catch { /* noop */ }
  ctx.fillText('EMBER NEST ABOVE', 500, 120);
  ctx.fillStyle = '#995a3b'; ctx.font = 'bold 19px Barlow Condensed, sans-serif';
  ctx.fillText('BALL PASSES UNDER  •  RAMPS LEAD UP', 500, 158);
  ctx.strokeStyle = '#bc6d3b99'; ctx.beginPath(); ctx.moveTo(250, 185); ctx.lineTo(750, 185); ctx.stroke();
  // Painted flame salamander on the lower deck.
  ctx.save(); ctx.translate(505, 965); ctx.rotate(-.16);
  const aura = ctx.createRadialGradient(0, 0, 25, 0, 0, 320);
  aura.addColorStop(0, '#e84b1870'); aura.addColorStop(.6, '#dc431a26'); aura.addColorStop(1, '#e44c1700');
  ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(0, 0, 330, 0, Math.PI * 2); ctx.fill();
  const flames = [[-20, 168, -55, 355, -138, 385, -82, 182], [5, 160, 42, 357, -8, 418, -24, 190], [24, 150, 103, 304, 104, 361, 4, 189], [-40, 145, -138, 288, -157, 350, -57, 195]];
  flames.forEach((f, i) => { ctx.beginPath(); ctx.moveTo(f[0], f[1]); ctx.bezierCurveTo(f[2], f[3] - 95, f[4], f[5] - 100, f[4], f[5]); ctx.quadraticCurveTo(f[6], f[7], f[0], f[1]); ctx.fillStyle = i % 2 ? '#ed6322' : '#a8341d'; ctx.fill(); });
  ctx.fillStyle = '#1c1512'; ctx.strokeStyle = '#ffb348'; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.moveTo(-72, 112); ctx.bezierCurveTo(-93, 33, -57, -106, 7, -128); ctx.bezierCurveTo(72, -156, 89, -64, 66, 29); ctx.bezierCurveTo(56, 105, 0, 176, -72, 112); ctx.fill(); ctx.stroke();
  const limbs = [[-51, -71, -178, -174], [55, -67, 174, -179], [-61, 84, -175, 154], [58, 84, 181, 145]];
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  limbs.forEach(([sx, sy, ex, ey]) => { ctx.strokeStyle = '#241a15'; ctx.lineWidth = 32; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.quadraticCurveTo(ex * .58, ey * .58, ex, ey); ctx.stroke(); ctx.strokeStyle = '#ffae42'; ctx.lineWidth = 6; for (let t = -1; t <= 1; t++) { ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex + t * 24, ey + (ey < 0 ? -25 : 25)); ctx.stroke(); } });
  // Signature yellow fire-salamander spots.
  ctx.fillStyle = '#ffcf3f';
  [[-30, -60, 20, 13], [25, -40, 15, 22], [-15, 10, 24, 14], [30, 40, 14, 18], [-25, 75, 18, 12], [5, -95, 16, 12]].forEach(([x, y, w, h]) => { ctx.beginPath(); ctx.ellipse(x, y, w, h, .4, 0, Math.PI * 2); ctx.fill(); });
  ctx.fillStyle = '#221913'; ctx.beginPath(); ctx.ellipse(0, -118, 94, 78, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#ffc16a'; ctx.lineWidth = 6; ctx.stroke();
  ctx.fillStyle = '#39ff6a'; ctx.beginPath(); ctx.arc(-40, -137, 13, 0, Math.PI * 2); ctx.arc(40, -137, 13, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#0d1a12'; ctx.beginPath(); ctx.arc(-40, -137, 5.5, 0, Math.PI * 2); ctx.arc(40, -137, 5.5, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#75271b'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, -105, 28, .15, Math.PI - .15); ctx.stroke();
  ctx.restore();
  ctx.fillStyle = '#ef9e4a'; ctx.font = 'bold 26px Barlow Condensed, sans-serif'; ctx.fillText('BURN BRIGHT', 505, 1330);
  ctx.fillStyle = '#ad6d45'; ctx.font = 'bold 20px Barlow Condensed, sans-serif';
  ctx.fillText('RAMP', 218, 560); ctx.fillText('RAMP', 790, 545); ctx.fillText('THE MAW', 505, 1000);
  ctx.fillStyle = '#ffcf3f'; ctx.fillText('SERPENT ↑', 812, 1030);
  ctx.fillStyle = '#ad6d45';
  ctx.fillStyle = '#ff5f36'; ctx.font = 'bold 19px Barlow Condensed, sans-serif';
  ctx.fillText('OUTLANE', 120, 1290); ctx.fillText('OUTLANE', 862, 1290);
  ctx.save(); ctx.translate(952, 800); ctx.rotate(Math.PI / 2); ctx.fillStyle = '#c98a52'; ctx.font = 'bold 19px Barlow Condensed, sans-serif'; ctx.fillText('HOLD SPACE — FULL POWER = SKYSHOT', 0, 0); ctx.restore();
  ctx.fillStyle = '#b87045'; ctx.font = 'bold 17px Barlow Condensed, sans-serif'; ctx.fillText('LEFT FLIP', 255, 1450); ctx.fillText('RIGHT FLIP', 745, 1450);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}

function upperTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas'); c.width = 768; c.height = 512;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#100d0c'; ctx.fillRect(0, 0, 768, 512);
  const g = ctx.createRadialGradient(384, 256, 40, 384, 256, 420);
  g.addColorStop(0, '#7c2a1233'); g.addColorStop(1, '#00000000'); ctx.fillStyle = g; ctx.fillRect(0, 0, 768, 512);
  ctx.strokeStyle = '#ff8b2a66'; ctx.lineWidth = 3; ctx.strokeRect(14, 14, 740, 484);
  for (let i = 0; i < 26; i++) {
    const x = 60 + (i * 173) % 650, y = 60 + (i * 211) % 395;
    ctx.fillStyle = i % 4 === 0 ? '#ffcf3f55' : '#e9802b33';
    ctx.beginPath(); ctx.ellipse(x, y, 9 + (i % 3) * 5, 6 + (i % 2) * 4, i, 0, Math.PI * 2); ctx.fill();
  }
  ctx.textAlign = 'center'; ctx.fillStyle = '#ffcf6a'; ctx.font = 'bold 44px Barlow Condensed, sans-serif';
  ctx.fillText('EMBER NEST', 384, 70);
  ctx.fillStyle = '#c97a3d'; ctx.font = 'bold 20px Barlow Condensed, sans-serif';
  ctx.fillText('UPPER DECK  •  DROP BACK TO THE FIRE BELOW', 384, 102);
  ctx.fillStyle = '#ff8b2a'; ctx.font = 'bold 22px Barlow Condensed, sans-serif';
  ctx.fillText('▼ DROP ▼', 170, 440); ctx.fillText('▼ DROP ▼', 600, 440);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}

function ballTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas'); c.width = 128; c.height = 128;
  const ctx = c.getContext('2d')!;
  const g = ctx.createLinearGradient(0, 0, 128, 128);
  g.addColorStop(0, '#fff3d0'); g.addColorStop(.5, '#ffb35c'); g.addColorStop(1, '#c33d12');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = '#5d1c0d';
  for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.arc(14 + (i * 47) % 100, 14 + (i * 71) % 100, 5 + (i % 3) * 3, 0, Math.PI * 2); ctx.fill(); }
  ctx.strokeStyle = '#7c1f0d88'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.arc(64, 64, 40, 0, Math.PI * 2); ctx.stroke();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

function makeBar(scene: THREE.Scene, a: Point, b: Point, color: number, width = .12, height = .22, y = .23, emissive = 0x23100a) {
  const dx = b.x - a.x, dz = b.z - a.z;
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(Math.hypot(dx, dz), height, width), new THREE.MeshStandardMaterial({ color, metalness: .65, roughness: .28, emissive, emissiveIntensity: .4 }));
  mesh.position.set((a.x + b.x) / 2, y, (a.z + b.z) / 2); mesh.rotation.y = -Math.atan2(dz, dx); scene.add(mesh); return mesh;
}

const PinballGame = forwardRef<GameHandle, { onUpdate: (s: GameSnapshot) => void }>(function PinballGame({ onUpdate }, ref) {
  const host = useRef<HTMLDivElement>(null);
  const api = useRef<GameHandle | null>(null);
  useImperativeHandle(ref, () => ({
    start: () => api.current?.start(), launch: () => api.current?.launch(), rescue: () => api.current?.rescue(),
    beginCharge: () => api.current?.beginCharge(), releaseCharge: () => api.current?.releaseCharge(), cancelCharge: () => api.current?.cancelCharge(),
    togglePause: () => api.current?.togglePause(), toggleMute: () => api.current?.toggleMute(),
    setFlipper: (s, d) => api.current?.setFlipper(s, d), nudge: () => api.current?.nudge(),
    setDifficulty: (d) => api.current?.setDifficulty(d),
  }), []);

  useEffect(() => {
    const element = host.current!;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(39, 1, .1, 120);
    const CAM_BASE = new THREE.Vector3(0, 16.9, 16.2);
    camera.position.copy(CAM_BASE); camera.lookAt(0, .2, .5);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.75;
    renderer.domElement.className = 'game-canvas'; element.appendChild(renderer.domElement);
    scene.add(new THREE.AmbientLight(0xffd7ab, 1.25));
    const fireA = new THREE.PointLight(0xff6a20, 52, 22); fireA.position.set(-2, 5, 0); scene.add(fireA);
    const fireB = new THREE.PointLight(0xffd892, 30, 18); fireB.position.set(3, 5.5, -5); scene.add(fireB);
    const underLight = new THREE.PointLight(0xff8b3a, 7, 9); underLight.position.set(0, .8, -4.8); scene.add(underLight);
    const nestLight = new THREE.PointLight(0xffb347, 14, 9); nestLight.position.set(0, 3.2, -5); scene.add(nestLight);
    // Cabinet + lower playfield.
    const cabinet = new THREE.Mesh(new THREE.BoxGeometry(11.3, .65, 17.25), new THREE.MeshStandardMaterial({ color: 0x251712, metalness: .45, roughness: .32 }));
    cabinet.position.y = -.32; scene.add(cabinet);
    const trim = new THREE.Mesh(new THREE.BoxGeometry(11.05, .13, 16.95), new THREE.MeshStandardMaterial({ color: 0xa65a2c, metalness: .8, roughness: .25 }));
    trim.position.y = .015; scene.add(trim);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(10.55, 16.35), new THREE.MeshStandardMaterial({ map: boardTexture(), roughness: .58, metalness: .12 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = .095; scene.add(floor);
    const laneRailMaterials: Partial<Record<'left' | 'right', THREE.MeshStandardMaterial>> = {};
    mainWalls.forEach(w => {
      const rail = makeBar(scene, w.a, w.b, w.color ?? 0xa77246, w.color ? .18 : .15, .36, .28, w.color ?? 0x381709);
      if (w.a.x === w.b.x && w.a.x === SHOOTER.innerRail) laneRailMaterials.left = rail.material;
      if (w.a.x === w.b.x && w.a.x === SHOOTER.outerRail) laneRailMaterials.right = rail.material;
    });
    mainPosts.forEach(p => {
      const tall = p.z < -2;
      const m = new THREE.Mesh(new THREE.CylinderGeometry(p.r, p.r + .05, tall ? 1.1 : .34, 14), new THREE.MeshStandardMaterial({ color: 0xd38c45, metalness: .85, roughness: .22 }));
      m.position.set(p.x, tall ? .6 : .32, p.z); scene.add(m);
    });
    // TRUE UPPER DECK: solid platform on pillars, ball rolls both ON it and UNDER it.
    const deckTop = UPPER_SURFACE_Y, deckThick = .18;
    const deck = new THREE.Mesh(new THREE.BoxGeometry(UX1 - UX0 + .3, deckThick, UZ1 - UZ0 + .3),
      new THREE.MeshStandardMaterial({ color: 0x2a1a12, metalness: .55, roughness: .4, emissive: 0x3a1408, emissiveIntensity: .5 }));
    deck.position.set((UX0 + UX1) / 2, deckTop - deckThick / 2, (UZ0 + UZ1) / 2); scene.add(deck);
    const deckSkin = new THREE.Mesh(new THREE.PlaneGeometry(UX1 - UX0 + .24, UZ1 - UZ0 + .24),
      new THREE.MeshStandardMaterial({ map: upperTexture(), roughness: .5, metalness: .2, emissive: 0x662208, emissiveIntensity: .35 }));
    deckSkin.rotation.x = -Math.PI / 2; deckSkin.position.set((UX0 + UX1) / 2, deckTop + .005, (UZ0 + UZ1) / 2); scene.add(deckSkin);
    const lipMat = new THREE.MeshStandardMaterial({ color: 0xff8b2a, emissive: 0xe65a12, emissiveIntensity: 1.4, metalness: .3, roughness: .3 });
    [[UX0, -2.1], [-.5, .5], [2.0, UX1]].forEach(([x0, x1]) => {
      const lip = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0 + .1, .07, .09), lipMat);
      lip.position.set((x0 + x1) / 2, deckTop + .02, UZ1 + .15); scene.add(lip);
    });
    upperWalls.forEach(w => makeBar(scene, w.a, w.b, 0xc77a35, .12, .3, deckTop + .15, 0x903c10));
    upperHoles.forEach(h => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.34, .09, 10, 28), new THREE.MeshStandardMaterial({ color: 0xf28e3d, emissive: 0xdb4d1c, emissiveIntensity: 1.3, metalness: .45, roughness: .22 }));
      ring.rotation.x = Math.PI / 2; ring.position.set(h.x, deckTop + .06, h.z); scene.add(ring);
      const pit = new THREE.Mesh(new THREE.CircleGeometry(.3, 28), new THREE.MeshBasicMaterial({ color: 0x0a0505, side: THREE.DoubleSide }));
      pit.rotation.x = -Math.PI / 2; pit.position.set(h.x, deckTop + .01, h.z); scene.add(pit);
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(.3, .3, deckTop - FLOOR_Y + .3, 18, 1, true),
        new THREE.MeshStandardMaterial({ color: 0xff7a2a, transparent: true, opacity: .28, emissive: 0xd74a12, emissiveIntensity: .8, side: THREE.DoubleSide }));
      shaft.position.set(h.x, (deckTop + FLOOR_Y) / 2, h.z); scene.add(shaft);
    });
    const rolloverMeshes: THREE.Mesh[] = [];
    rollovers.forEach(r => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(.2, .24, .07, 18), new THREE.MeshStandardMaterial({ color: 0x3a2a20, emissive: 0x30160a, emissiveIntensity: .4, metalness: .4, roughness: .4 }));
      m.position.set(r.x, deckTop + .04, r.z); scene.add(m); rolloverMeshes.push(m);
    });
    const diverter = new THREE.Mesh(new THREE.CylinderGeometry(.16, .2, .34, 14), new THREE.MeshStandardMaterial({ color: 0xd38c45, metalness: .85, roughness: .22 }));
    diverter.position.set(0, deckTop + .17, -6.3); scene.add(diverter);
    // Ramp tubes: transparent so the climbing ball stays visible.
    const rampCurves: THREE.CatmullRomCurve3[] = [];
    [rampL, rampR].forEach(r => {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(r.mouth.x, FLOOR_Y + .1, r.mouth.z),
        new THREE.Vector3(r.ctrl.x, 1.0, r.ctrl.z),
        new THREE.Vector3((r.ctrl.x + r.exit.x) / 2, 1.45, (r.ctrl.z + r.exit.z) / 2),
        new THREE.Vector3(r.exit.x, UPPER_Y, r.exit.z),
      ]);
      rampCurves.push(curve);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 28, .37, 12, false),
        new THREE.MeshStandardMaterial({ color: 0xff8b3d, transparent: true, opacity: .3, emissive: 0xc33f0e, emissiveIntensity: .7, metalness: .2, roughness: .3, side: THREE.DoubleSide }));
      scene.add(tube);
      const mouth = new THREE.Mesh(new THREE.TorusGeometry(.42, .09, 10, 24), new THREE.MeshStandardMaterial({ color: 0xffc36d, emissive: 0xe65a12, emissiveIntensity: 1.6 }));
      mouth.position.set(r.mouth.x, FLOOR_Y + .18, r.mouth.z); scene.add(mouth);
      const exit = new THREE.Mesh(new THREE.TorusGeometry(.4, .06, 8, 24), new THREE.MeshStandardMaterial({ color: 0xffc36d, emissive: 0xe65a12, emissiveIntensity: 1.2 }));
      exit.rotation.x = Math.PI / 2; exit.position.set(r.exit.x, deckTop + .1, r.exit.z); scene.add(exit);
    });
    // Bells live ON the upper deck now.
    const bumpers: { mesh: THREE.Group; hit: number; lit: boolean }[] = [];
    bellPositions.forEach((p, i) => {
      const g = new THREE.Group(); g.position.set(p.x, deckTop + .12, p.z);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(.57, .65, .16, 28), new THREE.MeshStandardMaterial({ color: 0x563124, metalness: .7, roughness: .26 })); g.add(base);
      const gold = new THREE.Mesh(new THREE.CylinderGeometry(.39, .52, .38, 28), new THREE.MeshStandardMaterial({ color: 0xe7aa52, metalness: .8, roughness: .18, emissive: 0x854012, emissiveIntensity: .5 }));
      gold.position.y = .25; g.add(gold);
      const cap = new THREE.Mesh(new THREE.SphereGeometry(.29, 20, 14), new THREE.MeshStandardMaterial({ color: 0xffd887, metalness: .65, roughness: .16, emissive: 0xff8420, emissiveIntensity: .4 }));
      cap.scale.y = .56; cap.position.y = .52; g.add(cap);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.57, .055, 8, 32), new THREE.MeshBasicMaterial({ color: 0xff8b2a }));
      ring.rotation.x = Math.PI / 2; ring.position.y = .17; g.add(ring);
      scene.add(g); bumpers.push({ mesh: g, hit: 0, lit: false });
      const marker = new THREE.Mesh(new THREE.RingGeometry(.84, .87, 32), new THREE.MeshBasicMaterial({ color: i === 1 ? 0xeaaa47 : 0x9c4723, side: THREE.DoubleSide }));
      marker.rotation.x = -Math.PI / 2; marker.position.set(p.x, deckTop + .012, p.z); scene.add(marker);
    });
    // Saucers + maw on the lower deck.
    saucers.forEach(p => {
      const outer = new THREE.Mesh(new THREE.TorusGeometry(.42, .1, 10, 30), new THREE.MeshStandardMaterial({ color: 0xdd7936, emissive: 0xa8310b, emissiveIntensity: .9, metalness: .6 }));
      outer.rotation.x = Math.PI / 2; outer.position.set(p.x, .19, p.z); scene.add(outer);
      const center = new THREE.Mesh(new THREE.CircleGeometry(.32, 28), new THREE.MeshBasicMaterial({ color: 0x4b160f, side: THREE.DoubleSide }));
      center.rotation.x = -Math.PI / 2; center.position.set(p.x, .115, p.z); scene.add(center);
    });
    const mawRing = new THREE.Mesh(new THREE.TorusGeometry(.44, .12, 12, 32), new THREE.MeshStandardMaterial({ color: 0xf28e3d, emissive: 0xdb4d1c, emissiveIntensity: 1.4, metalness: .45, roughness: .22 }));
    mawRing.rotation.x = Math.PI / 2; mawRing.position.set(MAW.x, .17, MAW.z); scene.add(mawRing);
    const mawInner = new THREE.Mesh(new THREE.CircleGeometry(.34, 28), new THREE.MeshBasicMaterial({ color: 0x120808, side: THREE.DoubleSide }));
    mawInner.rotation.x = -Math.PI / 2; mawInner.position.set(MAW.x, .115, MAW.z); scene.add(mawInner);
    // Spinner in the left lane.
    const spinner = new THREE.Group(); spinner.position.set(SPINNER.x, .55, SPINNER.z);
    const spinPost = new THREE.Mesh(new THREE.CylinderGeometry(.07, .07, .8, 10), new THREE.MeshStandardMaterial({ color: 0xd38c45, metalness: .8, roughness: .3 }));
    spinner.add(spinPost);
    const spinArm = new THREE.Mesh(new THREE.BoxGeometry(.09, .5, 1.0), new THREE.MeshStandardMaterial({ color: 0xff9a3d, emissive: 0xc33f0e, emissiveIntensity: .9 }));
    spinner.add(spinArm); scene.add(spinner);
    // Plunger.
    // Plunger: group origin = the tip that touches the ball, so visuals match the physics exactly.
    const plunger = new THREE.Group(); plunger.position.set(LANE_X, FLOOR_Y, TIP_REST_Z);
    const tipCap = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, .08, 16), new THREE.MeshStandardMaterial({ color: 0x3a1a10, metalness: .3, roughness: .7 }));
    tipCap.rotation.x = Math.PI / 2; tipCap.position.z = .04; plunger.add(tipCap);
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(.07, .07, 1.25, 12), new THREE.MeshStandardMaterial({ color: 0xd38c45, metalness: .85, roughness: .25 }));
    rod.rotation.x = Math.PI / 2; rod.position.z = .66; plunger.add(rod);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(.19, 14, 10), new THREE.MeshStandardMaterial({ color: 0xff8b2a, emissive: 0xb53a08, emissiveIntensity: .8 }));
    knob.position.z = 1.3; plunger.add(knob); scene.add(plunger);
    // Spring coils compress between the tip and a fixed housing.
    const SPRING_FIXED_Z = 7.75;
    const springMat = new THREE.MeshStandardMaterial({ color: 0xc9c2b5, metalness: .9, roughness: .2 });
    const coils: THREE.Mesh[] = [];
    for (let i = 0; i < 7; i++) { const c = new THREE.Mesh(new THREE.TorusGeometry(.15, .025, 6, 18), springMat); c.position.set(LANE_X, FLOOR_Y, 7.2); scene.add(c); coils.push(c); }
    const housing = new THREE.Mesh(new THREE.BoxGeometry(.5, .32, .12), new THREE.MeshStandardMaterial({ color: 0x5a3421, metalness: .7, roughness: .3 }));
    housing.position.set(LANE_X, FLOOR_Y, SPRING_FIXED_Z + .06); scene.add(housing);
    const plungerGlow = new THREE.PointLight(0xff7a2a, 0, 2.5); plungerGlow.position.set(LANE_X, .9, 6.9); scene.add(plungerGlow);

    // SERPENT TUNNEL: an enclosed salamander-body tube that snakes across the lower field.
    const serpentCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(SERP_MOUTH.x, FLOOR_Y + .1, SERP_MOUTH.z),
      new THREE.Vector3(2.8, 1.0, .3),
      new THREE.Vector3(1.2, 1.4, -.35),
      new THREE.Vector3(-1.0, 1.35, .2),
      new THREE.Vector3(-2.9, 1.15, 1.2),
      new THREE.Vector3(-4.05, .85, 2.6),
      new THREE.Vector3(-3.55, FLOOR_Y + .1, 3.95),
    ]);
    const serpentLen = serpentCurve.getLength();
    const serpentTube = new THREE.Mesh(new THREE.TubeGeometry(serpentCurve, 64, .34, 12, false),
      new THREE.MeshStandardMaterial({ color: 0x2a1610, transparent: true, opacity: .42, emissive: 0x5a1c08, emissiveIntensity: .8, metalness: .3, roughness: .35, side: THREE.DoubleSide }));
    scene.add(serpentTube);
    // Yellow salamander-spot bands double as chase lights while the ball rides.
    const serpentLights: THREE.Mesh[] = [];
    for (let i = 1; i < 14; i++) {
      const t = i / 14, p = serpentCurve.getPoint(t), tan = serpentCurve.getTangent(t);
      const band = new THREE.Mesh(new THREE.TorusGeometry(.36, .045, 6, 20), new THREE.MeshStandardMaterial({ color: 0xffcf3f, emissive: 0xb07a00, emissiveIntensity: .5 }));
      band.position.copy(p); band.lookAt(p.clone().add(tan)); scene.add(band); serpentLights.push(band);
    }
    const serpHead = new THREE.Group(); serpHead.position.set(SERP_MOUTH.x, FLOOR_Y + .2, SERP_MOUTH.z + .05);
    const serpJaw = new THREE.Mesh(new THREE.TorusGeometry(.42, .1, 10, 24), new THREE.MeshStandardMaterial({ color: 0x1a1210, emissive: 0x3a1408, emissiveIntensity: .6, metalness: .4, roughness: .4 }));
    serpHead.add(serpJaw);
    const serpEyeMat = new THREE.MeshStandardMaterial({ color: 0x39ff6a, emissive: 0x1fd44f, emissiveIntensity: 2.2 });
    [-.24, .24].forEach(dx => { const e = new THREE.Mesh(new THREE.SphereGeometry(.08, 10, 8), serpEyeMat); e.position.set(dx, .42, 0); serpHead.add(e); });
    scene.add(serpHead);
    // SKYSHOT wireform: carries a hard plunge from the lane crown up onto the nest.
    const skyCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(LANE_X, FLOOR_Y, LANE_TOP_Z),
      new THREE.Vector3(SHOOTER.outerRail - .3, 1.0, -7.2),
      new THREE.Vector3(3.95, 1.75, -7.25),
      new THREE.Vector3(3.2, UPPER_Y, -6.8),
    ]);
    const skyTube = new THREE.Mesh(new THREE.TubeGeometry(skyCurve, 24, .3, 10, false),
      new THREE.MeshStandardMaterial({ color: 0xffd887, transparent: true, opacity: .22, emissive: 0xc9861a, emissiveIntensity: .7, side: THREE.DoubleSide }));
    scene.add(skyTube);
    rampCurves.push(serpentCurve, skyCurve); // ride indices: 0 L ramp, 1 R ramp, 2 serpent, 3 skyshot
    // ---- Difficulty obstacle meshes (visibility toggled by difficulty) ----
    // EASY: Ember Spire, a static kicker bumper.
    const spireGroup = new THREE.Group(); spireGroup.position.set(SPIRE.x, 0, SPIRE.z);
    const spireBase = new THREE.Mesh(new THREE.CylinderGeometry(.42, .5, .12, 20), new THREE.MeshStandardMaterial({ color: 0x4a2418, metalness: .6, roughness: .35 }));
    spireBase.position.y = .16; spireGroup.add(spireBase);
    const spireMat = new THREE.MeshStandardMaterial({ color: 0xff7a2a, emissive: 0xd74a12, emissiveIntensity: 1.2, metalness: .3, roughness: .3 });
    const spireCone = new THREE.Mesh(new THREE.ConeGeometry(.3, .95, 14), spireMat);
    spireCone.position.y = .65; spireGroup.add(spireCone);
    const spireRing = new THREE.Mesh(new THREE.TorusGeometry(.5, .045, 8, 32), new THREE.MeshBasicMaterial({ color: 0xff8b2a }));
    spireRing.rotation.x = Math.PI / 2; spireRing.position.y = .12; spireGroup.add(spireRing);
    scene.add(spireGroup);
    // MEDIUM: the whole mechanism sits on the nest, with clear space under it.
    const pendGroup = new THREE.Group();
    pendGroup.position.y = deckTop;
    const groove = new THREE.Mesh(new THREE.BoxGeometry(PEND.amp * 2 + .5, .035, .15), new THREE.MeshStandardMaterial({ color: 0x1a1210, emissive: 0x7c2a10, emissiveIntensity: .8 }));
    groove.position.set(PEND.cx, .025, PEND.z); pendGroup.add(groove);
    const pendMat = new THREE.MeshStandardMaterial({ color: 0xff9a3d, emissive: 0xc33f0e, emissiveIntensity: 1.4, metalness: .4, roughness: .3 });
    const pendOrb = new THREE.Mesh(new THREE.SphereGeometry(PEND.r, 18, 14), pendMat);
    pendOrb.position.set(PEND.cx, UPPER_Y - deckTop, PEND.z); pendGroup.add(pendOrb);
    const pendRing = new THREE.Mesh(new THREE.TorusGeometry(.3, .025, 8, 28), new THREE.MeshBasicMaterial({ color: 0xffb054 }));
    pendRing.position.set(PEND.cx, .045, PEND.z); pendRing.rotation.x = Math.PI / 2; pendGroup.add(pendRing);
    scene.add(pendGroup);
    // HARD: Cinder Moons, twin bumpers orbiting above the maw.
    const moonGroup = new THREE.Group();
    const orbitRing = new THREE.Mesh(new THREE.TorusGeometry(MOONS.r, .025, 6, 64), new THREE.MeshBasicMaterial({ color: 0x8f4a22, transparent: true, opacity: .7 }));
    orbitRing.rotation.x = Math.PI / 2; orbitRing.position.set(MOONS.cx, .115, MOONS.cz); moonGroup.add(orbitRing);
    const moonMeshes: THREE.Mesh[] = [];
    for (let i = 0; i < 2; i++) {
      const m = new THREE.Mesh(new THREE.SphereGeometry(MOONS.orb, 16, 12), new THREE.MeshStandardMaterial({ color: 0x2a1a12, emissive: 0xe64a0c, emissiveIntensity: 1.1, metalness: .5, roughness: .35 }));
      m.position.y = FLOOR_Y + .05; moonGroup.add(m); moonMeshes.push(m);
    }
    scene.add(moonGroup);
    // EXTRA HARD: Inferno Vents, twin jet zones guarding the flippers.
    const ventGroup = new THREE.Group();
    const ventVisuals = VENTS.map(v => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(VENT_R, .06, 8, 40), new THREE.MeshStandardMaterial({ color: 0xff5030, emissive: 0xff2f12, emissiveIntensity: 1.2, metalness: .3, roughness: .4 }));
      ring.rotation.x = Math.PI / 2; ring.position.set(v.x, .12, v.z); ventGroup.add(ring);
      const grate = new THREE.Mesh(new THREE.CylinderGeometry(.48, .48, .03, 24), new THREE.MeshStandardMaterial({ color: 0x231a17, metalness: .8, roughness: .4 }));
      grate.position.set(v.x, .12, v.z); ventGroup.add(grate);
      for (let i = 0; i < 6; i++) {
        const slit = new THREE.Mesh(new THREE.BoxGeometry(.64, .008, .024), new THREE.MeshBasicMaterial({ color: 0xcd521d }));
        slit.position.set(v.x, .14, v.z); slit.rotation.y = i * Math.PI / 6; ventGroup.add(slit);
      }
      const jet = new THREE.Mesh(new THREE.ConeGeometry(.5, 1.2, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0xffb24c, transparent: true, opacity: 0, emissive: 0xe64a0c, emissiveIntensity: 2.5, side: THREE.DoubleSide, depthWrite: false }));
      jet.position.set(v.x, .75, v.z); jet.visible = false; ventGroup.add(jet);
      const shock = new THREE.Mesh(new THREE.RingGeometry(.68, .76, 40), new THREE.MeshBasicMaterial({ color: 0xffda85, side: THREE.DoubleSide, transparent: true, opacity: 0, depthWrite: false }));
      shock.rotation.x = -Math.PI / 2; shock.position.set(v.x, .19, v.z); ventGroup.add(shock);
      const glow = new THREE.PointLight(0xff741e, 0, 3.8); glow.position.set(v.x, .9, v.z); ventGroup.add(glow);
      return { ring, jet, shock, glow };
    });
    scene.add(ventGroup);
    // Flippers.
    const flipperMeshes: THREE.Mesh[] = [];
    for (let i = 0; i < 2; i++) {
      const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(.19, FLEN - .34, 5, 12), new THREE.MeshStandardMaterial({ color: 0xffa34d, emissive: 0x9d3718, emissiveIntensity: .35, metalness: .55, roughness: .27 }));
      mesh.rotation.z = Math.PI / 2; mesh.position.y = FLOOR_Y; scene.add(mesh); flipperMeshes.push(mesh);
      const pivot = new THREE.Mesh(new THREE.CylinderGeometry(.26, .26, .34, 18), new THREE.MeshStandardMaterial({ color: 0xd99250, metalness: .76, roughness: .25 }));
      pivot.position.set(i === 0 ? -2.08 : 2.08, .28, 5.82); scene.add(pivot);
    }
    // 3D fire-salamander mascot brooding over the nest.
    const mand = new THREE.Group(); mand.position.set(0, 2.35, -7.35);
    const mandMat = new THREE.MeshStandardMaterial({ color: 0x161110, roughness: .55, metalness: .15 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.44, 1.7, 6, 14), mandMat);
    body.rotation.z = Math.PI / 2; mand.add(body);
    for (let i = 0; i < 10; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(.1, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffcf3f, emissive: 0xa86a00, emissiveIntensity: .7 }));
      s.position.set(-.9 + (i % 5) * .45, .32 + (i % 2) * .12, (i > 4 ? -.2 : .2)); mand.add(s);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(.5, 18, 14), mandMat); head.position.set(1.35, .12, .1); mand.add(head);
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x39ff6a, emissive: 0x1fd44f, emissiveIntensity: 2.2 });
    const eyes: THREE.Mesh[] = [];
    [-.18, .18].forEach(dx => { const e = new THREE.Mesh(new THREE.SphereGeometry(.11, 10, 8), eyeMat); e.position.set(1.72, .28, .1 + dx * 2); mand.add(e); eyes.push(e); });
    [[.7, .3], [.7, -.3], [-.7, .3], [-.7, -.3]].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(.11, .14, .5, 8), mandMat);
      leg.position.set(lx, -.4, lz); leg.rotation.x = lz > 0 ? -.5 : .5; mand.add(leg);
    });
    const tailCurve = new THREE.CatmullRomCurve3([new THREE.Vector3(-1.1, 0, 0), new THREE.Vector3(-1.7, .5, -.3), new THREE.Vector3(-1.5, 1.1, .2), new THREE.Vector3(-1.9, 1.6, 0)]);
    const tail = new THREE.Mesh(new THREE.TubeGeometry(tailCurve, 16, .16, 8, false), mandMat); mand.add(tail);
    const tailTip = new THREE.Mesh(new THREE.ConeGeometry(.24, .7, 10), new THREE.MeshStandardMaterial({ color: 0xff7a2a, emissive: 0xe64a0c, emissiveIntensity: 2.4 }));
    tailTip.position.set(-1.9, 2.0, 0); mand.add(tailTip);
    const mandLight = new THREE.PointLight(0x7dff5a, 5, 7); mandLight.position.set(1.6, .6, .2); mand.add(mandLight);
    const tailLight = new THREE.PointLight(0xff6a1e, 10, 9); tailLight.position.set(-1.9, 2.1, 0); mand.add(tailLight);
    scene.add(mand);
    // Ball with a visible marble texture so spin reads on screen.
    const ballMesh = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 26, 18), new THREE.MeshStandardMaterial({ map: ballTexture(), metalness: .55, roughness: .25, emissive: 0x8d3a12, emissiveIntensity: .18 }));
    scene.add(ballMesh);
    const ballGlow = new THREE.PointLight(0xffa340, 3, 3); scene.add(ballGlow);
    const beacon = new THREE.Mesh(new THREE.TorusGeometry(.42, .05, 8, 32), new THREE.MeshBasicMaterial({ color: 0xffb054, transparent: true, opacity: .9 }));
    beacon.rotation.x = Math.PI / 2; beacon.visible = false; scene.add(beacon);
    const trail: THREE.Mesh[] = [];
    for (let i = 0; i < 7; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(.11 - i * .012, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff7227, transparent: true, opacity: .35 - i * .04 })); scene.add(m); trail.push(m); }
    const sparks: { mesh: THREE.Mesh; life: number; vx: number; vy: number; vz: number }[] = [];
    const sparkGeom = new THREE.SphereGeometry(.055, 6, 5);
    const spawnSparks = (x: number, y: number, z: number, count = 9) => {
      for (let i = 0; i < count; i++) {
        const m = new THREE.Mesh(sparkGeom, new THREE.MeshBasicMaterial({ color: Math.random() > .5 ? 0xffc36d : 0xff6526, transparent: true, opacity: 1 }));
        m.position.set(x, y, z); scene.add(m);
        const a = Math.random() * Math.PI * 2, s = 2 + Math.random() * 5;
        sparks.push({ mesh: m, life: .45 + Math.random() * .35, vx: Math.cos(a) * s, vy: 1 + Math.random() * 2.5, vz: Math.sin(a) * s });
      }
    };
    // Ambient rising embers.
    const EMBERS = 110;
    const emberPos = new Float32Array(EMBERS * 3), emberSpd = new Float32Array(EMBERS);
    for (let i = 0; i < EMBERS; i++) { emberPos[i * 3] = rand(-5.2, 5.2); emberPos[i * 3 + 1] = rand(0, 4); emberPos[i * 3 + 2] = rand(-8, 8); emberSpd[i] = rand(.4, 1.3); }
    const emberGeom = new THREE.BufferGeometry();
    emberGeom.setAttribute('position', new THREE.BufferAttribute(emberPos, 3));
    const embers = new THREE.Points(emberGeom, new THREE.PointsMaterial({ color: 0xff8b3d, size: .07, transparent: true, opacity: .75 }));
    scene.add(embers);

    const safeNum = (v: string | null, fb = 0) => { const n = Number(v); return Number.isFinite(n) ? n : fb; };
    let diffIdx = difficultyIndex(safeNum(localStorage.getItem('pyre-pinball-diff')));
    let runDifficulty = diffIdx;
    const D = () => DIFFS[runDifficulty];
    const bestKey = (difficulty: number) => `pyre-pinball-best-${difficulty}`;
    const bestFor = (difficulty: number) => safeNum(localStorage.getItem(bestKey(difficulty))) || (difficulty === 0 ? safeNum(localStorage.getItem('pyre-pinball-best')) : 0);
    const state: GameSnapshot = { status: 'ready', score: 0, best: bestFor(diffIdx), balls: 3, bells: 0, tunnel: false, message: 'THE FORGE AWAITS', muted: false, level: 'SHOOTER', power: 0, tilt: false, difficulty: diffIdx, scoreDifficulty: diffIdx, charging: false, canLaunch: false, catAlert: false };
    const ball = { x: LANE_X, z: BALL_REST_Z, y: FLOOR_Y, vx: 0, vz: 0, vy: 0, spin: 0, launched: false, inShooter: true, onUpper: false, falling: false, ramp: -1 as number, rampT: 0, rideDur: 1, rideSpeed: 0, hold: 0, holdAt: -1, cd: 0, still: 0, stallT: 0, lastX: LANE_X, lastZ: BALL_REST_Z, power: 0, charging: false };
    const plg = { pull: 0, vel: 0, omega: 0, strokePull: 0, strokeTime: 0, chargeStart: -1, firing: false, speed: 0, power: 0, difficulty: diffIdx };
    const flip = { left: false, right: false, la: REST_L, ra: REST_R, lav: 0, rav: 0 };
    let audio: AudioContext | null = null, lastTone = 0, lastMessage = 0, frame = 0, lastTime = performance.now(), acc = 0, raf = 0;
    let shake = 0, spinVel = 0, spinAngle = 0, tiltCount = 0, tiltWindow = 0, tiltUntil = 0, nudgeX = 0, nudgeZ = 0, nudgeCd = 0;
    let bellCombo = 0, bellTimer = 0, litRoll = [false, false, false], rollTimer = 0, curLevel = 'SHOOTER', powerTick = 0;
    let simT = 0; // simulation clock: drives moving obstacles in both physics and visuals so they always agree
    const obCd = { spire: -9, pend: -9, moon: -9 };
    const ventStates = VENTS.map(() => createVentState());
    const laneFlashes = { left: -10, right: -10 };
    let bellResetTimer = 0;
    let catTimer = 0;
    const emit = () => onUpdate({ ...state, charging: ball.charging, canLaunch: state.status === 'playing' && !ball.launched && !plg.firing }); emit();
    const message = (t: string) => { state.message = t; lastMessage = performance.now(); emit(); };
    const tone = (freq: number, dur = .1, type: OscillatorType = 'sine', vol = .055) => {
      if (state.muted) return;
      try {
        audio ??= new AudioContext(); if (audio.state === 'suspended') audio.resume();
        const now = audio.currentTime; if (now - lastTone < .027) return; lastTone = now;
        const f = freq * (1 + (Math.random() - .5) * .09);
        const o = audio.createOscillator(), g = audio.createGain();
        o.type = type; o.frequency.setValueAtTime(f, now); o.frequency.exponentialRampToValueAtTime(Math.max(80, f * .62), now + dur);
        g.gain.setValueAtTime(vol, now); g.gain.exponentialRampToValueAtTime(.001, now + dur);
        o.connect(g); g.connect(audio.destination); o.start(now); o.stop(now + dur);
      } catch { /* audio optional */ }
    };
    const catHiss = () => {
      if (state.muted) return;
      try {
        audio ??= new AudioContext(); if (audio.state === 'suspended') void audio.resume();
        const now = audio.currentTime;
        const length = Math.floor(audio.sampleRate * .68);
        const buffer = audio.createBuffer(1, length, audio.sampleRate);
        const data = buffer.getChannelData(0);
        let grit = 0;
        for (let i = 0; i < length; i++) {
          grit = grit * .45 + (Math.random() * 2 - 1) * .55;
          data[i] = grit;
        }
        const noise = audio.createBufferSource(); noise.buffer = buffer;
        const band = audio.createBiquadFilter(); band.type = 'bandpass'; band.Q.value = .65;
        band.frequency.setValueAtTime(1700, now); band.frequency.exponentialRampToValueAtTime(3500, now + .45);
        const hissGain = audio.createGain(); hissGain.gain.setValueAtTime(.001, now);
        hissGain.gain.exponentialRampToValueAtTime(.14, now + .075);
        hissGain.gain.exponentialRampToValueAtTime(.001, now + .65);
        noise.connect(band); band.connect(hissGain); hissGain.connect(audio.destination);
        noise.start(now); noise.stop(now + .68);
        const growl = audio.createOscillator(); growl.type = 'sawtooth';
        growl.frequency.setValueAtTime(105, now); growl.frequency.exponentialRampToValueAtTime(53, now + .55);
        const low = audio.createBiquadFilter(); low.type = 'lowpass'; low.frequency.value = 220;
        const growlGain = audio.createGain(); growlGain.gain.setValueAtTime(.001, now);
        growlGain.gain.exponentialRampToValueAtTime(.075, now + .12);
        growlGain.gain.exponentialRampToValueAtTime(.001, now + .62);
        growl.connect(low); low.connect(growlGain); growlGain.connect(audio.destination);
        growl.start(now); growl.stop(now + .64);
      } catch { /* Sound is optional if audio is blocked by the browser. */ }
    };
    const addScore = (n: number) => {
      if (state.status !== 'playing') return;
      state.score += n;
      if (state.score > state.best) {
        state.best = state.score;
        localStorage.setItem(bestKey(runDifficulty), String(state.best));
      }
      emit();
    };
    const clampSpin = (s: number) => clamp(s, -12 * D().spin, 12 * D().spin);
    const addShake = (a: number) => { shake = Math.min(.22, shake + a * D().shake); };
    const resetBall = () => {
      ball.x = LANE_X; ball.z = BALL_REST_Z; ball.y = FLOOR_Y; ball.vx = 0; ball.vz = 0; ball.vy = 0; ball.spin = 0;
      plg.firing = false; plg.vel = 0; plg.pull = 0; plg.strokeTime = 0; plg.strokePull = 0; plg.chargeStart = -1; state.power = 0;
      ball.launched = false; ball.inShooter = true; ball.onUpper = false; ball.falling = false; ball.ramp = -1; ball.rampT = 0; ball.hold = 0; ball.cd = 0;
      ball.still = 0; ball.stallT = 0; ball.power = 0; ball.charging = false; ball.lastX = ball.x; ball.lastZ = ball.z;
    };
    const cancelCharge = () => {
      if (!ball.charging) return;
      ball.charging = false; ball.power = 0; state.power = 0; plg.chargeStart = -1; plg.pull = 0;
      if (!ball.launched) ball.z = BALL_REST_Z;
      emit();
    };
    const beginCharge = () => {
      if (state.status !== 'playing' || ball.launched || plg.firing || ball.charging) return;
      ball.charging = true; ball.power = 0; state.power = 0; plg.chargeStart = performance.now();
      emit();
    };
    const launch = (power: number) => {
      if (state.status !== 'playing' || ball.launched || plg.firing) return;
      ball.charging = false; ball.power = 0; state.power = 0;
      plg.power = clamp(power, 0, 1); plg.difficulty = runDifficulty;
      plg.speed = plungeSpeed(plg.power, plg.difficulty);
      plg.pull = plg.power * PULL_MAX; plg.strokePull = plg.pull; plg.strokeTime = 0;
      plg.omega = plungeSpeed(1, plg.difficulty) / PULL_MAX; plg.vel = 0;
      plg.firing = plg.power > 0;
      plg.chargeStart = -1;
      emit();
    };
    const releaseCharge = () => {
      if (!ball.charging || state.status !== 'playing') return;
      const held = Math.max(0, performance.now() - plg.chargeStart);
      launch(held / (CHARGE_SECONDS * 1000));
    };
    const releaseFromPlunger = () => {
      ball.launched = true; ball.inShooter = true; ball.x = LANE_X; ball.z = BALL_REST_Z;
      Object.assign(ball, plungeVelocity(plg.power, plg.difficulty));
      ball.stallT = 0; ball.still = 0; ball.lastX = ball.x; ball.lastZ = ball.z;
      tone(260 + plg.power * 380, .22, 'sawtooth', .07); addShake(.03 + plg.power * .06);
      spawnSparks(LANE_X, FLOOR_Y + .1, BALL_REST_Z - .2, 4 + Math.round(plg.power * 8));
      message(plg.power < .3 ? 'SHORT PLUNGE / EXPECT A ROLLBACK' : `PLUNGE / ${plg.speed.toFixed(1)} u/s`);
      plg.pull = -.07 * plg.power;
    };
    const rescue = (auto = false, escaped = false) => {
      if (state.status !== 'playing' || !ball.launched || ball.ramp >= 0) return;
      if (escaped) { catHiss(); catTimer = 2.1; state.catAlert = true; }
      if (ball.inShooter) { resetBall(); message(escaped ? 'AN ANGRY CAT HISSED / BALL RESET' : 'BACK ON THE PLUNGER / HOLD TO CHARGE'); return; }
      if (ball.onUpper || ball.falling) { ball.x = -1.4; ball.z = -2.95; ball.y = UPPER_Y; ball.vy = 0; ball.onUpper = true; ball.falling = false; ball.vx = rand(-.8, .8); ball.vz = 3.5; }
      else { ball.x = .2; ball.z = -.25; ball.y = FLOOR_Y; ball.vx = rand(-1, 1); ball.vz = -6.5; }
      ball.inShooter = false; ball.vy = 0; ball.spin = rand(-3, 3); ball.still = 0; ball.stallT = 0; ball.cd = 1.5; ball.hold = 0;
      spawnSparks(ball.x, ball.y + .2, ball.z, 16); tone(660, .2, 'triangle');
      message(escaped ? 'AN ANGRY CAT HISSED / BALL RETURNED' : auto ? 'AUTO RESCUE  /  BACK IN PLAY' : 'BALL RESCUED  /  BACK IN PLAY');
    };
    const start = () => {
      runDifficulty = diffIdx;
      state.scoreDifficulty = runDifficulty;
      state.best = bestFor(runDifficulty);
      state.status = 'playing'; state.score = 0; state.balls = 3; state.bells = 0; state.tunnel = false; state.tilt = false;
      state.catAlert = false; catTimer = 0;
      bumpers.forEach(b => { b.lit = false; b.hit = 0; }); litRoll = [false, false, false];
      bellResetTimer = 0; bellCombo = 0; bellTimer = 0; rollTimer = 0;
      tiltCount = 0; tiltUntil = 0; tiltWindow = 0; nudgeCd = 0; nudgeX = 0; nudgeZ = 0;
      flip.left = false; flip.right = false;
      ventStates.forEach(v => Object.assign(v, createVentState()));
      applyDiffVisibility();
      resetBall(); message('HOLD SPACE OR LAUNCH / RELEASE TO PLUNGE');
    };
    const togglePause = () => {
      if (state.status === 'playing') { cancelCharge(); state.status = 'paused'; flip.left = false; flip.right = false; }
      else if (state.status === 'paused') state.status = 'playing';
      emit();
    };
    const setFlipper = (side: 'left' | 'right', down: boolean) => {
      if (performance.now() < tiltUntil) down = false;
      flip[side] = down; if (down) tone(155, .045, 'square', .04);
    };
    const nudge = () => {
      if (state.status !== 'playing' || !ball.launched || performance.now() < tiltUntil || nudgeCd > 0) return;
      nudgeCd = .45;
      const a = rand(Math.PI * 2), s = rand(2.5, 4.5);
      ball.vx += Math.cos(a) * s; ball.vz += Math.sin(a) * s; ball.spin += rand(-5, 5);
      nudgeX += Math.cos(a) * 1.5; nudgeZ += Math.sin(a) * 1.5;
      addShake(.1); tone(120, .12, 'square', .05); message('NUDGE!');
      tiltCount++; tiltWindow = 6;
      if (tiltCount >= 3) { tiltUntil = performance.now() + 4000; tiltCount = 0; state.tilt = true; flip.left = flip.right = false; message('TILT!  FLIPPERS DEAD  4s'); tone(90, .5, 'sawtooth', .07); emit(); }
    };
    const applyDiffVisibility = () => {
      const visibleDifficulty = state.status === 'ready' ? diffIdx : runDifficulty;
      spireGroup.visible = visibleDifficulty >= 1; pendGroup.visible = visibleDifficulty >= 2;
      moonGroup.visible = visibleDifficulty >= 3; ventGroup.visible = visibleDifficulty >= 4;
    };
    applyDiffVisibility();
    const setDifficulty = (d: number) => {
      const next = selectDifficultyForNextRun(state, d, bestFor);
      if (!next) return;
      diffIdx = next.difficulty; localStorage.setItem('pyre-pinball-diff', String(diffIdx));
      state.difficulty = next.difficulty;
      if (state.status === 'ready') {
        runDifficulty = next.scoreDifficulty;
        state.scoreDifficulty = next.scoreDifficulty;
        state.best = next.best;
        ventStates.forEach(v => Object.assign(v, createVentState()));
        applyDiffVisibility();
      }
      const info = DIFF_INFO[diffIdx];
      message(state.status === 'gameover' ? `NEXT RUN: ${info.name} / FINAL SCORE LOCKED` : info.obstacle ? `${info.name} / ${info.obstacle} RISES` : `${info.name} / BASE FORGE`);
      tone(520 + diffIdx * 90, .25, 'sawtooth');
      emit();
    };
    api.current = { start, launch: releaseCharge, beginCharge, releaseCharge, cancelCharge, rescue: () => rescue(), togglePause, toggleMute: () => { state.muted = !state.muted; emit(); }, setFlipper, nudge, setDifficulty };

    const collideCircle = (p: Point, r: number, bounce: number, bellIndex = -1) => {
      const dx = ball.x - p.x, dz = ball.z - p.z, dist = Math.hypot(dx, dz), min = r + BALL_R;
      if (dist >= min) return;
      const nx = dist > .001 ? dx / dist : 1, nz = dist > .001 ? dz / dist : 0;
      const tx = -nz, tz = nx;
      ball.x = p.x + nx * (min + .006); ball.z = p.z + nz * (min + .006);
      const vn = ball.vx * nx + ball.vz * nz, vt = ball.vx * tx + ball.vz * tz;
      if (vn < 0) {
        // Spin-coupled bounce: tangential velocity and spin exchange energy, plus rubber jitter.
        const e = Math.min(bounce * D().kick, 1.18) * (1 + (Math.random() - .5) * .16 * D().jitter);
        const vn2 = -vn * e;
        const vt2 = vt * (.94 + (Math.random() - .5) * .08 * D().jitter) - ball.spin * .3 * D().magnus + rand(-.55, .55) * D().jitter;
        ball.spin = clampSpin(ball.spin * .55 + vt * .3 * D().magnus + rand(-1.4, 1.4) * D().jitter);
        ball.vx = nx * vn2 + tx * vt2; ball.vz = nz * vn2 + tz * vt2;
      }
      if (bellIndex >= 0) {
        const b = bumpers[bellIndex];
        if (b.hit <= 0) {
          // Bells kick with randomized angle + power so no two hits repeat.
          const jitter = rand(-.24, .24) * Math.min(D().jitter, 2), pow = rand(8.5, 11.5) * D().bell;
          const ca = Math.cos(jitter), sa = Math.sin(jitter);
          const kx = nx * ca - nz * sa, kz = nx * sa + nz * ca;
          ball.vx += kx * pow; ball.vz += kz * pow - 1.5; ball.spin = clampSpin(ball.spin + rand(-6, 6) * D().spin);
          b.hit = .26; bellCombo = bellTimer > 0 ? bellCombo + 1 : 1; bellTimer = 1.2;
          const pts = 400 * Math.min(bellCombo, 4);
          spawnSparks(p.x, UPPER_Y + .2, ball.z, 10); tone(710 + bellIndex * 130, .17, 'triangle'); addScore(pts); addShake(.05);
          if (!b.lit) {
            b.lit = true; state.bells++;
            message(`FIRE BELL ${state.bells} / 3  +${pts}${bellCombo > 1 ? `  COMBO x${Math.min(bellCombo, 4)}` : ''}`);
            if (state.bells === 3) {
              addScore(5000); message('INFERNO BONUS  +5,000'); spawnSparks(p.x, UPPER_Y + .3, p.z, 30); addShake(.18);
              bellResetTimer = 2.4;
            }
          } else message(`BELL STRIKE  +${pts}`);
        }
      }
    };
    const collideSegment = (seg: Segment, upper: boolean) => {
      const ax = seg.a.x, az = seg.a.z, dx = seg.b.x - ax, dz = seg.b.z - az;
      const len2 = dx * dx + dz * dz;
      const t = clamp(((ball.x - ax) * dx + (ball.z - az) * dz) / len2, 0, 1);
      const px = ax + t * dx, pz = az + t * dz;
      const dist = Math.hypot(ball.x - px, ball.z - pz), min = BALL_R + (seg.color ? .14 : .1);
      if (dist >= min) return;
      let nx = (ball.x - px) / (dist || 1), nz = (ball.z - pz) / (dist || 1);
      if (dist < .001) { const l = Math.hypot(dx, dz); nx = -dz / l; nz = dx / l; }
      ball.x = px + nx * (min + .008); ball.z = pz + nz * (min + .008);
      const tx = -nz, tz = nx;
      const vn = ball.vx * nx + ball.vz * nz, vt = ball.vx * tx + ball.vz * tz;
      if (vn < 0) {
        const e = Math.min((seg.bounce ?? .8) * D().kick, 1.18) * (1 + (Math.random() - .5) * .16 * D().jitter);
        const vn2 = -vn * e;
        const vt2 = vt * (.94 + (Math.random() - .5) * .08 * D().jitter) - ball.spin * .26 * D().magnus + rand(-.5, .5) * D().jitter;
        ball.spin = clampSpin(ball.spin * .6 + vt * .26 * D().magnus + rand(-1.2, 1.2) * D().jitter);
        ball.vx = nx * vn2 + tx * vt2; ball.vz = nz * vn2 + tz * vt2;
        // Slingshots fire a randomized kicker pulse.
        if (seg.points) {
          const kick = rand(5.5, 8) * D().kick;
          ball.vx += nx * kick; ball.vz += nz * kick; ball.spin = clampSpin(ball.spin + rand(-4, 4) * D().spin);
          addScore(seg.points); tone(390 * (1 + rand(-.06, .06)), .07, 'triangle');
          spawnSparks(ball.x, (upper ? UPPER_Y : FLOOR_Y) + .1, ball.z, 3); addShake(.03);
        }
      }
    };
    const collideFlipper = (side: 'left' | 'right', ang: number, angVel: number) => {
      const pivX = side === 'left' ? -2.08 : 2.08, pivZ = 5.82;
      const dx = Math.cos(ang) * FLEN, dz = Math.sin(ang) * FLEN;
      const t = clamp(((ball.x - pivX) * dx + (ball.z - pivZ) * dz) / (FLEN * FLEN), 0, 1);
      const px = pivX + t * dx, pz = pivZ + t * dz;
      const dist = Math.hypot(ball.x - px, ball.z - pz), min = BALL_R + .19;
      if (dist >= min) return;
      const nx = dist > .001 ? (ball.x - px) / dist : 0, nz = dist > .001 ? (ball.z - pz) / dist : -1;
      ball.x = px + nx * (min + .008); ball.z = pz + nz * (min + .008);
      // Contact-point velocity from the swing + low restitution rubber + timing variance.
      const r = t * FLEN, pxp = -Math.sin(ang), pzp = Math.cos(ang);
      const cvx = pxp * angVel * r, cvz = pzp * angVel * r;
      const vn = (ball.vx - cvx) * nx + (ball.vz - cvz) * nz;
      if (vn < 0) {
        const snap = (side === 'left' ? flip.left : flip.right) ? 1 : 0;
        const j = -(1 + .42) * vn;
        ball.vx += j * nx + cvx * .28 + rand(-.5, .5) * D().jitter - ball.spin * .06 * -nz;
        ball.vz += j * nz + cvz * .28 + rand(-.5, .5) * D().jitter - ball.spin * .06 * nx;
        if (snap) {
          // Flippers hit slightly harder on brutal levels so the faster ball stays playable.
          ball.vz -= 2.2 * (1 - t * .35) * (1 + (D().kick - 1) * .4); ball.vx += (side === 'left' ? 1 : -1) * rand(.8, 1.8);
          ball.spin = clampSpin(ball.spin + rand(-3, 3) * D().spin + angVel * .12);
          tone(230, .07, 'square', .05); spawnSparks(ball.x, FLOOR_Y + .1, ball.z, 4); addShake(.04);
        } else ball.spin = clampSpin(ball.spin * .7 + rand(-1, 1) * D().jitter);
      }
    };

    // ---- Difficulty obstacle physics ----
    const pendPos = pendulumPosition;
    const moonPos = (t: number, k: number) => {
      const a = MOONS.w * t + k * Math.PI;
      return { x: MOONS.cx + MOONS.r * Math.cos(a), z: MOONS.cz + MOONS.r * Math.sin(a), vx: -MOONS.r * MOONS.w * Math.sin(a), vz: MOONS.r * MOONS.w * Math.cos(a) };
    };
    // Kicker bumper with an optional mover velocity (static spire, sliding pendulum, orbiting moons).
    const collideKicker = (px: number, pz: number, pr: number, mvx: number, mvz: number, cdKey: 'spire' | 'pend' | 'moon', pts: number, label: string, layer: 'upper' | 'lower' = 'lower') => {
      const hit = resolveMovingBumper(ball, { x: px, z: pz, r: pr, vx: mvx, vz: mvz, layer }, runDifficulty);
      if (hit && simT - obCd[cdKey] > .25) {
        obCd[cdKey] = simT;
        addScore(pts); tone(cdKey === 'moon' ? 660 : 540, .12, 'triangle');
        spawnSparks(ball.x, (layer === 'upper' ? UPPER_Y : FLOOR_Y) + .2, ball.z, 8);
        addShake(.05); message(`${label}  +${pts}`);
      }
    };
    const applyVents = (previous: Point, dt: number) => {
      for (let i = 0; i < VENTS.length; i++) {
        const hit = fireInfernoVent(ball, previous, VENTS[i], ventStates[i], simT, dt, runDifficulty);
        if (!hit) continue;
        addScore(150); tone(145 + i * 70, .24, 'sawtooth', .075);
        spawnSparks(VENTS[i].x, FLOOR_Y + .1, VENTS[i].z, 20);
        spawnSparks(hit.x, FLOOR_Y + .3, hit.z, 8);
        addShake(.09);
        message(`${i === 0 ? 'LEFT' : 'RIGHT'} INFERNO BLAST / +150`);
      }
    };

    const startRide = (idx: number) => {
      const speed = Math.max(2, Math.hypot(ball.vx, ball.vz));
      ball.inShooter = false; ball.ramp = idx; ball.rampT = 0; ball.rideSpeed = speed; ball.spin = 0; ball.hold = 0;
      if (idx <= 1) {
        ball.rideDur = clamp(18 / speed, .8, 1.6); // faster entry = quicker climb
        addScore(1000); state.tunnel = true; tone(520 + idx * 120, .3, 'sawtooth');
        message(idx === 0 ? 'LEFT RAMP  +1,000  → NEST' : 'RIGHT RAMP  +1,000  → NEST');
      } else if (idx === 2) {
        ball.rideDur = clamp(serpentLen / (speed * 1.1), .9, 2.1);
        addScore(1500); state.tunnel = true; tone(300, .45, 'sawtooth');
        message('SERPENT TUNNEL  +1,500');
      } else {
        ball.rideDur = clamp(3.2 / speed, .18, .45);
      }
      spawnSparks(ball.x, ball.y + .3, ball.z, 12);
    };
    const startFall = () => { ball.falling = true; ball.vy = 0; tone(300, .15, 'sine', .04); };
    const ejectSaucer = (_i: number) => {
      void _i;
      ball.hold = 0; ball.cd = 1.4; spawnSparks(ball.x, FLOOR_Y + .3, ball.z, 14);
      const roll = Math.random();
      if (roll < .15) {
        // Volcano launch: kicked clean up to the nest through the drop shaft.
        ball.onUpper = true; ball.x = rand(-1, 1); ball.z = -4.6; ball.y = UPPER_Y;
        ball.vx = rand(-3, 3) * D().kick; ball.vz = rand(-1, 2) * D().kick; ball.spin = clampSpin(rand(-6, 6) * D().spin);
        addScore(1500); message('VOLCANO LAUNCH  +1,500'); tone(880, .3, 'sawtooth'); addShake(.12);
      } else if (roll < .4) {
        const dir = ball.x > 0 ? 1 : -1;
        ball.vx = dir * rand(5, 7.5) * D().kick; ball.vz = rand(-3.5, -.5) * D().kick; ball.spin = clampSpin(rand(-6, 6) * D().spin);
        message('EMBER EJECT  → SLINGS'); tone(880, .18, 'sawtooth');
      } else {
        ball.vx = rand(-2.5, 2.5) * D().kick; ball.vz = rand(-11, -8) * D().kick; ball.spin = clampSpin(rand(-5, 5) * D().spin);
        message('EMBER EJECT  ↑ FIELD'); tone(880, .18, 'sawtooth');
      }
    };

    const step = (dt: number) => {
      if (state.status === 'paused') return;
      if (state.status === 'playing') simT += dt;
      const time = simT;
      if (catTimer > 0 && state.status === 'playing') {
        catTimer -= dt;
        if (catTimer <= 0) { state.catAlert = false; emit(); }
      }
      if (bellResetTimer > 0 && state.status === 'playing') {
        bellResetTimer -= dt;
        if (bellResetTimer <= 0) { state.bells = 0; bumpers.forEach(b => b.lit = false); emit(); }
      }
      // Flipper swing with tracked angular velocity.
      const lt = flip.left ? ACT_L : REST_L, rt = flip.right ? ACT_R : REST_R;
      const spd = 30, rel = 13;
      const nla = flip.la + (lt - flip.la) * Math.min(1, dt * (flip.left ? spd : rel));
      const nra = flip.ra + (rt - flip.ra) * Math.min(1, dt * (flip.right ? spd : rel));
      flip.lav = (nla - flip.la) / dt; flip.rav = (nra - flip.ra) / dt;
      flip.la = nla; flip.ra = nra;
      bellTimer = Math.max(0, bellTimer - dt); rollTimer = Math.max(0, rollTimer - dt);
      nudgeX *= 1 - 2 * dt; nudgeZ *= 1 - 2 * dt; nudgeCd = Math.max(0, nudgeCd - dt);
      tiltWindow = Math.max(0, tiltWindow - dt); if (tiltWindow === 0) tiltCount = 0;
      if (state.tilt && performance.now() > tiltUntil) { state.tilt = false; message('TILT CLEARED  /  PLAY ON'); emit(); }
      // --- Plunger simulation (runs before the ball is in play) ---
      if (state.status === 'playing' && !ball.launched) {
        if (plg.firing) {
          // Analytic spring motion keeps a short stroke from gaining energy through timestep overshoot.
          plg.strokeTime += dt;
          const phase = Math.min(Math.PI / 2, plg.strokeTime * plg.omega);
          plg.pull = plg.strokePull * Math.cos(phase);
          plg.vel = plg.strokePull * plg.omega * Math.sin(phase);
          if (phase >= Math.PI / 2) { plg.firing = false; releaseFromPlunger(); return; }
          else ball.z = BALL_REST_Z + plg.pull;
        } else if (ball.charging) {
          ball.power = clamp((performance.now() - plg.chargeStart) / (CHARGE_SECONDS * 1000), 0, 1); state.power = ball.power;
          plg.pull = ball.power * PULL_MAX; ball.z = BALL_REST_Z + plg.pull;
          if (++powerTick % 4 === 0) emit();
        } else {
          plg.pull += (0 - plg.pull) * Math.min(1, dt * 12); ball.z = BALL_REST_Z + Math.max(0, plg.pull);
        }
        ball.x = LANE_X;
      } else if (!plg.firing) {
        plg.pull += (0 - plg.pull) * Math.min(1, dt * 12); // recoil settles after release
      }
      bumpers.forEach(b => b.hit = Math.max(0, b.hit - dt));
      spinVel *= 1 - 1.6 * dt; spinAngle += spinVel * dt;
      if (state.status !== 'playing' || !ball.launched) return;
      if (!Number.isFinite(ball.x + ball.y + ball.z + ball.vx + ball.vy + ball.vz + ball.spin)) {
        ball.ramp = -1; ball.hold = 0; rescue(true, true); return;
      }
      // Ramp ride: locked to the tube curve, then deposited on the nest.
      if (ball.ramp >= 0) {
        ball.rampT += dt / ball.rideDur;
        const t = Math.min(1, ball.rampT);
        // Ramps climb (ease in/out); tunnel and skyshot carry momentum (linear with slight slowdown).
        const s = ball.ramp <= 1 ? t * t * (3 - 2 * t) : t * (1.15 - .15 * t);
        const pt = rampCurves[ball.ramp].getPoint(Math.min(1, s));
        ball.x = pt.x; ball.z = pt.z; ball.y = pt.y;
        if (t >= 1) {
          const idx = ball.ramp; ball.ramp = -1; ball.falling = false;
          if (idx <= 1) {
            const r = idx === 0 ? rampL : rampR;
            ball.onUpper = true; ball.y = UPPER_Y; ball.x = r.exit.x; ball.z = r.exit.z;
            ball.vx = r.evx + rand(-1, 1); ball.vz = r.evz + rand(-.5, 1); ball.spin = clampSpin(rand(-4, 4) * D().spin); ball.cd = .8;
            addScore(500); message('NEST LANDING  +500'); tone(760, .2, 'triangle'); addShake(.06);
          } else if (idx === 2) {
            // Serpent spits the ball into the left inlane along its exit tangent, speed tied to entry speed.
            const tan = serpentCurve.getTangent(1); const h = Math.hypot(tan.x, tan.z) || 1;
            const out = clamp(ball.rideSpeed * .55, 3, 7.5);
            ball.onUpper = false; ball.y = FLOOR_Y;
            ball.vx = tan.x / h * out + rand(-.6, .6); ball.vz = tan.z / h * out + rand(-.4, .4); ball.spin = clampSpin(rand(-5, 5) * D().spin); ball.cd = .7;
            addScore(500); message('SERPENT RELEASES  →  LEFT FLIPPER'); tone(420, .22, 'triangle'); addShake(.05);
            spawnSparks(ball.x, FLOOR_Y + .2, ball.z, 10);
          } else {
            // Skyshot landing: lateral speed scales with how hard the ball was plunged.
            ball.onUpper = true; ball.y = UPPER_Y;
            ball.vx = -ball.rideSpeed * rand(.3, .45); ball.vz = rand(.8, 2.4); ball.spin = clampSpin(rand(-5, 5) * D().spin); ball.cd = .6;
            state.tunnel = true; addScore(2500); spawnSparks(ball.x, UPPER_Y + .3, ball.z, 20); tone(990, .3, 'sawtooth');
            message(`SKYSHOT!  NEST  +2,500`); addShake(.12);
          }
        }
        return;
      }
      if (ball.hold > 0) {
        ball.hold -= dt;
        if (ball.hold <= 0) ejectSaucer(ball.holdAt);
        return;
      }
      ball.cd = Math.max(0, ball.cd - dt);
      // Falling between decks: vertical gravity + continued lateral drift.
      if (ball.falling) {
        ball.vy -= 20 * D().grav * dt; ball.y += ball.vy * dt;
        ball.vx *= 1 - .1 * dt; ball.vz = ball.vz + 4 * D().grav * dt;
        ball.x += ball.vx * dt; ball.z += ball.vz * dt;
        // Once under the nest, the cabinet rails still contain a falling ball.
        if (ball.x < -4.3) { ball.x = -4.3; ball.vx = Math.abs(ball.vx) * .55; }
        if (ball.x > 3.8) { ball.x = 3.8; ball.vx = -Math.abs(ball.vx) * .55; }
        if (ball.z < -7.24) { ball.z = -7.24; ball.vz = Math.abs(ball.vz) * .55; }
        ball.z = Math.min(ball.z, 7.6);
        if (ball.y <= FLOOR_Y) {
          ball.y = FLOOR_Y; ball.falling = false; ball.onUpper = false; ball.vy = 0; ball.cd = Math.max(ball.cd, .4);
          containPlayfield(ball);
          spawnSparks(ball.x, FLOOR_Y + .1, ball.z, 8); tone(180, .12, 'sine', .05); addShake(.05);
          message('BACK TO THE FIRE  +250'); addScore(250);
        }
        return;
      }
      if (!ball.onUpper && !ball.inShooter && ball.x > SHOOTER.innerRail + BALL_R + SHOOTER.railRadius && ball.z > LANE_TOP_Z && ball.z < LANE_TOP_Z + 1) {
        ball.inShooter = true;
      }
      if (ball.inShooter) {
        const lane = advanceShooter(ball, dt, runDifficulty);
        if (lane.wallHits && lane.lastWall) {
          laneFlashes[lane.lastWall] = simT;
          if (lane.impact > .12) {
            const wallX = lane.lastWall === 'left' ? SHOOTER.innerRail : SHOOTER.outerRail;
            spawnSparks(wallX, FLOOR_Y, ball.z, 3);
            tone(440 + lane.impact * 70, .045, 'triangle', .03);
          }
        }
        if (lane.kind === 'exit') {
          ball.inShooter = false;
          const top = -ball.vz;
          if (top >= SKYSHOT_SPEED + rand(-.5, .5)) { startRide(3); return; }
          const s = top * .85;
          const railDeflection = ball.vx;
          ball.x = SHOOTER.innerRail - BALL_R - .14; ball.z = -6.9;
          ball.vx = -s * rand(.78, .92) + railDeflection * .18; ball.vz = s * rand(.22, .4);
          ball.spin = clampSpin(ball.spin + rand(-2, 2));
          spawnSparks(ball.x, FLOOR_Y + .2, ball.z, 6); tone(520 + top * 20, .11);
          message(`ORBIT  ${top.toFixed(1)} u/s  /  UNDER THE NEST`);
        } else if (lane.kind === 'settled') {
          resetBall(); message('ROLLED BACK / SAME BALL / PULL FURTHER');
        }
        return;
      }
      // Rolling: table slope wobble + magnus curve from spin + micro vibration.
      const upper = ball.onUpper;
      const baseG = (upper ? 6.4 : 7.8) * D().grav;
      const gx = (Math.sin(time * .9) * .45 + Math.sin(time * 2.7) * .15) * D().slope + nudgeX;
      const gz = baseG + (Math.sin(time * 1.1 + 1.7) * .5 + Math.sin(time * 3.1) * .15) * D().slope + nudgeZ;
      const mCoef = .16 * D().magnus, mCl = 3 * D().magnus;
      const magX = clamp(-ball.spin * ball.vz * mCoef, -mCl, mCl), magZ = clamp(ball.spin * ball.vx * mCoef, -mCl, mCl);
      const jit = .9 * D().jitter;
      ball.vx += (gx + magX) * dt + rand(-jit, jit) * dt;
      ball.vz += (gz + magZ) * dt + rand(-jit, jit) * dt;
      const drag = (upper ? .22 : .18) * D().drag;
      ball.vx *= 1 - drag * dt; ball.vz *= 1 - drag * .6 * dt; ball.spin *= 1 - 1.1 * dt;
      const previousPosition = { x: ball.x, z: ball.z };
      ball.x += ball.vx * dt; ball.z += ball.vz * dt;

      if (upper) {
        upperWalls.forEach(w => collideSegment(w, true));
        collideCircle({ x: 0, z: -6.3 }, .16, .85);
        bellPositions.forEach((p, i) => collideCircle(p, .55, 1.0, i));
        if (runDifficulty >= 2) {
          const p = pendPos(simT);
          collideKicker(p.x, p.z, PEND.r, p.vx, p.vz, 'pend', 200, 'NEST PENDULUM', 'upper');
        }
        rollovers.forEach((r, i) => {
          if (!litRoll[i] && Math.hypot(ball.x - r.x, ball.z - r.z) < .36) {
            litRoll[i] = true; rollTimer = 6; addScore(200); tone(990 + i * 110, .12, 'sine'); spawnSparks(ball.x, UPPER_Y + .15, ball.z, 4);
            if (litRoll.every(Boolean)) { addScore(2000); message('NEST ROLLOVERS  +2,000'); spawnSparks(ball.x, UPPER_Y + .3, ball.z, 20); }
            else message(`ROLLOVER ${litRoll.filter(Boolean).length} / 3  +200`);
          }
        });
        if (rollTimer === 0 && litRoll.some(Boolean)) litRoll = [false, false, false];
        if (ball.cd <= 0) for (const h of upperHoles) {
          if (Math.hypot(ball.x - h.x, ball.z - h.z) < .3) {
            ball.x = h.x; ball.z = h.z; ball.cd = 1; addScore(750); message('NEST DROP  +750  ↓ UNDERWORLD');
            tone(520, .25, 'triangle'); spawnSparks(h.x, UPPER_Y + .2, h.z, 12); startFall(); return;
          }
        }
        // Waterfall gaps in the front rail spill the ball back to the lower deck.
        if (ball.z > UZ1 - .12) {
          const inGap = (ball.x > -2.1 + BALL_R && ball.x < -.5 - BALL_R) || (ball.x > .5 + BALL_R && ball.x < 2.0 - BALL_R);
          if (inGap) { addScore(400); message('WATERFALL DROP  +400'); startFall(); return; }
          ball.z = UZ1 - BALL_R - .08; ball.vz = -Math.abs(ball.vz) * .65;
        }
      } else {
        mainWalls.forEach(w => { if (w.a.x === 4.12 && ball.z < -6.52) return; collideSegment(w, false); });
        mainPosts.forEach(p => collideCircle(p, p.r, .8));
        // Outlanes feed the drain.
        const outlane = (ball.x < -3.5 && ball.z > 6.3) || (ball.x > 3.35 && ball.x < 4.12 && ball.z > 6.3);
        if (outlane) { ball.vz += 10 * D().grav * dt; }
        // Ramp + tunnel mouths demand up-field pace; slow balls rim out instead of wedging.
        const mouths = [rampL.mouth, rampR.mouth, SERP_MOUTH];
        const need = [-3.5, -3.5, -2.5];
        for (let i = 0; i < 3; i++) {
          const d = Math.hypot(ball.x - mouths[i].x, ball.z - mouths[i].z);
          if (d < .5 && ball.cd <= 0) {
            if (ball.vz < need[i]) { startRide(i); return; }
            const nx = (ball.x - mouths[i].x) / (d || 1), nz = (ball.z - mouths[i].z) / (d || 1);
            ball.x = mouths[i].x + nx * .56; ball.z = mouths[i].z + nz * .56;
            const dot = ball.vx * nx + ball.vz * nz;
            if (dot < 0) { ball.vx -= 1.7 * dot * nx; ball.vz -= 1.7 * dot * nz; }
          }
        }
        if (ball.cd <= 0) saucers.forEach((p, i) => {
          if (Math.hypot(ball.x - p.x, ball.z - p.z) < .32) {
            ball.x = p.x; ball.z = p.z; ball.vx = 0; ball.vz = 0; ball.spin = 0;
            ball.hold = .9; ball.holdAt = i; ball.cd = 2;
            addScore(750); message('EMBER HOLD  +750'); tone(330, .25, 'triangle');
          }
        });
        if (ball.hold > 0) return;
        if (ball.cd <= 0 && Math.hypot(ball.x - MAW.x, ball.z - MAW.z) < .36) {
          ball.cd = 2.2; state.tunnel = true; addScore(1250); tone(990, .3, 'sawtooth');
          spawnSparks(ball.x, FLOOR_Y + .3, ball.z, 18); addShake(.1);
          if (Math.random() < .45) {
            ball.onUpper = true; ball.x = rand(-1.5, 1.5); ball.z = -5; ball.y = UPPER_Y;
            ball.vx = rand(-3, 3) * D().kick; ball.vz = rand(0, 2) * D().kick; ball.spin = clampSpin(rand(-5, 5) * D().spin);
            message('THE MAW SPITS YOU SKYWARD  +1,250');
          } else {
            ball.x = rand(-1, 1); ball.z = -1.2; ball.vx = rand(-6, 6) * D().kick; ball.vz = rand(-4, 1) * D().kick; ball.spin = clampSpin(rand(-6, 6) * D().spin);
            message('THE MAW CHEWS  +1,250');
          }
          return;
        }
        if (Math.hypot(ball.x - SPINNER.x, ball.z - SPINNER.z) < .55) {
          const sp = Math.hypot(ball.vx, ball.vz);
          if (Math.abs(spinVel) < 14 * D().kick && sp > 1.5) {
            spinVel += (ball.vx > 0 ? 1 : -1) * sp * .9 * D().kick + rand(-2, 2) * D().jitter;
            ball.vx *= .94; ball.spin = clampSpin(ball.spin + rand(-3, 3) * D().spin);
            addScore(100); tone(1200, .05, 'square', .03);
          }
        }
        // Difficulty obstacles (cumulative).
        if (runDifficulty >= 1) collideKicker(SPIRE.x, SPIRE.z, SPIRE.r, 0, 0, 'spire', 150, 'EMBER SPIRE');
        if (runDifficulty >= 3) {
          const m0 = moonPos(simT, 0), m1 = moonPos(simT, 1);
          collideKicker(m0.x, m0.z, MOONS.orb, m0.vx, m0.vz, 'moon', 250, 'CINDER MOON');
          collideKicker(m1.x, m1.z, MOONS.orb, m1.vx, m1.vz, 'moon', 250, 'CINDER MOON');
        }
        if (runDifficulty >= 4) applyVents(previousPosition, dt);
        collideFlipper('left', flip.la, flip.lav); collideFlipper('right', flip.ra, flip.rav);
      }
      containPlayfield(ball);
      ball.vx = clamp(ball.vx, -22 * D().vmax, 22 * D().vmax); ball.vz = clamp(ball.vz, -27 * D().vmax, 22 * D().vmax); ball.spin = clampSpin(ball.spin);
      if (!ball.onUpper && !ball.falling && ball.z > 7.95) {
        state.balls--; tone(130, .35, 'sawtooth');
        if (state.balls <= 0) { state.status = 'gameover'; state.catAlert = false; catTimer = 0; message('THE FLAME FADES  /  PLAY AGAIN'); }
        else { resetBall(); message('BALL LOST  /  HOLD SPACE TO LAUNCH'); }
        emit(); return;
      }
      if (ball.z < -8.4 || Math.abs(ball.x) > 5.6 || !Number.isFinite(ball.x + ball.z + ball.spin)) { rescue(true, true); return; }
      // True-stall detection: only a ball dead still for seconds is rescued, never a cradled or slow roller.
      ball.still += dt;
      if (ball.still > .75) {
        const moved = Math.hypot(ball.x - ball.lastX, ball.z - ball.lastZ);
        const speed = Math.hypot(ball.vx, ball.vz);
        if (moved < .14 && speed < .5 && ball.z < 7.4) ball.stallT += .75; else ball.stallT = 0;
        if (ball.stallT > 3.5) { ball.stallT = 0; rescue(true); }
        ball.lastX = ball.x; ball.lastZ = ball.z; ball.still = 0;
      }
    };

    const levelOf = () => {
      if (!ball.launched) return 'SHOOTER';
      if (ball.inShooter) return 'LAUNCH LANE';
      if (ball.ramp === 2) return 'SERPENT TUNNEL';
      if (ball.ramp === 3) return 'SKYSHOT';
      if (ball.ramp >= 0) return 'RAMP';
      if (ball.hold > 0) return 'HOLD';
      if (ball.onUpper || ball.falling) return 'NEST ↑';
      return ball.z < UZ1 && ball.x > UX0 && ball.x < UX1 ? 'UNDER ↓' : 'LOWER';
    };

    const resize = () => {
      const w = element.clientWidth, h = element.clientHeight; if (!w || !h) return;
      renderer.setSize(w, h); camera.aspect = w / h;
      if (w / h < .8) { CAM_BASE.set(0, 18.5, 18.3); camera.fov = 54; }
      else { CAM_BASE.set(0, 16.9, 16.2); camera.fov = w / h > 1.5 ? 42 : 39; }
      camera.updateProjectionMatrix();
    };
    const observer = new ResizeObserver(resize); observer.observe(element); resize();
    const keyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const target = e.target;
      if (target instanceof HTMLElement && (target.closest('input, select, textarea, [contenteditable="true"]') || (k === ' ' && state.status !== 'playing' && target.closest('button')))) return;
      if (['arrowleft', 'arrowright', 'arrowup', ' ', 'a', 'd', 'w', 'r', 'p', 'n'].includes(k)) e.preventDefault();
      if (k === 'arrowleft' || k === 'a') setFlipper('left', true);
      if (k === 'arrowright' || k === 'd') setFlipper('right', true);
      if ((k === 'arrowup' || k === 'w' || k === 'n') && !e.repeat) nudge();
      if (k === ' ' && !e.repeat) {
        if (state.status === 'ready' || state.status === 'gameover') { start(); beginCharge(); }
        else if (state.status === 'paused') togglePause();
        else beginCharge();
      }
      if (k === 'r' && !e.repeat) rescue();
      if (k === 'p' && !e.repeat) togglePause();
      if (!e.repeat && k >= '1' && k <= '5') setDifficulty(Number(k) - 1);
    };
    const keyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') setFlipper('left', false);
      if (k === 'arrowright' || k === 'd') setFlipper('right', false);
      if (k === ' ') releaseCharge();
    };
    const blur = () => { flip.left = flip.right = false; cancelCharge(); };
    window.addEventListener('keydown', keyDown); window.addEventListener('keyup', keyUp); window.addEventListener('blur', blur);

    const animate = (now: number) => {
      raf = requestAnimationFrame(animate);
      const delta = Math.min((now - lastTime) / 1000, .05); lastTime = now; acc += delta;
      let iter = 0;
      while (acc >= 1 / 120 && iter++ < 8) {
        let remaining = 1 / 120;
        // Fast blasts and moving obstacles get extra collision samples, not a larger teleporting step.
        while (remaining > 1e-9) {
          const speed = Math.hypot(ball.vx, ball.vz);
          const safeSpeed = Number.isFinite(speed) ? Math.min(speed + 6, 120) : 6;
          const dt = Math.min(remaining, BALL_R * .42 / safeSpeed);
          step(dt); remaining -= dt;
        }
        acc -= 1 / 120;
      }
      frame += delta;
      flipperMeshes.forEach((mesh, i) => {
        const a = i === 0 ? flip.la : flip.ra, pivot = i === 0 ? -2.08 : 2.08;
        mesh.position.set(pivot + Math.cos(a) * (FLEN / 2), FLOOR_Y, 5.82 + Math.sin(a) * (FLEN / 2));
        mesh.rotation.set(0, -a, Math.PI / 2);
      });
      ballMesh.position.set(ball.x, ball.y, ball.z);
      if (state.status === 'playing') {
        ballMesh.rotation.x += ball.vz * delta * 2.2; ballMesh.rotation.z -= ball.vx * delta * 2.2; ballMesh.rotation.y += ball.spin * delta * .8;
      }
      ballGlow.position.set(ball.x, ball.y + .4, ball.z);
      const underDeck = !ball.onUpper && !ball.falling && ball.launched && ball.z < UZ1 && ball.z > UZ0 && ball.x > UX0 && ball.x < UX1;
      ballGlow.intensity = underDeck ? 7 : 3;
      beacon.visible = underDeck;
      if (underDeck) { beacon.position.set(ball.x, deckTop + .14, ball.z); const s = 1 + Math.sin(frame * 10) * .12; beacon.scale.setScalar(s); }
      trail.forEach((m, i) => { m.position.lerp(ballMesh.position, .32 - i * .032); m.visible = ball.launched && state.status === 'playing' && ball.hold <= 0; });
      bumpers.forEach((b, i) => {
        const pulse = Math.sin(frame * 4 + i * 2) * .05;
        b.mesh.scale.setScalar(1 + pulse + b.hit * .6);
        const ring = b.mesh.children[3] as THREE.Mesh;
        (ring.material as THREE.MeshBasicMaterial).color.setHex(b.lit ? 0xffe18b : 0xff8b2a);
      });
      rolloverMeshes.forEach((m, i) => {
        const mat = m.material as THREE.MeshStandardMaterial;
        mat.emissive.setHex(litRoll[i] ? 0xffb02e : 0x30160a); mat.emissiveIntensity = litRoll[i] ? 1.6 + Math.sin(frame * 8) * .4 : .4;
      });
      spinner.rotation.y = spinAngle;
      // Difficulty obstacles: meshes track the same simT the physics uses, so they never disagree.
      if (runDifficulty >= 1) {
        const heat = Math.max(0, 1 - (simT - obCd.spire) * 3);
        spireMat.emissiveIntensity = 1.2 + heat * 2.5 + Math.sin(frame * 6) * .25;
        spireCone.scale.set(1 + heat * .25, 1 + heat * .15, 1 + heat * .25);
      }
      if (runDifficulty >= 2) {
        const p = pendPos(simT);
        pendOrb.position.x = p.x; pendRing.position.x = p.x;
        const heat = Math.max(0, 1 - (simT - obCd.pend) * 3);
        pendMat.emissiveIntensity = 1.4 + heat * 2.5;
      }
      if (runDifficulty >= 3) {
        const m0 = moonPos(simT, 0), m1 = moonPos(simT, 1);
        moonMeshes[0].position.x = m0.x; moonMeshes[0].position.z = m0.z;
        moonMeshes[1].position.x = m1.x; moonMeshes[1].position.z = m1.z;
        const heat = Math.max(0, 1 - (simT - obCd.moon) * 3);
        moonMeshes.forEach(m => ((m.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.1 + heat * 2.5));
      }
      if (runDifficulty >= 4) {
        ventVisuals.forEach((v, i) => {
          const fired = Math.max(0, 1 - (simT - ventStates[i].firedAt) / .4);
          const recharge = 1 - clamp((ventStates[i].readyAt - simT) / VENT_RECHARGE, 0, 1);
          v.ring.material.emissiveIntensity = .25 + recharge * 1.2 + fired * 5;
          v.ring.material.color.setHex(recharge === 1 ? 0xffa840 : 0x752b20);
          v.jet.visible = fired > 0; v.jet.material.opacity = fired * .6;
          v.jet.scale.set(1 + fired * .25, .3 + fired * 1.5, 1 + fired * .25);
          v.shock.visible = fired > 0; v.shock.material.opacity = fired * .8;
          v.shock.scale.setScalar(1 + (1 - fired) * .9);
          v.glow.intensity = fired * 22;
        });
      }
      (['left', 'right'] as const).forEach(side => {
        const material = laneRailMaterials[side];
        if (material) material.emissiveIntensity = .35 + Math.max(0, 1 - (simT - laneFlashes[side]) / .14) * 3;
      });
      // Organic fire flicker: layered sines + smoothed noise.
      const flick = Math.sin(frame * 9) * .5 + Math.sin(frame * 17 + 1) * .3 + Math.sin(frame * 31) * .2;
      fireA.intensity = 50 + flick * 9 + rand(-2, 2);
      fireB.intensity = 29 + Math.sin(frame * 6 + 1) * 5 + rand(-1.5, 1.5);
      nestLight.intensity = 13 + flick * 3;
      underLight.intensity = 6.5 + Math.sin(frame * 7) * 1.2;
      tailLight.intensity = 9 + flick * 4 + rand(-1, 2);
      tailTip.scale.set(1 + flick * .18, 1 + flick * .3, 1 + flick * .18);
      mand.position.y = 2.35 + Math.sin(frame * 1.8) * .06;
      mand.rotation.y = Math.sin(frame * .6) * .08;
      const blink = Math.sin(frame * .9) > .985 ? .15 : 1;
      eyes.forEach(e => e.scale.set(1, blink, 1));
      eyeMat.emissiveIntensity = 2 + flick * .6;
      const pos = emberGeom.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < EMBERS; i++) {
        let y = pos.getY(i) + emberSpd[i] * delta;
        if (y > 4.5) { y = 0; pos.setX(i, rand(-5.2, 5.2)); pos.setZ(i, rand(-8, 8)); }
        pos.setY(i, y); pos.setX(i, pos.getX(i) + Math.sin(frame * 2 + i) * delta * .3);
      }
      pos.needsUpdate = true;
      // Plunger tip, spring compression and charge glow all read straight from the simulated stroke.
      plunger.position.z = TIP_REST_Z + plg.pull;
      const coilStart = TIP_REST_Z + plg.pull + .1, coilEnd = SPRING_FIXED_Z - .02;
      coils.forEach((c, i) => { c.position.z = coilStart + (coilEnd - coilStart) * (i / (coils.length - 1)); });
      plungerGlow.intensity = ball.charging ? 1 + ball.power * 6 + Math.sin(frame * 30) * ball.power : Math.max(0, plungerGlow.intensity - delta * 20);
      // Serpent chase lights: run with the ball while riding, idle shimmer otherwise.
      serpentLights.forEach((m, i) => {
        const mat = m.material as THREE.MeshStandardMaterial;
        const f = i / serpentLights.length;
        const riding = ball.ramp === 2 && Math.abs(f - ball.rampT) < .14;
        mat.emissiveIntensity = riding ? 3 : .45 + Math.max(0, Math.sin(frame * 3 - i * .6)) * .6;
      });
      serpHead.rotation.y = Math.sin(frame * 1.3) * .12;
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i]; s.life -= delta;
        s.mesh.position.x += s.vx * delta; s.mesh.position.y += s.vy * delta; s.mesh.position.z += s.vz * delta;
        s.vy -= 6 * delta;
        (s.mesh.material as THREE.MeshBasicMaterial).opacity = clamp(s.life * 2, 0, 1);
        if (s.life <= 0) { scene.remove(s.mesh); (s.mesh.material as THREE.Material).dispose(); sparks.splice(i, 1); }
      }
      shake = Math.max(0, shake - delta * .8);
      camera.position.set(CAM_BASE.x + rand(-1, 1) * shake, CAM_BASE.y + rand(-1, 1) * shake * .6, CAM_BASE.z + rand(-1, 1) * shake);
      camera.lookAt(0, .2, .5);
      const lv = levelOf();
      if (lv !== curLevel) { curLevel = lv; state.level = lv; emit(); }
      if (lastMessage && now - lastMessage > 4500 && state.status === 'playing') {
        lastMessage = 0;
        state.message = ball.onUpper ? 'RULE THE NEST' : underDeck ? 'SHADOW RUNNING UNDER THE NEST' : 'KEEP THE FLAME ALIVE';
        emit();
      }
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(raf); observer.disconnect();
      window.removeEventListener('keydown', keyDown); window.removeEventListener('keyup', keyUp); window.removeEventListener('blur', blur);
      audio?.close();
      scene.traverse(obj => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          const mats: THREE.Material[] = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach(m => { if (m instanceof THREE.MeshStandardMaterial && m.map) m.map.dispose(); m.dispose(); });
        }
      });
      emberGeom.dispose(); (embers.material as THREE.Material).dispose();
      renderer.dispose(); element.removeChild(renderer.domElement); api.current = null;
    };
  }, [onUpdate]);
  return <div ref={host} style={{ position: 'absolute', inset: 0 }} />;
});

export default PinballGame;
